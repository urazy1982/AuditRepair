"""Validity checks for WorBettingTest.

1. Exact enumeration: for small finite populations whose mean is <= 0.5 (H0 true,
   boundary cases included), enumerate every distinct ordering and compute the exact
   probability that the test EVER rejects. It must be <= alpha.
2. Monte Carlo: the 15 ones / 15 zeros population reported in the review.
3. Power sanity check: a population with clearly positive benefit should be rejected often.
Run:  python -m tests.test_betting
"""
from __future__ import annotations

import itertools
import math
from collections import Counter

import numpy as np

from audit_repair.core import WorBettingTest, WorLowerCS


def distinct_perms(values):
    """Yield (permutation, multiplicity weight) for every distinct ordering of a multiset."""
    counts = Counter(values)
    total = math.factorial(len(values))
    for c in counts.values():
        total //= math.factorial(c)
    seen = set()
    for p in itertools.permutations(values):
        if p not in seen:
            seen.add(p)
            yield p
    assert len(seen) == total


def exact_reject_prob(values, alpha):
    perms = list(distinct_perms(values))
    rej = 0
    for p in perms:
        t = WorBettingTest(N=len(values), alpha=alpha)
        for x in p:
            t.update(x)
            if t.rejected:
                rej += 1
                break
    return rej / len(perms)  # distinct orderings are equally likely under uniform WoR sampling


def main():
    worst = 0.0
    n_checked = 0
    for N in range(2, 9):
        for alpha in (0.05, 0.2, 0.5):
            # all multisets over {0, 0.5, 1} of size N with mean <= 0.5
            for k1 in range(N + 1):
                for kh in range(N - k1 + 1):
                    vals = [1.0] * k1 + [0.5] * kh + [0.0] * (N - k1 - kh)
                    if sum(vals) / N > 0.5 + 1e-12:
                        continue
                    p = exact_reject_prob(vals, alpha)
                    n_checked += 1
                    worst = max(worst, p / alpha)
                    assert p <= alpha + 1e-12, (N, alpha, vals, p)
    print(f"exact enumeration: {n_checked} null populations, N <= 8; "
          f"worst P(reject)/alpha = {worst:.3f}  (must be <= 1)")

    rng = np.random.default_rng(1)
    for alpha in (0.005, 0.05):
        rej = 0
        for _ in range(4000):
            t = WorBettingTest(N=30, alpha=alpha)
            for x in rng.permutation([1.0] * 15 + [0.0] * 15):
                t.update(x)
                if t.rejected:
                    rej += 1
                    break
        print(f"15 ones / 15 zeros, alpha={alpha}: false rejections {rej}/4000 = {rej / 4000:.4f}")
        assert rej / 4000 <= alpha + 3 * math.sqrt(alpha / 4000)

    rej = 0
    for _ in range(1000):
        t = WorBettingTest(N=200, alpha=0.005)
        for x in rng.permutation([1.0] * 150 + [0.0] * 50):  # mean 0.75 -> benefit +0.5
            t.update(x)
            if t.rejected:
                rej += 1
                break
    print(f"power check (mean 0.75, N=200, alpha=0.005): rejected {rej}/1000")


def test_lower_cs_and_remainder():
    """WorLowerCS: (a) exact enumeration of coverage, P(exists t: lower(t) > true mean) <= alpha;
    (b) Monte Carlo: P(accept repair while the UNAUDITED remainder gain <= 0) <= alpha,
    including the 55/45 counter-example from review."""
    worst = 0.0
    for N in range(2, 8):
        for k1 in range(N + 1):
            for kh in range(N - k1 + 1):
                vals = [1.0] * k1 + [0.5] * kh + [0.0] * (N - k1 - kh)
                mu = sum(vals) / N
                perms = list(distinct_perms(vals)); miss = 0
                for p in perms:
                    cs = WorLowerCS(N, alpha=0.2)
                    for v in p:
                        cs.update(v)
                        if cs.lower > mu + 1e-9:
                            miss += 1; break
                worst = max(worst, miss / len(perms) / 0.2)
    assert worst <= 1.0
    print(f"lower CS exact enumeration (N <= 7): worst P(miscoverage)/alpha = {worst:.3f}")
    rng = np.random.default_rng(3)
    for nb, na, nz in [(55, 45, 0), (52, 48, 0), (40, 40, 20), (60, 40, 0)]:
        x = np.array([1.0] * nb + [0.0] * na + [0.5] * nz); N = len(x); bad = 0
        for _ in range(2000):
            o = rng.permutation(x); cs = WorLowerCS(N, alpha=0.05)
            for k, v in enumerate(o, 1):
                cs.update(v)
                if k < N and cs.remainder_gain_lb() > 0:
                    bad += (2 * o[k:] - 1).sum() <= 0; break
        print(f"  remainder rule, population {nb}/{na}/{nz}: harmful acceptance {bad / 2000:.3f} (<= 0.05)")
        assert bad / 2000 <= 0.05 + 3 * math.sqrt(0.05 / 2000)


if __name__ == "__main__":
    test_lower_cs_and_remainder()
    main()
