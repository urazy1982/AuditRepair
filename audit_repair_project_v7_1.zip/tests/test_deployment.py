import copy
import json
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import deployment


class DeploymentTests(unittest.TestCase):
    def setUp(self):
        self.raw = {"Id": "container-1", "Image": "sha256:image", "RestartCount": 0,
                    "State": {"Running": True, "StartedAt": "2026-10-31T00:00:00Z"},
                    "Config": {"Cmd": ["--model", "org/model", "--revision", "a" * 40,
                                       "--quantization", "awq", "--max-model-len", "4096"],
                               "Env": ["HF_TOKEN=hf_DUMMY_SECRET"]},
                    "NetworkSettings": {"Ports": {"8000/tcp": [{"HostPort": "8001"}]}}}

    def inspect(self):
        with patch.object(deployment.subprocess, "run", return_value=SimpleNamespace(stdout=json.dumps([self.raw]))):
            return deployment.inspect_deployment("server")

    def test_records_actual_config_without_environment(self):
        actual = self.inspect()
        deployment.check_configuration(actual, "org/model", "awq", 4096, 8001)
        self.assertNotIn("hf_DUMMY_SECRET", json.dumps(actual))
        self.assertIn("rev=" + "a" * 40, deployment.verify_manifest(actual, actual))

    def test_changed_deployment_rejected(self):
        recorded = self.inspect()
        for field, value in [("container_id", "replacement"), ("revision", "b" * 40),
                             ("image_id", "newimage"), ("quantization", "fp8"),
                             ("started_at", "later"), ("restart_count", 1)]:
            changed = copy.deepcopy(recorded); changed[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                deployment.verify_manifest(changed, recorded)

    def test_requested_settings_must_match(self):
        actual = self.inspect()
        for kwargs in [dict(model="other"), dict(quant="fp8"), dict(max_model_len=8192),
                       dict(port=8000), dict(revision="b" * 40)]:
            args = dict(model="org/model", quant="awq", max_model_len=4096, port=8001)
            args.update(kwargs)
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                deployment.check_configuration(actual, **args)

    def test_new_verified_instance_preserves_config_fingerprint(self):
        previous = self.inspect()
        new = copy.deepcopy(previous)
        new["container_id"] = "container-2"
        new["started_at"] = "later"
        self.assertEqual(deployment.verify_manifest(previous, previous),
                         deployment.verify_manifest(new, new))

    def test_mutable_revision_and_stopped_container_rejected(self):
        self.raw["Config"]["Cmd"][3] = "main"
        with self.assertRaises(ValueError): self.inspect()
        self.raw["State"]["Running"] = False
        with self.assertRaises(ValueError): self.inspect()


if __name__ == "__main__": unittest.main()
