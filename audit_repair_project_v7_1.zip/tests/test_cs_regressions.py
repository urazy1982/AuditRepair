"""Deterministic checks of the grid inversion, independent of statistical power."""
import unittest

import numpy as np

from audit_repair.core import WorLowerCS


class GridInversionTests(unittest.TestCase):
    def test_high_rejection_cannot_jump_over_unrejected_null(self):
        cs = WorLowerCS(100, grid=5)
        # Reject 0 and .75, leaving .25 and .5 unrejected. Largest-rejected
        # inversion would incorrectly jump to .75; prefix inversion stays at 0.
        cs.log_cap[[0, 3]] = np.inf
        cs.update(0.5)
        self.assertEqual(cs.lower, 0.0)
        cs.log_cap[1] = np.inf
        cs.update(0.5)
        self.assertEqual(cs.lower, 0.25)
        cs.log_cap[2] = np.inf
        cs.update(0.5)
        self.assertEqual(cs.lower, 0.75)

    def test_rejections_are_sticky_even_if_capital_falls(self):
        cs = WorLowerCS(100, grid=5)
        cs.log_cap[:2] = np.inf
        cs.update(0.5)
        self.assertEqual(cs.lower, 0.25)
        # Isolate the inversion bookkeeping by simulating falling capital.
        cs.log_cap[:] = -100.0
        cs.update(0.5)
        self.assertEqual(cs.lower, 0.25)
        np.testing.assert_array_equal(cs._rejected, [True, True, False, False, False])

    def test_no_rejections_gives_zero_bound(self):
        cs = WorLowerCS(100, grid=5)
        cs.update(0.0)
        self.assertEqual(cs.lower, 0.0)

    def test_remainder_bound_subtracts_observed_gain(self):
        cs = WorLowerCS(100, grid=5)
        cs.log_cap[:3] = np.inf
        cs.update(1.0)
        self.assertEqual(cs.lower, 0.5)
        self.assertEqual(cs.remainder_gain_lb(), -1.0)


if __name__ == "__main__":
    unittest.main()
