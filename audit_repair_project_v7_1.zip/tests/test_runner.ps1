# No WSL, Docker, GPU, or network required. Loads only helper definitions, never the runner.
$ErrorActionPreference = "Stop"
$runner = Join-Path (Split-Path $PSScriptRoot -Parent) "Run-AuditRepair.ps1"
$tokens = $null; $parseErrors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($runner, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw ($parseErrors | Out-String) }
foreach ($name in @("Protect-LogText", "Copy-SanitizedLog", "Invoke-Wsl", "Get-WslOutput")) {
    $node = $ast.Find({ param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name }, $true)
    if (-not $node) { throw "Missing helper: $name" }
    Invoke-Expression $node.Extent.Text
}

$HfToken = "review-secret.with-special+characters"
$Distro = "mock"
$script:MockExit = 125
$script:NativeMode = $false
$script:NativePsExe = @("pwsh.exe", "powershell.exe", "pwsh") |
    ForEach-Object { Join-Path $PSHOME $_ } | Where-Object { Test-Path $_ -PathType Leaf } |
    Select-Object -First 1
if (-not $script:NativePsExe) { throw "Cannot locate the current PowerShell executable" }
$script:Captured = @()
$previousExitCode = $global:LASTEXITCODE
function wsl.exe {
    if ($script:NativeMode) {
        # Exercise real native stdout/stderr conversion in this PowerShell version,
        # while still requiring neither WSL nor Docker.
        & $script:NativePsExe -NoProfile -Command "[Console]::Out.WriteLine('payload hf_DUMMY_REVIEW_ONLY'); [Console]::Error.WriteLine('warning hf_DUMMY_REVIEW_ONLY'); exit $($script:MockExit)"
        $global:LASTEXITCODE = $LASTEXITCODE
        return
    }
    $global:LASTEXITCODE = $script:MockExit
    "mock output: $HfToken and hf_DUMMY_REVIEW_ONLY"
}
function Out-Host { process { $script:Captured += [string]$_ } }
function Assert-Clean([string]$text) {
    if ($text.Contains($HfToken) -or $text.Contains("hf_DUMMY_REVIEW_ONLY")) {
        throw "Credential redaction regression"
    }
}
$temp = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
try {
    $message = $null
    try { Invoke-Wsl "docker run -e HF_TOKEN='$HfToken' broken:image" | Out-Null }
    catch { $message = $_.Exception.Message }
    if (-not $message -or $message -notmatch "exit 125") { throw "Expected a nonzero-exit exception" }
    Assert-Clean $message
    Assert-Clean ($script:Captured -join "`n")
    if (($script:Captured -join "`n") -notmatch '\[REDACTED\]') { throw "Output was not redacted" }

    $code = Invoke-Wsl "failing probe" -AllowFail
    if ($code -ne 125) { throw "AllowFail lost the exit code" }
    $script:MockExit = 0
    Assert-Clean (Get-WslOutput "successful probe")
    $script:MockExit = 125
    $message = $null
    try { Get-WslOutput "probe '$HfToken'" | Out-Null } catch { $message = $_.Exception.Message }
    if (-not $message) { throw "Get-WslOutput failed to propagate the error" }
    Assert-Clean $message

    $script:NativeMode = $true
    $script:MockExit = 0
    $value = Get-WslOutput "native streams"
    if ($value -ne "payload [REDACTED]") { throw "Native stderr contaminated stdout: $value" }
    if ($ErrorActionPreference -ne "Stop") { throw "ErrorActionPreference was not restored" }
    $script:MockExit = 7
    if ((Invoke-Wsl "native failure" -AllowFail) -ne 7) { throw "Native exit code lost" }
    $message = $null
    try { Get-WslOutput "native failure" | Out-Null } catch { $message = $_.Exception.Message }
    if (-not $message -or $message -notmatch "exit 7") { throw "Native failure was not propagated" }
    Assert-Clean $message
    Assert-Clean ($script:Captured -join "`n")
    if ($ErrorActionPreference -ne "Stop") { throw "ErrorActionPreference changed on failure" }
    $script:NativeMode = $false

    [IO.File]::WriteAllText($temp, "earlier log $HfToken hf_DUMMY_REVIEW_ONLY")
    Copy-SanitizedLog $temp $temp
    Assert-Clean ([IO.File]::ReadAllText($temp))
    Write-Output "Runner regression checks passed (mocked WSL)."
} finally {
    Remove-Item $temp -ErrorAction SilentlyContinue
    $global:LASTEXITCODE = $previousExitCode
}
