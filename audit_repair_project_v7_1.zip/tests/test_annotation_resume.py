import asyncio
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

import pandas as pd
import annotate_llm as annotation


class ResumeTests(unittest.TestCase):
    def test_recovery_and_explicit_resampling(self):
        class APIError(Exception):
            pass
        state = {"mode": "failed", "calls": 0, "revision": None}
        class Dataset:
            def shuffle(self, seed): return self
            def select(self, indices): return self
            def __getitem__(self, key):
                return {"text": ["example news"], "label": [0]}[key]
        def load(*args, **kwargs):
            state["revision"] = kwargs["revision"]
            return Dataset()
        class Completions:
            async def create(self, **kw):
                state["calls"] += 1
                if state["mode"] == "failed": raise APIError("temporary outage")
                text = "World" if kw["max_tokens"] == 16 else "Answer: World"
                if state["mode"] == "invalid": text = "unparseable"
                return NS(choices=[NS(message=NS(content=text), finish_reason="stop")])
        class Client:
            def __init__(self, **kwargs): self.chat = NS(completions=Completions())
        async def fingerprint(*args): return {"id": "model"}
        async def no_sleep(*args): pass
        with tempfile.TemporaryDirectory() as directory:
            a = NS(dataset="ag_news", revision=None, n=1, concurrency=1,
                   out=str(Path(directory) / "labels.csv"),
                   source=["a=http://mock/v1@model#rev=fixed"],
                   allow_stale_cache=False, retry_unusable=False)
            with patch.dict("sys.modules", {
                "datasets": NS(load_dataset=load),
                "openai": NS(AsyncOpenAI=Client, APIError=APIError),
                "huggingface_hub": NS(HfApi=lambda: NS(dataset_info=lambda *args, **kw: NS(sha="a" * 40)))
            }), patch.object(annotation, "server_fingerprint", fingerprint), patch.object(asyncio, "sleep", no_sleep):
                asyncio.run(annotation.main_async(a))
                self.assertEqual(state["calls"], 8)
                state["mode"] = "ok"
                asyncio.run(annotation.main_async(a))
                self.assertEqual(state["calls"], 10)
                self.assertTrue((pd.read_csv(a.out).filter(like="status_") == "ok").all().all())
                asyncio.run(annotation.main_async(a))
                self.assertEqual(state["calls"], 10)  # successful cache retained
                self.assertEqual(state["revision"], "a" * 40)
                self.assertEqual(json.loads(Path(a.out + ".meta.json").read_text())["revision"], "a" * 40)

                a.out = str(Path(directory) / "invalid.csv")
                state["mode"] = "invalid"
                asyncio.run(annotation.main_async(a))
                state["mode"] = "ok"
                asyncio.run(annotation.main_async(a))
                self.assertEqual(state["calls"], 12)  # invalid output is an outcome, not an outage
                a.retry_unusable = True
                asyncio.run(annotation.main_async(a))
                self.assertEqual(state["calls"], 14)
                self.assertTrue((pd.read_csv(a.out).filter(like="status_") == "ok").all().all())


if __name__ == "__main__": unittest.main()
