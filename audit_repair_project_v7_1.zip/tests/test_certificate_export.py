import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import pandas as pd
from audit_repair.core import WorLowerCS


class CertificateTests(unittest.TestCase):
    def test_export_replays_and_original_arms_are_unchanged(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory) / "comparison"  # also check suffix-free paths
            subprocess.run([sys.executable, "run_certified.py", "--sim", "--scenario", "clear",
                            "--seeds", "1", "--pac_reps", "1", "--boot", "10", "--out", str(out)],
                           cwd=root, check=True, capture_output=True, text=True)
            df = pd.read_csv(out)
            self.assertEqual(len(df), 7)
            self.assertIn("repair_labels_ds_U+pac", set(df.method))
            self.assertIn("ds_labels_repair_U+pac", set(df.method))
            # Compare both paths under the SAME installed dependency versions.
            # The bundled historical CSV was generated in another environment;
            # exact matching to that artifact is not a valid cross-version gate.
            baseline = Path(directory) / "baseline"
            subprocess.run([sys.executable, "run_certified.py", "--sim", "--scenario", "clear",
                            "--seeds", "1", "--pac_reps", "1", "--boot", "10",
                            "--baseline-only", "--out", str(baseline)],
                           cwd=root, check=True, capture_output=True, text=True)
            old = pd.read_csv(baseline)
            merged = old.merge(df, on=["method", "seed", "rep"],
                               suffixes=("_old", "_new"), validate="one_to_one")
            self.assertEqual(len(merged), 5)
            for column in ["pre_audits", "expert_total", "error", "violated"]:
                pd.testing.assert_series_equal(merged[column + "_old"],
                                               merged[column + "_new"], check_names=False)
            # Also assert the original repair certificates are byte-for-byte equivalent.
            self.assertEqual(baseline.with_name("baseline_certificates.jsonl").read_bytes(),
                             out.with_name("comparison_certificates.jsonl").read_bytes())
            records = [json.loads(line) for line in out.with_name("comparison_certificates.jsonl").read_text().splitlines()]
            self.assertTrue(records)
            for record in records:
                cs = WorLowerCS(record["size"], alpha=record["alpha"])
                for h in record["audit_history"]: cs.update((h["gain"] + 1) / 2)
                self.assertEqual(len(record["members"]), record["size"])
                self.assertEqual(len(record["audit_history"]), record["audited"])
                self.assertAlmostEqual(cs.remainder_gain_lb(), record["remainder_lb_exact"])
                self.assertIn(record["stop_reason"], {"certified", "futility", "budget", "audit_cap", "fraction_cap", "population_exhausted"})
                if record["guarded"]: self.assertGreater(record["remainder_lb_exact"], 0)


if __name__ == "__main__": unittest.main()
