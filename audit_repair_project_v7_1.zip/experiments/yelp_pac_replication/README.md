# Frozen Yelp replication

The AG News holdout missed its cost gate. The transfer diagnostic
reproduced that result and found higher grouped DS costs with
520 draws on the holdout. This protocol tests whether the same
aggregation comparison has a useful cost effect on a different corpus.

Use 2,600 distinct Yelp Review Full test texts at revision
`c1f9ee939b7d05667af864ee1cb066393154bf85`. Select the first eligible
texts after shuffling with seed 20261108. Exclude duplicate normalized
prompt-visible text within the sample and against AG News development.
The collector uses the same verified model deployments, prompt
templates and generation settings, with Yelp's five rating labels
in place of AG News topic labels. [Yelp dataset card](https://huggingface.co/datasets/Yelp/yelp_review_full)

## Frozen comparison

- Primary comparison uses grouped DS and prompt-wise DS with zero
  preprocessing audits. Grouped DS models the two prompt outputs from
  each model jointly.
- Secondary comparison uses the same 400 prompt-wise uncertainty
  audits in each arm.
- Use 1,000 PAC draws, a 3% final error target, alpha 0.10,
  20 preprocessing seeds and ten paired PAC repetitions per seed.
  Use the dataset ratings to simulate expert labels.
- Advance if the primary mean saving is at least 26 expert labels,
  the 95% paired bootstrap interval is above zero, its paired
  upper mean-error increase is at most 0.5 percentage points,
  and both primary arms have zero observed violations of 3%.
- Apply the existing maximum 5% unusable-output share per source.

Intervals quantify algorithmic variability conditional on the Yelp
pool. Retain the AG News negative result and report Yelp separately.
A positive Yelp result indicates a benefit on this corpus and
motivates testing what drives the difference between the two tasks.

## Run on the RTX 5090

Extract this ZIP into `C:\auditrepair\yelp_pac_replication`.
If the model servers are stopped, start them in Windows PowerShell.
Use the same HF_TOKEN environment setting as the development run.

```powershell
Set-Location C:\auditrepair\v6_4_2
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-AuditRepair.ps1 -Stages Serve -ServerTimeoutMin 60 -VllmImage "vllm/vllm-openai@sha256:d825baf9ce4b1b6bfc5ecc7b79880c7e6748c65a72d697ce3d47607aafa84c6e" -RevisionA "b25037543e9394b818fdfca67ab2a00ecc7dd641" -RevisionB "db1f81ad4b8c7e39777509fac66c652eb0a52f91"
wsl -d Ubuntu-24.04
```

Run the following in WSL. The collector resumes its cache with the
same inputs.

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/yelp_pac_replication
python -u annotate_yelp.py --development "$HOME/audit_repair/ag_news_5000.csv" --deployment-dir "$HOME/audit_repair" --out yelp_2600.csv
```

After annotation succeeds, run the CPU evaluation with a fresh output
directory. The JSON decision, paired cost breakdown and manifest are
written under the output path.

```bash
python -u run_replication.py --development "$HOME/audit_repair/ag_news_5000.csv" --labels yelp_2600.csv --out yelp_results
python -m zipfile -c yelp_results.zip yelp_results yelp_2600.csv yelp_2600.csv.meta.json
```
