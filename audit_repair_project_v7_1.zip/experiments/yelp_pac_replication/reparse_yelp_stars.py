"""Replay the frozen Yelp cache with a narrow singular/plural label alias."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import sys

import pandas as pd

from annotate_yelp import _norm, parse, sha
from holdout_protocol import digest, metadata
from replication_protocol import CLASSES, DATASET, ITEMS, REVISION

RULE = "posthoc_star_spelling_alias_v1"


def repair(answer, prompt, finish_reason):
    label, status = parse(answer, CLASSES, prompt, finish_reason)
    if status != "invalid":
        return label, status
    if prompt == "direct":
        candidate = _norm(answer)
    else:
        lines = answer.strip().splitlines()
        if not lines:
            return label, status
        last = lines[-1]
        match = re.fullmatch(r"\s*\**\s*answer\s*:\s*(.+?)\s*", last, re.I)
        if not match:
            return label, status
        candidate = _norm(match.group(1))
    alias = re.fullmatch(r"([1-5]) stars?", candidate)
    return (int(alias.group(1)) - 1, "ok") if alias else (label, status)


def reparse(labels, cache_path, out):
    meta = metadata(labels)
    if (meta["dataset"], meta["revision"], meta["classes"], meta["n"]) != (
            DATASET, REVISION, CLASSES, ITEMS):
        raise ValueError("Unexpected frozen Yelp metadata")
    original_hash = digest(labels)
    if meta["replication_sha256"] != original_hash or "parser_sensitivity" in meta:
        raise ValueError("Provide the original strict-parser CSV and sidecar")
    df = pd.read_csv(labels, keep_default_na=False)
    if len(df) != ITEMS or df.id.tolist() != list(range(ITEMS)):
        raise ValueError("Unexpected Yelp row IDs")
    latest = {}
    with cache_path.open(encoding="utf-8") as f:
        for line in f:
            row = json.loads(line)
            latest[row["key"]] = row
    records = {(r["src"], r["id"]): r for r in latest.values()}
    sources = sorted(c for c in df.columns if c.startswith("src_"))
    if len(records) != len(latest) or records.keys() != {
            (src, i) for src in sources for i in range(ITEMS)}:
        raise ValueError("Cache does not contain exactly one current entry per source and item")
    data_key = sha(json.dumps([meta["dataset"], None, meta["split"], meta["revision"],
                               meta["shuffle_seed"], df.shuffled_position.tolist(), CLASSES]))
    summary = {}
    for src in sources:
        tag, prompt = src.removeprefix("src_").rsplit("_", 1)
        deployment = meta["deployments"][tag]
        generation = meta["gen"]
        src_key = sha(json.dumps([data_key, deployment["url"].rstrip("/"), deployment["model"],
                                  deployment["fingerprint"], deployment["server"],
                                  meta["prompts"][prompt], generation["temperature"],
                                  generation["seed"], generation["max_tokens"][prompt]]))
        status_col = "status_" + src[4:]
        before, after = Counter(), Counter()
        recovered = 0
        for i in range(ITEMS):
            row = records[src, i]
            if row["model"] != meta["deployments"][tag]["model"] or row["prompt"] != prompt:
                raise ValueError(f"Cache source mismatch at {src}, row {i}")
            if row["key"] != f"{src_key}:{i}:{sha(df.at[i, 'text'])}":
                raise ValueError(f"Cache key does not match provenance at {src}, row {i}")
            inputs = row["answer"], CLASSES, prompt, row["finish_reason"]
            original = parse(*inputs)
            if original != (df.at[i, src], df.at[i, status_col]):
                raise ValueError(f"Cache does not reproduce the strict result at {src}, row {i}")
            label, status = repair(row["answer"], prompt, row["finish_reason"])
            before[original[1]] += 1
            after[status] += 1
            if status != original[1]:
                recovered += 1
                df.at[i, src], df.at[i, status_col] = label, status
        summary[src] = dict(strict=dict(before), reparsed=dict(after), recovered=recovered,
                            unusable_share=(ITEMS - after["ok"]) / ITEMS)
    out.mkdir(parents=True, exist_ok=False)
    output = out / "yelp_2600_star_alias.csv"
    df.to_csv(output, index=False)
    provenance = dict(rule=RULE, strict_csv_sha256=original_hash,
                      cache_sha256=digest(cache_path), sources=summary)
    meta["parser_sensitivity"] = provenance
    meta["replication_sha256"] = digest(output)
    Path(str(output) + ".meta.json").write_text(json.dumps(meta, indent=2) + "\n")
    (out / "parser_diagnostic.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps(provenance, indent=2), flush=True)
    return output, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--development", required=True)
    parser.add_argument("--labels", type=Path, default=Path("yelp_2600.csv"))
    parser.add_argument("--cache", type=Path, default=Path("yelp_2600.csv.cache.jsonl"))
    parser.add_argument("--out", type=Path, default=Path("yelp_parser_sensitivity"))
    args = parser.parse_args()
    labels, summary = reparse(args.labels, args.cache, args.out)
    if any(row["unusable_share"] > .05 for row in summary.values()):
        raise SystemExit("The reparsed outputs still fail the frozen 5% quality gate")
    results = args.out / "evaluation"
    subprocess.run([sys.executable, "-u", str(Path(__file__).with_name("run_replication.py")),
                    "--development", args.development, "--labels", str(labels),
                    "--out", str(results)], check=True)
    decision_path = results / "decision.json"
    decision = json.loads(decision_path.read_text())
    strict_passed = all((ITEMS - row["strict"].get("ok", 0)) / ITEMS <= .05
                        for row in summary.values())
    decision.update(analysis=RULE, original_strict_quality_gate_passed=strict_passed)
    decision_path.write_text(json.dumps(decision, indent=2) + "\n")


if __name__ == "__main__":
    main()
