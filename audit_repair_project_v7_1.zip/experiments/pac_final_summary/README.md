# Final diagnostic tables

The reproduced directory contains tables generated from the supplied Yelp
diagnostics and the AG News CPU runs. Both analyses use inspected fixed
annotation pools. Preserve the original AG News cost-gate failure and the
strict-parser Yelp failure. The Yelp tables describe the star-alias
sensitivity analysis.

At 1,950 equal reviews on Yelp, grouped DS residual error was 4.86% versus
6.76% for prompt-wise DS. Swapping only the ranking reproduced that gap
to the displayed precision. At a common 3% PAC target, grouped DS cost
72.7 extra labels. At 5%, it saved 105.0 labels with 0.26 percentage points
higher observed final error. This supports a budget- and target-dependent
tradeoff on these pools.

To regenerate the tables, use the existing audit-repair Python environment:

```bash
python summarize.py --yelp /path/to/yelp_diagnostics.zip --out final_tables
```

The runner checks pairing, review cost accounting, and target-violation
flags. The included AG News inputs allow reproduction without refitting.
Use a fresh output directory. Seed-bootstrap intervals are pointwise
and conditional on each evaluated annotation pool.
