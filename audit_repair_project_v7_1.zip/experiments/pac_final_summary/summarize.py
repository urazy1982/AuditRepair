"""Validate diagnostic outputs and write paired study tables without refitting."""
import argparse
import io
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
FULL = ["grouped_labels_grouped_rank", "prompt_labels_prompt_rank",
        "grouped_labels_prompt_rank", "prompt_labels_grouped_rank"]
TARGETS = [.01, .02, .03, .05]


def interval(delta, resamples):
    clusters = delta.groupby(level="seed").mean().to_numpy()
    lo, hi = np.quantile(clusters[resamples].mean(axis=1), [.025, .975])
    return float(lo), float(hi)


def read_pair(read, prefix):
    return (pd.read_csv(io.BytesIO(read(prefix + "/comparison.csv"))),
            json.loads(read(prefix + "/manifest.json")))


def summarize(dataset, equal, equal_meta, pac, pac_meta):
    if equal_meta["labels_sha256"] != pac_meta["labels_sha256"] or equal_meta["items"] != pac_meta["items"]:
        raise ValueError("Equal-budget and PAC runs use different inputs")
    n = equal_meta["items"]
    if n != 2600 or pac_meta["pac_draws"] != 1000 or pac_meta["alpha"] != .1:
        raise ValueError("Expected the fixed 2,600-item, 1,000-draw protocol")
    if sorted(pac.target.unique()) != TARGETS or set(pac.method) != {"grouped", "prompt"} or set(equal.arm) != set(FULL):
        raise ValueError("Unexpected targets or arms")
    if not (pac.calibration + pac.threshold).eq(pac.expert_total).all():
        raise ValueError("Review costs do not reconcile")
    if not pac.violation.eq(pac.error > pac.target).all():
        raise ValueError("Error violation counts do not reconcile")
    if any(not df.error.between(0, 1).all() for df in (equal, pac)):
        raise ValueError("Invalid error rates")
    if not pac.expert_total.between(0, n).all() or not equal.review_labels.between(0, n).all():
        raise ValueError("Invalid review counts")
    eq = equal.pivot(index=["seed", "review_labels"], columns="arm", values="error")
    cost = pac.pivot(index=["seed", "rep", "target"], columns="method",
                     values=["expert_total", "error", "violation"])
    expected_seeds = set(range(20))
    if (eq.isna().any().any() or cost.isna().any().any()
            or set(equal.seed) != expected_seeds or set(pac.seed) != expected_seeds
            or len(cost) != 800 or set(pac.rep) != set(range(10))
            or len(eq) != 180):
        raise ValueError("Incomplete paired design")
    if not eq.xs(n, level="review_labels").eq(0).all().all():
        raise ValueError("Full expert review should leave no error")
    resamples = np.random.default_rng(20261112).integers(0, 20, (5000, 20))
    budget_rows, frontier_rows = [], []
    for budget, values in eq.groupby(level="review_labels"):
        grouped, prompt, labels_only, rank_only = (values[arm] for arm in FULL)
        lo, hi = interval(grouped - prompt, resamples)
        budget_rows.append(dict(dataset=dataset, review_labels=budget,
                                prompt_error=prompt.mean(), grouped_error=grouped.mean(),
                                grouped_minus_prompt_pp=100 * (grouped - prompt).mean(),
                                lower_pp=100 * lo, upper_pp=100 * hi,
                                labels_only_delta_pp=100 * (labels_only - prompt).mean(),
                                rank_only_delta_pp=100 * (rank_only - prompt).mean()))
    for target, values in cost.groupby(level="target"):
        dc = values["expert_total"].grouped - values["expert_total"].prompt
        de = values["error"].grouped - values["error"].prompt
        cl, ch = interval(dc, resamples)
        el, eh = interval(de, resamples)
        frontier_rows.append(dict(dataset=dataset, target=target,
                                  prompt_labels=values["expert_total"].prompt.mean(),
                                  grouped_labels=values["expert_total"].grouped.mean(),
                                  delta_labels=dc.mean(), lower_labels=cl, upper_labels=ch,
                                  delta_error_pp=100 * de.mean(),
                                  lower_error_pp=100 * el, upper_error_pp=100 * eh,
                                  prompt_violations=int(values["violation"].prompt.sum()),
                                  grouped_violations=int(values["violation"].grouped.sum())))
    return budget_rows, frontier_rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--yelp", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    with ZipFile(args.yelp) as z:
        yelp = summarize("Yelp", *read_pair(z.read, "yelp_equal_budget"),
                         *read_pair(z.read, "yelp_frontier"))
    ag = summarize("AG News", *read_pair(lambda name: (ROOT / name).read_bytes(), "agnews_equal_budget"),
                   *read_pair(lambda name: (ROOT / name).read_bytes(), "agnews_frontier"))
    budgets, frontier = (pd.DataFrame(a + b) for a, b in zip(ag, yelp))
    args.out.mkdir(parents=True, exist_ok=False)
    budgets.to_csv(args.out / "equal_budget.csv", index=False)
    frontier.to_csv(args.out / "pac_frontier.csv", index=False)
    text = (
        "Post-hoc diagnostics on fixed annotation pools\n"
        "Negative differences favor grouped DS. Error differences are percentage points.\n"
        "Intervals are pointwise seed-bootstrap intervals, conditional on each pool.\n\n"
        + budgets.round(4).to_string(index=False) + "\n\n"
        + frontier.round(4).to_string(index=False) + "\n"
    )
    (args.out / "report.txt").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
