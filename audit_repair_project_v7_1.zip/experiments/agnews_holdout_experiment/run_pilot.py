"""Pilot: does certified group repair beat Dawid-Skene updated with the same audits?

Usage
  python run_pilot.py --sim                          # simulated annotators (default config)
  python run_pilot.py --labels labels.csv        # real LLM labels from annotate_llm.py
Options: --budgets 200 400 800 --seeds 20 --alpha 0.05 --out results.csv
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import pandas as pd

from audit_repair.core import (dawid_skene, majority_vote, run_ds_same_audits,
                               run_ds_uncertainty, run_group_repair)
from audit_repair.simulate import SCENARIOS, simulate


def load_labels(path):
    """Labels are class indices into the declared vocabulary (-1 = no valid label).
    K comes from <path>.meta.json ("classes") when present, else max index + 1, so a class
    missing from the sample (or non-contiguous ids) never shrinks K."""
    import os
    df = pd.read_parquet(path) if path.endswith(".parquet") else pd.read_csv(path)
    src = [c for c in df.columns if c.startswith("src_")]
    L = df[src].to_numpy().astype(int)
    gold = df["gold"].to_numpy().astype(int)
    meta = path + ".meta.json"
    if os.path.exists(meta):
        K = len(json.load(open(meta))["classes"])
    else:
        K = int(max(gold.max(), L.max())) + 1
    if gold.min() < 0 or gold.max() >= K or L.max() >= K or L.min() < -1:
        raise ValueError(f"labels outside the declared vocabulary of {K} classes")
    return L, gold, K, src


def one_run(L, gold, K, budget, alpha, seed, ref_share=0.0, pre_stream=None, tie_stream=None):
    rng = np.random.default_rng(tie_stream if tie_stream is not None else seed)  # MV tie-breaks only
    err = lambda y: float((y != gold).mean())
    rows = []
    rows.append(("majority_vote", err(majority_vote(L, K, rng)), {}))
    rows.append(("ds_no_audit", err(dawid_skene(L, K).argmax(1)), {}))
    y, info = run_ds_uncertainty(L, K, gold, budget)
    rows.append(("ds_uncertainty_audits", err(y), info))
    res = run_group_repair(L, K, gold, budget, alpha=alpha, ref_share=ref_share,
                           seed=pre_stream if pre_stream is not None else seed)
    for k in ("guarded", "unguarded"):
        y, info = res[k]
        rows.append((f"group_repair_{k}", err(y), info))
    y2, info2 = run_ds_same_audits(L, K, gold, res["guarded"][1]["audited_labels"])
    rows.append(("ds_same_audits", err(y2), info2))
    out = []
    for name, e, info in rows:
        out.append({"method": name, "budget": budget, "seed": seed, "error": e,
                    "audited": info.get("audited", 0), "repaired": info.get("repaired", 0),
                    "correct_to_incorrect": info.get("c2i", 0), "incorrect_to_correct": info.get("i2c", 0),
                    "groups_repaired": info.get("groups_repaired", 0),
                    "harmful_group_repairs": info.get("harmful_group_repairs", 0)})
    return out, rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--scenario", default="clear", help="clear | null | borderline (with --sim)")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--ref_share", type=float, default=0.0,
                    help="budget share for DS uncertainty audits before freezing the reference")
    ap.add_argument("--labels")
    ap.add_argument("--budgets", type=int, nargs="+", default=[200, 400, 800])
    ap.add_argument("--seeds", type=int, default=20)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--out", default="results.csv")
    a = ap.parse_args()

    results, t0 = [], time.time()
    for seed in range(a.seeds):
        # separate streams: data generation / item order vs. audit randomness
        ss_data, ss_pre, ss_mv = np.random.SeedSequence([20261030, seed]).spawn(3)
        if a.sim:
            L, gold = simulate(seed=ss_data, **SCENARIOS[a.scenario])
            K = int(gold.max()) + 1
        else:
            L, gold, K, _ = load_labels(a.labels)
            # real data: vary only the audit randomness via a permutation of item order
            perm = np.random.default_rng(ss_data).permutation(len(gold))
            L, gold = L[perm], gold[perm]
        for b in a.budgets:
            out, rows = one_run(L, gold, K, b, a.alpha, seed, a.ref_share, ss_pre, ss_mv)
            results += out
            if seed == 0 and b == a.budgets[0] and not a.quiet:
                for name, _, info in rows:
                    if info.get("log"):
                        print(f"\n[{name}] group decisions (seed 0, budget {b}):")
                        for g in info["log"]:
                            print("  ", json.dumps(g))
        print(f"seed {seed} done ({time.time() - t0:.0f}s)", flush=True)

    df = pd.DataFrame(results)
    df.to_csv(a.out, index=False)
    summ = (df.groupby(["budget", "method"])
              .agg(error=("error", "mean"), error_sd=("error", "std"),
                   audited=("audited", "mean"), repaired=("repaired", "mean"),
                   c2i=("correct_to_incorrect", "mean"), i2c=("incorrect_to_correct", "mean"),
                   harmful_group_repairs=("harmful_group_repairs", "sum"),
                   groups_repaired=("groups_repaired", "sum"))
              .round(4))
    print("\n", summ.to_string())


if __name__ == "__main__":
    main()
