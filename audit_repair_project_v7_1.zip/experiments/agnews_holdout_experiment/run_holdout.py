"""Validate the annotated holdout and run the frozen paired evaluation."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
import pandas as pd

from holdout_protocol import development, digest, metadata, prompt_key, RULE


def validate_holdout(dev, dev_meta, path, development_hash):
    meta = metadata(path)
    for key in ("dataset", "revision", "split", "shuffle_seed", "classes", "deployments",
                "prompts", "gen", "retry_policy"):
        if meta[key] != dev_meta[key]:
            raise ValueError(f"Holdout metadata differs in {key}")
    if (meta["selection_rule"] != RULE or meta["development_sha256"] != development_hash
            or meta["holdout_sha256"] != digest(path)):
        raise ValueError("Holdout selection or file identity mismatch")
    holdout = pd.read_csv(path, keep_default_na=False)
    if len(holdout) != meta["n"] or len(holdout) < 400:
        raise ValueError("Holdout row count mismatch")
    positions = holdout.shuffled_position.to_numpy()
    if not (positions >= len(dev)).all() or not (np.diff(positions) > 0).all():
        raise ValueError("Holdout positions overlap development or are out of order")
    keys = holdout.text.map(prompt_key)
    if keys.duplicated().any() or keys.isin(set(dev.text.map(prompt_key))).any():
        raise ValueError("Duplicate model-visible text found")
    expected = {c for c in dev.columns if c.startswith("src_")}
    if {c for c in holdout.columns if c.startswith("src_")} != expected:
        raise ValueError("Holdout source columns differ from development")
    bad = {c: float((holdout["status_" + c[4:]] != "ok").mean()) for c in sorted(expected)}
    if any(fraction > .05 for fraction in bad.values()):
        raise ValueError(f"Annotation quality gate failed: {bad}")
    return holdout, bad


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--development", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    dev, dev_meta = development(args.development)
    dev_hash = digest(args.development)
    holdout, bad = validate_holdout(dev, dev_meta, args.labels, dev_hash)
    subprocess.run([sys.executable, "-u", str(Path(__file__).with_name("run_pac_budget.py")),
                    "--labels", args.labels, "--out", str(args.out), "--seeds", "20",
                    "--pac-samples", "1000", "--pac-reps", "10"], check=True)
    results = pd.read_csv(args.out / "comparison.csv")
    reference, candidate = "prompt_ds_pac_only", "grouped_ds_pac_only"
    costs = results.pivot(index=["seed", "rep"], columns="method", values="expert_total")
    errors = results.pivot(index=["seed", "rep"], columns="method", values="error")
    saving = (costs[reference] - costs[candidate]).groupby(level="seed").mean().to_numpy()
    error_delta = (errors[candidate] - errors[reference]).groupby(level="seed").mean().to_numpy()
    rng = np.random.default_rng(20261105)
    bootstrap = rng.integers(0, len(saving), size=(5000, len(saving)))
    saving_ci = np.quantile(saving[bootstrap].mean(axis=1), [.025, .975])
    error_ci = np.quantile(error_delta[bootstrap].mean(axis=1), [.025, .975])
    minimum_saving = .01 * len(holdout)
    violations = results.groupby("method").violated.sum().astype(int).to_dict()
    checks = dict(practical_saving=bool(saving.mean() >= minimum_saving),
                  paired_saving_interval_above_zero=bool(saving_ci[0] > 0),
                  error_margin=bool(error_ci[1] <= .005),
                  observed_primary_runs_within_target=violations[reference] == violations[candidate] == 0)
    decision = dict(development_sha256=dev_hash, holdout_sha256=digest(args.labels),
                    items=len(holdout), primary="grouped versus prompt DS with zero pre-audits",
                    unusable_by_source=bad, minimum_saving=minimum_saving,
                    mean_saving=float(saving.mean()), saving_ci=saving_ci.tolist(),
                    max_error_margin=.005, error_delta=float(error_delta.mean()),
                    error_delta_ci=error_ci.tolist(), observed_violations=violations,
                    checks=checks, advance=all(checks.values()))
    text = json.dumps(decision, indent=2) + "\n"
    (args.out / "decision.json").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
