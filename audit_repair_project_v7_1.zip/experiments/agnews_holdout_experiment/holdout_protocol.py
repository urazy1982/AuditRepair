"""Frozen AG News development identity and disjoint selection rule."""
import hashlib
import json
from pathlib import Path
import unicodedata

import pandas as pd

DEVELOPMENT_SHA256 = "b3a87b9b80d531e579634a64aca6239f58c640e851cbd8ac3ce849a2961d1f59"
REVISION = "eb185aade064a813bc0b7f42de02595523103ca4"
RULE = "pinned_test_tail_excluding_normalized_prompt_text_duplicates"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def metadata(path):
    return json.loads(Path(str(path) + ".meta.json").read_text())


def development(path):
    if digest(path) != DEVELOPMENT_SHA256:
        raise ValueError("Expected the frozen 5,000-row development CSV")
    meta = metadata(path)
    expected = dict(dataset="fancyzhx/ag_news", revision=REVISION, split="test",
                    n=5000, shuffle_seed=0)
    if any(meta[key] != value for key, value in expected.items()):
        raise ValueError("Development metadata does not match the frozen protocol")
    return pd.read_csv(path, keep_default_na=False), meta


def prompt_key(text):
    return " ".join(unicodedata.normalize("NFKC", text[:2000]).casefold().split())


def select_positions(texts, dev_texts):
    size = len(dev_texts)
    if list(texts[:size]) != list(dev_texts):
        raise ValueError("Pinned dataset prefix does not match development text and order")
    seen = {prompt_key(text) for text in dev_texts}
    positions = []
    for position in range(size, len(texts)):
        key = prompt_key(texts[position])
        if key not in seen:
            positions.append(position)
            seen.add(key)
    if len(positions) < 400:
        raise ValueError("Holdout needs at least 400 items for the secondary arm")
    return positions
