"""Collect the frozen AG News holdout with the development deployments and prompts."""
from __future__ import annotations

from pathlib import Path

from deployment import inspect_deployment, verify_manifest
from holdout_protocol import development, digest, RULE, REVISION, select_positions

import argparse
import asyncio
import hashlib
import json
import os
import re

import pandas as pd

DATASETS = {
    # name: (HF id, config, split, text field, label field, class names)
    "ag_news": ("fancyzhx/ag_news", None, "test", "text", "label",
                ["World", "Sports", "Business", "Sci/Tech"]),
    "trec": ("CogComp/trec", None, "train", "text", "coarse_label",
             ["Abbreviation", "Entity", "Description", "Human", "Location", "Numeric"]),
    "yelp": ("Yelp/yelp_review_full", None, "test", "text", "label",
             ["1 star", "2 stars", "3 stars", "4 stars", "5 stars"]),
    "imdb": ("stanfordnlp/imdb", None, "test", "text", "label", ["negative", "positive"]),
}

PROMPTS = {
    "direct": ("Classify the text into exactly one of these categories: {labels}.\n"
               "Text: {text}\nAnswer with the category name only, nothing else."),
    "reason": ("You are an expert annotator. Possible categories: {labels}.\n"
               "Read the text, think about which category fits best, then end your reply with a "
               "final line of exactly the form 'Answer: <category>'.\nText: {text}"),
}
GEN = {"temperature": 0.0, "seed": 0, "max_tokens": {"direct": 16, "reason": 512}}
SHUFFLE_SEED = 0


def sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def _norm(s: str) -> str:
    return re.sub(r"[\s\.\"'`*:;!]+$", "", re.sub(r"^[\s\"'`*]+", "", s)).strip().lower()


def parse(answer: str, names: list[str], prompt: str, finish_reason: str | None) -> tuple[int, str]:
    """Strict parsing. Returns (label index or -1, status)."""
    if answer is None or answer == "":
        return -1, "failed"
    if finish_reason == "length":
        return -1, "truncated"
    lookup = {nm.lower(): i for i, nm in enumerate(names)}
    if prompt == "direct":
        cand = _norm(answer)
    else:
        lines = [ln for ln in answer.strip().splitlines() if ln.strip()]
        m = re.fullmatch(r"\s*\**\s*answer\s*:\s*(.+?)\s*", lines[-1], re.I) if lines else None
        if not m:
            return -1, "invalid"
        cand = _norm(m.group(1))
    return (lookup[cand], "ok") if cand in lookup else (-1, "invalid")


async def ask(client, model, prompt, sem, max_tokens):
    from openai import APIError
    async with sem:
        for attempt in range(4):
            try:
                r = await client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}],
                    temperature=GEN["temperature"], max_tokens=max_tokens, seed=GEN["seed"])
                ch = r.choices[0]
                return ch.message.content or "", ch.finish_reason
            except APIError:
                await asyncio.sleep(2 ** attempt)
        return "", "error"


async def server_fingerprint(url: str, model: str) -> dict:
    """What the endpoint itself reports about the served model (vLLM: id, root, max_model_len)."""
    try:
        from openai import AsyncOpenAI
        cl = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        models = await cl.models.list()
        for mdl in models.data:
            d = mdl.model_dump() if hasattr(mdl, "model_dump") else dict(mdl)
            if d.get("id") == model:
                return {k: d.get(k) for k in ("id", "root", "max_model_len", "owned_by") if d.get(k) is not None}
    except Exception as e:  # endpoint without /models: rely on the user fingerprint
        return {"unavailable": type(e).__name__}
    return {"not_listed": True}


async def main_async(a):
    from datasets import load_dataset
    from openai import AsyncOpenAI
    from huggingface_hub import HfApi

    dev, dev_meta = development(a.development)
    hf, cfg, split, tf, lf, names = DATASETS["ag_news"]
    revision = REVISION
    if HfApi().dataset_info(hf, revision=revision).sha != revision:
        raise ValueError("Pinned AG News revision could not be verified")
    raw = load_dataset(hf, cfg, split=split, revision=revision).shuffle(seed=SHUFFLE_SEED)
    positions = select_positions(list(raw[tf]), dev.text.tolist())
    ds = raw.select(positions)
    a.n = len(positions)
    df = pd.DataFrame({"id": range(a.n), "shuffled_position": positions, "text": ds[tf], "gold": ds[lf]})
    text_hash = [sha(t) for t in df.text]
    data_key = sha(json.dumps([hf, cfg, split, revision, SHUFFLE_SEED, positions, names]))
    prompt_hashes = {k: sha(v) for k, v in PROMPTS.items()}
    if (dev_meta["prompts"] != prompt_hashes or dev_meta["gen"] != GEN
            or dev_meta["classes"] != names
            or dev_meta["retry_policy"] != {"transport_failures": True, "unusable_outputs": False}):
        raise ValueError("Prompt, generation, class or retry protocol differs from development")
    instances = {}
    a.source = []
    for tag, expected in dev_meta["deployments"].items():
        container = "ar_vllm_" + tag
        recorded = json.loads((Path(a.deployment_dir) / f"deployment_{container}.json").read_text())
        actual = inspect_deployment(container)
        fp = verify_manifest(actual, recorded)
        if fp != expected["fingerprint"] or actual["model"] != expected["model"]:
            raise ValueError(f"Deployment {tag} differs from development")
        instances[container] = actual
        a.source.append(f"{tag}={expected['url']}@{expected['model']}#{fp}")
    print(f"Selected {a.n} disjoint holdout items from the pinned test split", flush=True)

    cache_path = a.out + ".cache.jsonl"
    cache, stale = {}, 0
    if os.path.exists(cache_path):
        with open(cache_path) as cached_file:
            for line in cached_file:
                r = json.loads(line)
                cache[r["key"]] = r
    sem = asyncio.Semaphore(a.concurrency)
    labels = ", ".join(names)
    used_keys = set()

    plan, deployments = [], {}
    for spec in a.source:
        tag, rest = spec.split("=", 1)
        url, model = rest.split("@", 1)
        model, _, user_fp = model.partition("#")
        if not user_fp:
            print(f"WARNING: no deployment fingerprint for '{tag}'. Add '#rev=...,quant=...' "
                  f"to the --source spec for reproducible source identity.", flush=True)
        server_fp = await server_fingerprint(url, model)
        deployments[tag] = {"url": url, "model": model, "fingerprint": user_fp, "server": server_fp}
        for pname, tmpl in PROMPTS.items():
            mt = GEN["max_tokens"][pname]
            src_key = sha(json.dumps([data_key, url.rstrip("/"), model, user_fp, server_fp,
                                      sha(tmpl), GEN["temperature"], GEN["seed"], mt]))
            keys = [f"{src_key}:{i}:{text_hash[i]}" for i in range(a.n)]
            used_keys.update(keys)
            plan.append((f"src_{tag}_{pname}", url, model, pname, tmpl, mt, keys))
    if deployments != dev_meta["deployments"]:
        raise ValueError("Endpoint fingerprints differ from development")
    # refuse incompatible resumes BEFORE spending any queries
    stale = sum(1 for k in cache if k not in used_keys)
    if stale and not a.allow_stale_cache:
        raise SystemExit(f"{stale} cached answers in {cache_path} come from a different dataset/model/"
                         f"prompt/settings. Use a new --out path, or --allow-stale-cache to ignore them.")

    for src, url, model, pname, tmpl, mt, keys in plan:
        client = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        def needs_query(i):
            if keys[i] not in cache:
                return True
            rec = cache[keys[i]]
            # Transport failures are recoverable. Model-format failures are experimental
            # outcomes, retained unless the caller explicitly opts into resampling them.
            if rec.get("finish_reason") == "error":
                return True
            status = parse(rec["answer"], names, pname, rec["finish_reason"])[1]
            return getattr(a, "retry_unusable", False) and status != "ok"
        todo = [i for i in range(a.n) if needs_query(i)]
        print(f"{src}: {len(todo)} to query ({a.n - len(todo)} cached)", flush=True)
        for start in range(0, len(todo), 500):
            chunk = todo[start:start + 500]
            outs = await asyncio.gather(*[
                ask(client, model, tmpl.format(labels=labels, text=df.text[i][:2000]), sem, mt)
                for i in chunk])
            with open(cache_path, "a") as cache_f:
                for i, (ans, fin) in zip(chunk, outs):
                    rec = {"key": keys[i], "src": src, "id": i, "model": model, "prompt": pname,
                           "answer": ans, "finish_reason": fin}
                    cache[keys[i]] = rec
                    cache_f.write(json.dumps(rec) + "\n")
        parsed = [parse(cache[k]["answer"], names, pname, cache[k]["finish_reason"]) for k in keys]
        df[src] = [p[0] for p in parsed]
        df["status_" + src[4:]] = [p[1] for p in parsed]
        ok = df["status_" + src[4:]] == "ok"
        print(f"  {src}: accuracy on valid {(df[src][ok] == df.gold[ok]).mean():.3f}; "
              f"status {df['status_' + src[4:]].value_counts().to_dict()}", flush=True)

    for container, before in instances.items():
        if inspect_deployment(container) != before:
            raise ValueError("Deployment changed during holdout annotation")
    df.to_csv(a.out, index=False)
    with open(a.out + ".meta.json", "w") as metadata_file:
        json.dump({"dataset": hf, "revision": str(revision), "split": split, "n": a.n,
                   "shuffle_seed": SHUFFLE_SEED, "classes": names, "deployments": deployments,
                   "selection_rule": RULE, "development_sha256": digest(a.development),
                   "holdout_sha256": digest(a.out),
                   "retry_policy": {"transport_failures": True, "unusable_outputs": getattr(a, "retry_unusable", False)},
                   "prompts": {k: sha(v) for k, v in PROMPTS.items()}, "gen": GEN},
                  metadata_file, indent=2)
    print("saved", a.out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--development", required=True)
    ap.add_argument("--deployment-dir", required=True)
    ap.add_argument("--concurrency", type=int, default=32)
    ap.set_defaults(allow_stale_cache=False, retry_unusable=False)
    ap.add_argument("--out", required=True)
    asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    main()
