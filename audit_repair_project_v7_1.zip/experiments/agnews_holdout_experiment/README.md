# Frozen AG News holdout evaluation

The development sweep favored 1,000 PAC draws among the three counts
tested. The primary comparison is grouped DS versus prompt-wise DS
with zero preprocessing audits. Both methods use 1,000 PAC draws,
a 3% final error target, and PAC alpha 0.10. The secondary comparison
uses the same 400 prompt-wise DS uncertainty audits in both arms.

The holdout uses the remaining rows of the pinned AG News test split.
The collector checks that the first 5,000 shuffled rows exactly match
the development CSV in order. It excludes later items whose normalized
first 2,000 characters duplicate a development item or an earlier
holdout item. It also verifies model deployments, prompt hashes, and
generation settings against the development sidecar. The remaining
pool is smaller than development, so 1,000 draws represent a larger
fraction of the pool.

## Decision rule

Use 20 fresh preprocessing seeds and ten paired PAC repetitions per
seed. Simulate expert review with the dataset gold labels. Compare total
unique expert labels, with calibration and threshold review reported
separately. The primary arm advances if:

- Mean savings are at least 1% of the holdout size, equivalent to 50
  labels per 5,000 items.
- The lower endpoint of the 95% paired seed-bootstrap interval for
  savings exceeds zero.
- The upper endpoint of the corresponding interval for grouped minus
  prompt-wise final error is at most 0.5 percentage points.
- Both primary arms have zero observed runs above the 3% error target.

These are development-to-holdout decision criteria. The bootstrap
quantifies algorithmic variability conditional on this AG News pool.
Observed threshold violations are diagnostics.

## Windows and WSL commands

Extract this archive into `C:\auditrepair\agnews_holdout_experiment`.
Start the pinned servers from the existing runner in PowerShell. Use
the same HF_TOKEN environment setting as the development run.

```powershell
Set-Location C:\auditrepair\v6_4_2
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-AuditRepair.ps1 `
  -Stages Serve -ServerTimeoutMin 60 `
  -VllmImage "vllm/vllm-openai@sha256:d825baf9ce4b1b6bfc5ecc7b79880c7e6748c65a72d697ce3d47607aafa84c6e" `
  -RevisionA "b25037543e9394b818fdfca67ab2a00ecc7dd641" `
  -RevisionB "db1f81ad4b8c7e39777509fac66c652eb0a52f91"
wsl -d Ubuntu-24.04
```

Collect labels in WSL. The collector resumes from its holdout cache
when run again with the same inputs.

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/agnews_holdout_experiment
python -u annotate_holdout.py \
  --development "$HOME/audit_repair/ag_news_5000.csv" \
  --deployment-dir "$HOME/audit_repair" \
  --out ag_news_holdout.csv
```

After collection succeeds, run the CPU evaluation. The runner verifies
file identity, disjoint positions and text, source provenance, and the
existing 5% unusable-output limit for each source.

```bash
python -u run_holdout.py \
  --development "$HOME/audit_repair/ag_news_5000.csv" \
  --labels ag_news_holdout.csv \
  --out holdout_results

python -m zipfile -c holdout_results.zip holdout_results \
  ag_news_holdout.csv ag_news_holdout.csv.meta.json
```

Review `holdout_results/decision.json`, the detailed paired results,
and `report.txt`. Use a fresh output directory for each evaluation.
Stop the two inference containers when annotation has completed.

```bash
docker stop ar_vllm_a ar_vllm_b
```
