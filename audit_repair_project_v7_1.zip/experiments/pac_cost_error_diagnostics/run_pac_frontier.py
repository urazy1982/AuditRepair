"""Estimate cost and observed error across a fixed grid of PAC targets."""
import pandas as pd

from audit_repair.pac import pac_labels
from diagnostic_common import arguments, inputs, paired_fits, seed_interval

TARGETS = [.01, .02, .03, .05]


def main():
    args = arguments(__doc__, pac=True)
    labels, gold, classes, sources = inputs(args, pac_draws=1000, alpha=.1,
                                             targets=TARGETS, pac_reps=args.pac_reps,
                                             pre_audits=0)
    rows = []
    for seed, pac_seed, y, fits in paired_fits(args, labels, gold, classes, sources):
        streams = pac_seed.spawn(args.pac_reps)
        for method, (prediction, uncertainty) in fits.items():
            for eps in TARGETS:
                for rep, stream in enumerate(streams):
                    _, result = pac_labels(prediction, uncertainty, y, eps=eps, alpha=.1,
                                           m=1000, seed=stream)
                    rows.append(dict(seed=seed, rep=rep, method=method, target=eps,
                                     expert_total=result["expert_new"],
                                     calibration=result["calibration_new"],
                                     threshold=result["threshold_new"], error=result["error"],
                                     violation=result["error"] > eps))
        print(f"Completed seed {seed + 1}/{args.seeds}", flush=True)
    results = pd.DataFrame(rows)
    results.to_csv(args.out / "comparison.csv", index=False)
    summary = results.groupby(["target", "method"])[
        ["expert_total", "calibration", "threshold", "error", "violation"]].mean()
    summary.to_csv(args.out / "summary.csv")
    contrasts = []
    for target, rows_at_target in results.groupby("target"):
        for metric in ["expert_total", "error"]:
            p = rows_at_target.pivot(index=["seed", "rep"], columns="method", values=metric)
            contrasts.append(dict(target=target, metric=metric,
                                  **seed_interval(p.grouped - p.prompt)))
    paired = pd.DataFrame(contrasts)
    paired.to_csv(args.out / "paired_grouped_minus_prompt.csv", index=False)
    report = summary.round(5).to_string() + "\n\n" + paired.round(5).to_string(index=False) + "\n"
    (args.out / "report.txt").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
