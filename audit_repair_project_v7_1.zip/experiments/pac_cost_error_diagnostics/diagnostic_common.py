"""Inputs, pairing, and output helpers for the two diagnostic experiments."""
import argparse
import json
from pathlib import Path

import numpy as np

from audit_repair.core import dawid_skene
from holdout_protocol import development, digest, metadata
from run_holdout import validate_holdout
from run_pac_budget import encode_models
from run_pilot import load_labels
from run_replication import validate_replication

ROOTS = {"agnews": 20261104, "yelp": 20261109}
EXPECTED_HASHES = {
    "agnews": "be7a8e71e0f004761f21910be684a4f24a2e1a1c1f7e5ae4bf2899c783812b82",
    "yelp": "d892551dbeba09bbe7377a45370c6f90a166c94e4c5ef7a3aeab799dfabe7e83",
}


def arguments(description, *, pac=False):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--dataset", choices=ROOTS, required=True)
    parser.add_argument("--development", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", type=int, default=20)
    if pac:
        parser.add_argument("--pac-reps", type=int, default=10)
    args = parser.parse_args()
    if args.seeds < 1 or getattr(args, "pac_reps", 1) < 1:
        parser.error("seeds and repetitions must be positive")
    return args


def inputs(args, **settings):
    dev, dev_meta = development(args.development)
    dev_hash, labels_hash = digest(args.development), digest(args.labels)
    if labels_hash != EXPECTED_HASHES[args.dataset]:
        raise ValueError("Expected the exact evaluated annotation CSV for this dataset")
    validator = validate_holdout if args.dataset == "agnews" else validate_replication
    validator(dev, dev_meta, args.labels, dev_hash)
    meta = metadata(args.labels)
    if args.dataset == "yelp" and meta.get("parser_sensitivity", {}).get("rule") != "posthoc_star_spelling_alias_v1":
        raise ValueError("Expected the Yelp star-alias reparse and its metadata")
    labels, gold, classes, sources = load_labels(args.labels)
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = dict(analysis="posthoc_diagnostic", dataset=meta["dataset"],
                    labels_sha256=labels_hash, development_sha256=dev_hash,
                    parser_sensitivity=meta.get("parser_sensitivity"),
                    items=len(gold), seeds=args.seeds, root_seed=ROOTS[args.dataset],
                    numpy=np.__version__, **settings)
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return labels, gold, classes, sources


def paired_fits(args, labels, gold, classes, sources):
    for seed in range(args.seeds):
        data_seed, _, pac_seed = np.random.SeedSequence([ROOTS[args.dataset], seed]).spawn(3)
        perm = np.random.default_rng(data_seed).permutation(len(gold))
        L, y = labels[perm], gold[perm]
        joint, _ = encode_models(L, sources, classes)
        prompt = dawid_skene(L, classes)
        grouped = dawid_skene(L, classes, observation_codes=joint)
        fits = {name: (post.argmax(1), 1 - post.max(1))
                for name, post in [("prompt", prompt), ("grouped", grouped)]}
        yield seed, pac_seed, y, fits


def seed_interval(delta):
    means = delta.groupby(level="seed").mean().to_numpy()
    rng = np.random.default_rng(20261111)
    boot = rng.choice(means, (5000, len(means)), replace=True).mean(axis=1)
    return dict(mean=float(delta.mean()), lower=float(np.quantile(boot, .025)),
                upper=float(np.quantile(boot, .975)))
