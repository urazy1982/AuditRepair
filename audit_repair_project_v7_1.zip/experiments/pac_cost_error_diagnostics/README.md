# Cost and error diagnostics after the Yelp sensitivity analysis

The original Yelp parser failed its quality gate. The spelling-only
reparse recovered 1,033 responses. In the post-hoc evaluation,
grouped DS cost 72.715 more expert labels at the fixed 3% PAC target
and had 0.908 percentage points lower observed final error. The
cost gate failed. These two diagnostics investigate that tradeoff
on the inspected AG News and Yelp pools.

## Step 1. Match the review budget

Compare empirical final error when each method receives exactly the
same number of reviews. Review the most uncertain items first and
simulate perfect review with the gold labels. Seeded row order breaks
ties. This step measures the rankings directly. PAC calibration is
used in Step 2.

The four arms cross prompt-wise and grouped DS label predictions with
their uncertainty rankings. Comparing the arms at each common budget
shows whether a difference follows the predicted labels or the review
order. The grid covers 0%, 40%, 60%, 70%, 75%, 80%, 85%, 90% and 100%
of the pool.

## Step 2. Measure the PAC cost and error frontier

Compare both original aggregation pipelines at final-error targets
of 1%, 2%, 3% and 5%. Use 1,000 PAC draws, alpha 0.10, zero pre-audits,
20 seeds and ten paired repetitions per seed. Report distinct
calibration and threshold-review labels, final error and observed
target violations. The 3% row anchors the comparison to the earlier
evaluation. Seed-bootstrap intervals are pointwise and conditional
on each fixed annotation pool.

Interpretation: if the Yelp error gap shrinks at equal budgets,
the extra review is part of the explanation. If it persists, use the
crossed arms to see which part of the pipeline carries the gap.
Use the PAC frontier to assess the price of lower error at shared
targets. Preserve the original failed cost gate. A revised primary
claim requires a separately declared evaluation on fresh data.

## Run in WSL

Extract into `C:\auditrepair\pac_cost_error_diagnostics`. Both steps
reuse saved annotations on CPU. Keep each CSV and its metadata
sidecar together. The runners check the exact input hashes from
the evaluated files.

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/pac_cost_error_diagnostics

python -u run_equal_budget.py --dataset yelp \
  --development "$HOME/audit_repair/ag_news_5000.csv" \
  --labels /mnt/c/auditrepair/yelp_pac_replication/yelp_parser_sensitivity/yelp_2600_star_alias.csv \
  --out yelp_equal_budget

python -u run_pac_frontier.py --dataset yelp \
  --development "$HOME/audit_repair/ag_news_5000.csv" \
  --labels /mnt/c/auditrepair/yelp_pac_replication/yelp_parser_sensitivity/yelp_2600_star_alias.csv \
  --out yelp_frontier
```

For AG News, change `--dataset` to `agnews` and use
`/mnt/c/auditrepair/agnews_holdout_experiment/ag_news_holdout.csv`
as `--labels`. Use distinct output directories for every run.

```bash
python -m zipfile -c yelp_diagnostics.zip yelp_equal_budget yelp_frontier
```
