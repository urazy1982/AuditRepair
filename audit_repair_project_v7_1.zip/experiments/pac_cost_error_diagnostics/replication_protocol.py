"""Frozen cross-corpus sample and evaluation settings."""
from holdout_protocol import prompt_key

DATASET = "Yelp/yelp_review_full"
REVISION = "c1f9ee939b7d05667af864ee1cb066393154bf85"
CLASSES = ["1 star", "2 star", "3 stars", "4 stars", "5 stars"]
ITEMS = 2600
SHUFFLE_SEED = 20261108
RULE = "first_2600_unique_prompt_texts_after_fixed_test_shuffle"


def select_positions(texts, development_texts):
    seen = {prompt_key(text) for text in development_texts}
    selected = []
    for i, text in enumerate(texts):
        key = prompt_key(text)
        if key not in seen:
            seen.add(key)
            selected.append(i)
            if len(selected) == ITEMS:
                return selected
    raise ValueError("Pinned test split has too few eligible items")
