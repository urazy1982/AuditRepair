"""Compare errors after matched review budgets and cross labels with rankings."""
import itertools

import numpy as np
import pandas as pd

from diagnostic_common import arguments, inputs, paired_fits, seed_interval

FRACTIONS = [0, .40, .60, .70, .75, .80, .85, .90, 1]


def main():
    args = arguments(__doc__)
    labels, gold, classes, sources = inputs(args, review_fractions=FRACTIONS)
    rows = []
    for seed, _, y, fits in paired_fits(args, labels, gold, classes, sources):
        for pred_method, rank_method in itertools.product(fits, repeat=2):
            prediction, uncertainty = fits[pred_method][0], fits[rank_method][1]
            # Seeded input permutation breaks equal-score ties consistently.
            priority = np.argsort(-uncertainty, kind="stable")
            errors = prediction != y
            remaining = errors.sum() - np.r_[0, errors[priority].cumsum()]
            for fraction in FRACTIONS:
                budget = round(fraction * len(y))
                rows.append(dict(seed=seed, review_labels=budget, fraction=fraction,
                                 arm=f"{pred_method}_labels_{rank_method}_rank",
                                 error=remaining[budget] / len(y)))
    results = pd.DataFrame(rows)
    results.to_csv(args.out / "comparison.csv", index=False)
    summary = results.groupby(["review_labels", "arm"]).error.mean().unstack()
    summary.to_csv(args.out / "mean_errors.csv")
    contrasts = []
    for budget, rows_at_budget in results.groupby("review_labels"):
        p = rows_at_budget.pivot(index="seed", columns="arm", values="error")
        for label, delta in [
            ("full_grouped_minus_prompt", p.grouped_labels_grouped_rank - p.prompt_labels_prompt_rank),
            ("change_labels_at_prompt_rank", p.grouped_labels_prompt_rank - p.prompt_labels_prompt_rank),
            ("change_rank_at_prompt_labels", p.prompt_labels_grouped_rank - p.prompt_labels_prompt_rank),
        ]:
            contrasts.append(dict(review_labels=budget, contrast=label, **seed_interval(delta)))
    paired = pd.DataFrame(contrasts)
    paired.to_csv(args.out / "paired_error_differences.csv", index=False)
    report = summary.round(5).to_string() + "\n\n" + paired.round(5).to_string(index=False) + "\n"
    (args.out / "report.txt").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
