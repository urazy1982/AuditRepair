"""Exploratory pool-size and PAC draw-count diagnostic after the frozen holdout."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from audit_repair.core import dawid_skene
from audit_repair.pac import pac_labels
from holdout_protocol import development, digest
from run_holdout import validate_holdout
from run_pac_budget import encode_models
from run_pilot import load_labels


def oracle_coverage(prediction, uncertainty, gold):
    """Gold-evaluated threshold coverage, with score ties kept together."""
    _, bins = np.unique(uncertainty, return_inverse=True)
    sizes = np.bincount(bins).cumsum()
    errors = np.bincount(bins, weights=(prediction != gold)).cumsum()
    return int(sizes[errors <= .03 * len(gold)].max(initial=0))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--development", required=True)
    parser.add_argument("--holdout", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--pac-reps", type=int, default=10)
    args = parser.parse_args()
    if min(args.seeds, args.pac_reps) < 1:
        parser.error("seeds and repetitions must be positive")
    dev, dev_meta = development(args.development)
    holdout, _ = validate_holdout(dev, dev_meta, args.holdout, digest(args.development))
    dev_L, dev_y, classes, columns = load_labels(args.development)
    hold_L, hold_y, hold_classes, hold_columns = load_labels(args.holdout)
    if classes != hold_classes or columns != hold_columns or len(holdout) >= len(dev):
        raise ValueError("Expected a smaller holdout with the same classes and source layout")
    pools = {"matched_development": (dev_L, dev_y), "holdout": (hold_L, hold_y)}
    n = len(holdout)
    samples = sorted({round(n * 1000 / len(dev)), 1000})
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = dict(development_sha256=digest(args.development), holdout_sha256=digest(args.holdout),
                    status="exploratory_after_frozen_holdout", items_per_pool=n, pac_samples=samples,
                    seeds=args.seeds, pac_reps=args.pac_reps, root_seed=20261104,
                    subsample_seed=20261106, alpha_final=.1, epsilon=.03,
                    pre_audits=0, numpy=np.__version__, pandas=pd.__version__)
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    rows, selection = [], []
    for seed in range(args.seeds):
        data_seed, _, pac_seed = np.random.SeedSequence([20261104, seed]).spawn(3)
        perm = np.random.default_rng(data_seed).permutation(n)
        subset_rng = np.random.default_rng(np.random.SeedSequence([20261106, seed]))
        subset = np.sort(subset_rng.choice(len(dev), size=n, replace=False))
        selection.extend(dict(seed=seed, original_row=int(i)) for i in subset)
        streams = pac_seed.spawn(args.pac_reps)
        for pool, (labels, gold) in pools.items():
            order = subset[perm] if pool == "matched_development" else perm
            L, y = labels[order], gold[order]
            joint, _ = encode_models(L, columns, classes)
            for method, observations in [("prompt", None), ("grouped", joint)]:
                post = dawid_skene(L, classes, observation_codes=observations)
                prediction, uncertainty = post.argmax(1), 1 - post.max(1)
                ideal = oracle_coverage(prediction, uncertainty, y)
                for sample in samples:
                    for rep, stream in enumerate(streams):
                        _, result = pac_labels(prediction, uncertainty, y, eps=.03, alpha=.1,
                                               m=sample, seed=stream)
                        rows.append(dict(pool=pool, method=method, seed=seed, rep=rep, sample=sample,
                                         raw_error=float(np.mean(prediction != y)),
                                         oracle_auto_labels=ideal,
                                         calibration=result["calibration_new"],
                                         threshold=result["threshold_new"],
                                         expert_total=result["expert_new"], error=result["error"],
                                         violation=result["error"] > .03))
        print(f"Completed seed {seed + 1}/{args.seeds}", flush=True)
    results = pd.DataFrame(rows)
    results.to_csv(args.out / "comparison.csv", index=False)
    pd.DataFrame(selection).to_csv(args.out / "matched_development_rows.csv", index=False)
    summary = results.groupby(["pool", "sample", "method"])[
        ["expert_total", "calibration", "threshold", "raw_error", "oracle_auto_labels",
         "error", "violation"]].mean()
    summary.to_csv(args.out / "summary.csv")
    pivot = results.pivot(index=["seed", "rep"], columns=["pool", "sample", "method"],
                          values="expert_total")
    rng = np.random.default_rng(20261107)
    bootstrap = rng.integers(0, args.seeds, size=(5000, args.seeds))
    estimates = []
    for pool in pools:
        for sample in samples:
            saving = pivot[pool, sample, "prompt"] - pivot[pool, sample, "grouped"]
            clusters = saving.groupby(level="seed").mean().to_numpy()
            lo, hi = np.quantile(clusters[bootstrap].mean(axis=1), [.025, .975])
            estimates.append(dict(pool=pool, sample=sample, mean_saving=saving.mean(),
                                  lower=lo, upper=hi))
    savings = pd.DataFrame(estimates)
    savings.to_csv(args.out / "paired_savings.csv", index=False)
    report = (summary.round(4).to_string() + "\n\n" + savings.round(3).to_string(index=False)
              + "\n\nSeed-bootstrap intervals are conditional on these annotation files.\n")
    (args.out / "report.txt").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
