# PAC transfer diagnostic

The frozen evaluation on 2,600 unseen AG News items produced a mean
saving of 7.14 labels with zero preprocessing audits. The required
saving was 26 labels and the paired interval included zero. Preserve
that decision for the frozen experiment.

This CPU diagnostic compares the same zero-audit methods on two
pools of equal size. One is the holdout. The other is a new random
subsample of the development file for each seed. It tests 1,000 draws
and the draw count proportional to 1,000 draws per 5,000 development
items. For the uploaded holdout that count is 520.

Each comparison uses paired PAC streams. The smaller draw count
uses the prefix of the larger draw count. The seed-bootstrap
intervals describe algorithm and subsample variation conditional
on the two annotation files. Subsamples overlap across seeds.

The oracle coverage diagnostic measures the largest prefix in
uncertainty order that has at most 3% of the pool mislabeled, with
score ties kept together. It uses gold labels for retrospective
analysis. The PAC selection uses its usual sampled evidence.

## Next-stage decision

Inspect the four paired savings estimates and the cost breakdown.
Differences between draw counts within a pool describe sensitivity
to calibration density. Differences between equal-size pools at
the same draw count indicate sensitivity to the annotated items.
Interpret these as exploratory results from inspected data.

If the diagnostic suggests a useful setting, freeze that setting
and repeat the comparison on a separately annotated corpus.
Evaluate matched budgets and apply a cost-and-error gate declared
before accessing its results. Keep the original AG News holdout
result in the study record.

## Run in WSL

Extract this ZIP into `C:\auditrepair\pac_transfer_diagnostic`.
Open WSL with `wsl -d Ubuntu-24.04` in PowerShell and run:

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/pac_transfer_diagnostic

python -u run_transfer_diagnostic.py \
  --development "$HOME/audit_repair/ag_news_5000.csv" \
  --holdout /mnt/c/auditrepair/agnews_holdout_experiment/ag_news_holdout.csv \
  --out transfer_results
```

Keep the metadata sidecar beside each CSV. The script validates file
identity and disjointness before fitting. Use a fresh output directory
for each run. It writes `comparison.csv`, `summary.csv`,
`paired_savings.csv`, `matched_development_rows.csv`, `manifest.json`
and `report.txt`. The included `frozen_holdout_decision.json` records
the decision before this exploratory diagnostic.

```bash
python -m zipfile -c transfer_results.zip transfer_results
```
