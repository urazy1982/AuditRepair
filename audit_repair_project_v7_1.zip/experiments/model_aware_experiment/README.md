# Model-aware candidate ordering experiment

This exploratory CPU experiment uses the existing 5,000 AG News annotations.
It compares size ordering and model-aware ordering with a common certification
rule, DS uncertainty scores, a 400-label preprocessing budget, and a 3% PAC
error target. Each repair policy has a DS baseline refitted on its exact audits.
PAC alone provides the end-to-end cost benchmark.

For each candidate supported by one model, the model-aware policy scores the
fraction of group items for which both prompts of the other model agree with
the frozen reference label. Candidates supported by multiple models score zero.
Larger groups break score ties. The ordering uses source predictions and model
identity, with no access to gold labels beyond the existing charged warm-up.

The two policies share preprocessing and PAC seeds. Group sampling follows
each policy's traversal order. PAC comparisons use paired draws, and the
bootstrap resamples whole preprocessing seeds. The data have already informed
the policy design, so results are exploratory.

## Run on Windows with WSL

Extract the ZIP into `C:\auditrepair\model_aware_experiment`.
Enter WSL from PowerShell with `wsl -d Ubuntu-24.04`, then run:

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/model_aware_experiment
python -u run_ordering_experiment.py \
  --labels "$HOME/audit_repair/ag_news_5000.csv" \
  --out ordering_results
```

Use a fresh output directory for each run. Keep the CSV and its metadata
sidecar together in the existing annotation directory.

The output contains the input hash and settings in `manifest.json`, per-run
cost and error in `comparison.csv`, group-level decisions in
`certificates.jsonl`, and audit burden in `group_summary.csv`.
Audits to first certificate count newly purchased group labels through that
certificate, excluding warm-up labels. The metric is missing when a run
certifies no repair, so read it alongside the certification count.

```bash
python -m zipfile -c ordering_results.zip ordering_results
```
