"""Paired exploratory comparison on a fixed, already annotated AG News file."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from audit_repair.core import dawid_skene, run_group_repair
from audit_repair.pac import pac_labels
from run_pilot import load_labels


def model_aware_key(labels, columns):
    # The annotator names columns src_<deployment>_<prompt>.
    identities = np.array([name.removeprefix("src_").rsplit("_", 1)[0] for name in columns])
    models = {name: np.flatnonzero(identities == name) for name in np.unique(identities)}
    if len(models) != 2 or any(len(indices) != 2 for indices in models.values()):
        raise ValueError("Expected two deployments with two prompt columns each")

    def key(group):
        dissenting_models = set(identities[list(group.source)])
        if len(dissenting_models) != 1:
            return 0.0, len(group.items)
        opposite = next(indices for name, indices in models.items()
                        if name not in dissenting_models)
        duplicate_reference = np.all(labels[np.ix_(group.items, opposite)] == group.cur, axis=1)
        return float(duplicate_reference.mean()), len(group.items)

    return key


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--pac-reps", type=int, default=10)
    args = parser.parse_args()
    if args.seeds < 1 or args.pac_reps < 1:
        parser.error("seeds and PAC repetitions must be positive")
    labels, gold, classes, columns = load_labels(args.labels)
    model_aware_key(labels, columns)  # Validate source layout before creating outputs.
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = dict(labels_sha256=hashlib.sha256(Path(args.labels).read_bytes()).hexdigest(),
                    sources=columns, items=len(gold), seeds=args.seeds, pac_reps=args.pac_reps,
                    root_seed=20261030, budget=400, ref_share=.3, min_size=30,
                    stop_after_fails=10, max_groups=10, alpha_repair=.05,
                    epsilon=.03, alpha_final=.1, pac_sample=500,
                    numpy=np.__version__, pandas=pd.__version__)
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    rows, summaries = [], []
    with (args.out / "certificates.jsonl").open("w") as certificates:
        for seed in range(args.seeds):
            data_seed, audit_seed, pac_seed = np.random.SeedSequence([20261030, seed]).spawn(3)
            order = np.random.default_rng(data_seed).permutation(len(gold))
            L, y = labels[order], gold[order]
            pac_streams = pac_seed.spawn(args.pac_reps)
            base = dawid_skene(L, classes)
            arms = [("pac_only", base.argmax(1), 1 - base.max(1), {})]
            for policy, rank in [("size", "size"), ("model_aware", model_aware_key(L, columns))]:
                prediction, info = run_group_repair(
                    L, classes, y, 400, ref_share=.3, stop_after_fails=10,
                    min_size=30, seed=audit_seed, order=rank)["guarded"]
                audits, post = info["audited_labels"], info["post"]
                uncertainty = 1 - post.max(1)
                arms.extend([(policy + "_repair", prediction, uncertainty, audits),
                             (policy + "_matched_ds", post.argmax(1), uncertainty, audits)])
                group_audits, first = 0, None
                for index, group in enumerate(info["log"], 1):
                    known = set(group["known_at_start"])
                    group_audits += sum(event["item"] not in known for event in group["audit_history"])
                    if group["guarded"] and first is None:
                        first = group_audits
                    record = dict(seed=seed, policy=policy, rank=index, **group,
                                  original_rows=order[group["members"]].tolist())
                    certificates.write(json.dumps(record) + "\n")
                summaries.append(dict(seed=seed, policy=policy, group_audits=group_audits,
                                      audits_to_first_certificate=first,
                                      certified=info["groups_repaired"],
                                      harmful=info["harmful_group_repairs"],
                                      propagated=info["repaired"], pre_audits=len(audits)))
            for method, prediction, uncertainty, audits in arms:
                for rep, stream in enumerate(pac_streams):
                    _, result = pac_labels(prediction, uncertainty, y, eps=.03, alpha=.1,
                                           m=500, already=audits, seed=stream)
                    rows.append(dict(seed=seed, rep=rep, method=method,
                                     pre_audits=len(audits), expert_total=len(audits)+result["expert_new"],
                                     error=result["error"], violated=result["error"] > .03))
            print(f"Completed seed {seed + 1}/{args.seeds}", flush=True)

    results, groups = pd.DataFrame(rows), pd.DataFrame(summaries)
    results.to_csv(args.out / "comparison.csv", index=False)
    groups.to_csv(args.out / "group_summary.csv", index=False)
    print(results.groupby("method")[["expert_total", "error", "violated"]].mean())
    print(groups.groupby("policy")[["group_audits", "audits_to_first_certificate",
                                    "certified", "harmful", "propagated"]].mean())
    paired = results.pivot(index=["seed", "rep"], columns="method", values="expert_total")
    rng = np.random.default_rng(20261030)
    for reference in ["size_repair", "model_aware_matched_ds", "pac_only"]:
        delta = paired["model_aware_repair"] - paired[reference]
        clusters = delta.groupby(level="seed").mean().to_numpy()
        draws = rng.choice(clusters, (5000, len(clusters)), replace=True).mean(axis=1)
        lo, hi = np.quantile(draws, [.025, .975])
        print(f"Model-aware repair minus {reference}: {delta.mean():.2f} labels "
              f"[{lo:.2f}, {hi:.2f}], cheaper in {(delta < 0).mean():.1%}")
    print("Intervals describe preprocessing and PAC variability on this fixed development file.")


if __name__ == "__main__":
    main()
