# PAC sample size diagnostic

The grouped DS pilot estimated a saving of about 10 labels with matched
preprocessing audits, with a paired interval that includes zero. This
experiment measures how much of the total labeling cost comes from the
PAC calibration sample and how much comes from reviewing items at or
above the selected uncertainty threshold.

## Stage plan

1. Run the development sweep at 500, 1,000 and 2,000 PAC draws. Compare
   prompt-wise DS and grouped DS, each with zero preprocessing audits
   and with the same 400 audits selected by prompt-wise DS. Hold the
   3% error target and 0.10 PAC error probability fixed.
2. Compare total unique labels and the cost components across draw
   counts. Use the lowest mean total cost of the prompt-wise DS + PAC
   arm with zero preprocessing audits to select a common draw count
   for the next stage. Break a tie in favor of fewer draws.
3. Freeze the input sampling rule, common draw count, baselines,
   stopping rules and minimum useful saving before evaluation on
   untouched annotations. Compare the methods under the common
   configuration. Keep the 5,000 development items separate from that
   evaluation. Evaluate cost and error together. A smaller pre-PAC
   error or an earlier repair certificate is a secondary outcome.

The four arms share item order and PAC seeds. At a given seed and
repetition, a smaller calibration sample uses the prefix of the
larger sample. Bootstrap intervals resample whole preprocessing seeds.
They describe variability on this fixed development file.

Counts simulate expert review by revealing existing gold labels.
Total cost is the sum of preprocessing labels, new distinct
calibration labels, and new threshold-review labels after removing
overlap. PAC draws are sampled with replacement, so the number of
draws can exceed the number of distinct calibration labels.

## Run in WSL

Extract the ZIP into `C:\auditrepair\pac_budget_experiment`.
Run `wsl -d Ubuntu-24.04` from PowerShell, then run:

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/pac_budget_experiment

python -u run_pac_budget.py \
  --labels "$HOME/audit_repair/ag_news_5000.csv" \
  --out pac_budget_results
```

The defaults are 20 preprocessing seeds and three PAC repetitions.
Use `--pac-reps 10` to match the original number of repetitions.
Use a fresh output directory on every run. Keep the CSV and its
metadata sidecar together.

`summary.csv` breaks down mean costs by method and sample size.
`paired_differences.csv` compares models at equal draw counts and
compares larger samples with the smallest sample for each arm.
`comparison.csv` contains individual results. The archive also
includes the shared audit indices, configuration manifest and report.

```bash
python -m zipfile -c pac_budget_results.zip pac_budget_results
```
