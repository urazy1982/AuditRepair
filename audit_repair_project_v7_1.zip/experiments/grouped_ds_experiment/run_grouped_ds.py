"""Compare prompt-wise and model-grouped Dawid–Skene with shared audit evidence."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from audit_repair.core import Oracle, dawid_skene, uncertainty_fill
from audit_repair.pac import pac_labels
from run_pilot import load_labels


def encode_models(labels, columns, classes):
    models = {}
    for index, column in enumerate(columns):
        model, _ = column.removeprefix("src_").rsplit("_", 1)
        models.setdefault(model, []).append(index)
    if len(models) != 2 or any(len(indices) != 2 for indices in models.values()):
        raise ValueError("Expected two models with two prompt columns each")
    codes = []
    for left, right in models.values():
        first, second = labels[:, left], labels[:, right]
        code = (first + 1) * (classes + 1) + second + 1
        code[(first == -1) & (second == -1)] = -1
        codes.append(code)
    return np.column_stack(codes), models


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--seeds", type=int, default=20)
    parser.add_argument("--pac-reps", type=int, default=10)
    args = parser.parse_args()
    if args.seeds < 1 or args.pac_reps < 1:
        parser.error("seeds and repetitions must be positive")
    L, gold, classes, columns = load_labels(args.labels)
    if len(gold) < 400:
        parser.error("the 400-label arm requires at least 400 items")
    joint, models = encode_models(L, columns, classes)
    args.out.mkdir(parents=True, exist_ok=False)
    manifest = dict(labels_sha256=hashlib.sha256(Path(args.labels).read_bytes()).hexdigest(),
                    sources=columns, model_columns=models, items=len(gold),
                    seeds=args.seeds, pac_reps=args.pac_reps, budget=400, root_seed=20261030,
                    epsilon=.03, alpha_final=.1, pac_sample=500, smooth=.01,
                    numpy=np.__version__, pandas=pd.__version__)
    (args.out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    rows, audit_rows = [], []
    for seed in range(args.seeds):
        data_seed, _, pac_seed = np.random.SeedSequence([20261030, seed]).spawn(3)
        order = np.random.default_rng(data_seed).permutation(len(gold))
        labels, y, model_codes = L[order], gold[order], joint[order]
        streams = pac_seed.spawn(args.pac_reps)
        oracle = Oracle(y, 400)
        evidence = {}
        prompt_post = uncertainty_fill(labels, classes, oracle, evidence)
        audit_rows.extend(dict(seed=seed, original_row=int(order[i])) for i in evidence)
        arms = [
            ("prompt_ds_pac_only", dawid_skene(labels, classes), {}),
            ("grouped_ds_pac_only", dawid_skene(labels, classes, observation_codes=model_codes), {}),
            ("prompt_ds_shared_audits", prompt_post, evidence),
            ("grouped_ds_shared_audits",
             dawid_skene(labels, classes, evidence, observation_codes=model_codes), evidence),
        ]
        for method, post, audits in arms:
            prediction, uncertainty = post.argmax(1), 1 - post.max(1)
            for rep, stream in enumerate(streams):
                _, result = pac_labels(prediction, uncertainty, y, eps=.03, alpha=.1,
                                       m=500, already=audits, seed=stream)
                rows.append(dict(seed=seed, rep=rep, method=method, pre_audits=len(audits),
                                 pre_pac_error=float(np.mean(prediction != y)),
                                 expert_total=len(audits) + result["expert_new"],
                                 error=result["error"], violated=result["error"] > .03))
        print(f"Completed seed {seed + 1}/{args.seeds}", flush=True)

    results = pd.DataFrame(rows)
    results.to_csv(args.out / "comparison.csv", index=False)
    pd.DataFrame(audit_rows).to_csv(args.out / "shared_audits.csv", index=False)
    summary = results.groupby("method")[["expert_total", "pre_pac_error", "error", "violated"]].mean()
    paired = results.pivot(index=["seed", "rep"], columns="method", values="expert_total")
    rng = np.random.default_rng(20261030)
    lines = [summary.to_string(), ""]
    for arm, reference in [
        ("grouped_ds_pac_only", "prompt_ds_pac_only"),
        ("grouped_ds_shared_audits", "prompt_ds_shared_audits"),
        ("grouped_ds_shared_audits", "prompt_ds_pac_only"),
    ]:
        delta = paired[arm] - paired[reference]
        clusters = delta.groupby(level="seed").mean().to_numpy()
        draws = rng.choice(clusters, (5000, len(clusters)), replace=True).mean(axis=1)
        lo, hi = np.quantile(draws, [.025, .975])
        lines.append(f"{arm} minus {reference}: {delta.mean():.2f} expert labels "
                     f"[{lo:.2f}, {hi:.2f}], cheaper in {(delta < 0).mean():.1%}")
    lines.append("Intervals describe variability on the fixed development file.")
    report = "\n".join(lines) + "\n"
    (args.out / "report.txt").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
