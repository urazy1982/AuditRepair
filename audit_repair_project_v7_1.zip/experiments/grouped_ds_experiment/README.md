# Model-grouped Dawid–Skene experiment

Compare the existing Dawid–Skene model, which assigns a confusion matrix to
each prompt, with a version that assigns a joint confusion matrix to each
model's pair of prompt outputs. The joint matrix represents agreement and
disagreement within a model. Each model contributes one likelihood factor.
The two models are assumed conditionally independent given the class.

Both variants initialize EM from the same prompt vote counts. A single missing
prompt is encoded as a missing component of the pair. A pair with both prompts
missing contributes no likelihood term.

Run both variants with zero preprocessing audits and again with the same
400 audits selected by the existing prompt-wise DS uncertainty policy.
For each seed, use the same item order and PAC draws across all four arms.
Count distinct expert labels across preprocessing and PAC, with a 3% final
error target. The report bootstraps whole seeds for paired cost differences.
This is an exploratory comparison on the development annotations.

## Run in WSL

Extract the ZIP into `C:\auditrepair\grouped_ds_experiment`. Enter WSL with
`wsl -d Ubuntu-24.04` and run:

```bash
source ~/audit_repair/.venv/bin/activate
cd /mnt/c/auditrepair/grouped_ds_experiment
python -u run_grouped_ds.py \
  --labels "$HOME/audit_repair/ag_news_5000.csv" \
  --out grouped_ds_results
```

Keep the input CSV and its metadata sidecar together. Choose a fresh output
directory on each run. Outputs include `comparison.csv`, `report.txt`,
`shared_audits.csv` with original zero-based row indices, and `manifest.json`
with the input hash, source layout, versions and settings.

```bash
python -m zipfile -c grouped_ds_results.zip grouped_ds_results
```
