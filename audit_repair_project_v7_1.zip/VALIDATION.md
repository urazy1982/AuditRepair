# v6.3 validation — 2026-10-31

Executed on CPU:

- `python -m unittest discover -v`: eleven tests for confidence-bound inversion,
  recovery from cached transport failures, preservation of successful/invalid outputs,
  explicit resampling, immutable dataset revisions, deployment mismatch detection,
  secret exclusion, stable fingerprints across identical verified deployments,
  detailed certificate replay and crossed ablations.
- The export integration test runs seven arms on one clear simulated dataset and one
  PAC repetition. All five original arms match the historical seed-0/repetition-0
  results exactly; both crossed arms are present. Exported bounds are reconstructed
  from audit observations and per-group alpha. A suffix-free output path is also tested.
- `python -u -m tests.test_betting`: enumeration, remainder Monte Carlo,
  false-rejection and power checks passed.

Original root-level experiment CSVs and summaries are historical v6.1 results.
No new full comparison or real annotation experiment is claimed.

PowerShell is unavailable here. The mocked-WSL test in `tests/test_runner.ps1` is
included in the runner's Test stage but has not been executed here. Docker inspection
was tested with mocked responses. Windows/WSL, live Docker, downloads and RTX 5090
inference require validation on the target workstation.

Run `powershell -NoProfile -File .\tests\test_runner.ps1` from the extracted package
for standalone runner helper checks; that test needs no GPU, Docker, WSL or network.

## v6.4 check (reviewer side)

- `python -m unittest discover -v`: 11 tests OK. `tests/test_betting.py`: all checks within bounds.
- `tests/test_runner.ps1` executed under PowerShell 7.4.6: passed.
- Full runner, all eight stages, against a mocked WSL/Docker/vLLM environment whose `docker inspect`
  returns real-shaped JSON: SUCCESS; no token in any collected file.
- Negative paths: Annotate after Stop, Annotate after an out-of-band container restart, and a
  `-RevisionA` that differs from the deployment all stop before querying; a clean re-Serve reuses
  all 2000 cached answers; `-Quant auto` against an `awq` cache is refused as stale (intended).
- Not testable here: Windows PowerShell 5.1 itself, real Docker/GPU, real Hugging Face API.

## v6.4.1 final review (current review environment)

- Independently reran all 11 Python regression tests: passed.
- Independently reran the complete betting/remainder suite: passed.
- Downloaded PowerShell 7.4.6 for this review and executed the runner helper tests: passed.
- Extended the helper tests with a real PowerShell child emitting stdout, stderr and
  nonzero exit codes: verified stdout isolation, credential redaction, exit-code
  propagation and restoration of ErrorActionPreference.
- Separately exercised the wrappers with a native shell stub: benign stderr succeeds,
  a failing command is detected, and a missing launcher is detected.
- Get-Process.Path was empty here; the Test stage now resolves child PowerShell from PSHOME.
- No live WSL/Docker/Hugging Face/GPU experiment was run. Windows PowerShell 5.1
  remains a target-side check. Earlier v6.4 mock-integration claims above are supplied
  upstream validation, not an independent rerun in this final review.

## v6.4.2 portable regression check

A user's WSL test reported failure while comparing fresh results against `certified_clear.csv` from a historical run. That assertion can be affected by NumPy/SciPy numerical changes and was not reproducible in the current review environment. The test now runs the five-arm original configuration with `--baseline-only` and the seven-arm configuration under the SAME Python dependencies, comparing all original result columns and the full serialized group-certificate export. The supplied historical results are preserved as research records, not used as portable exact-output test oracles. This is a test portability correction, NOT evidence that scientific computations across versions are identical. New live WSL/GPU validation remains necessary.
