# Real-data results (AG News, Yelp) — consolidated record

All real annotations come from two pinned vLLM deployments on the RTX 5090 (see `deployment/`):
Qwen2.5-7B-Instruct-AWQ (rev `b25037…`) and Llama-3.1-8B-Instruct-AWQ-INT4 (rev `db1f81…`), each with
a direct and a reasoning prompt, giving 4 sources. Expert review is simulated by revealing the dataset gold label.
All intervals are seed bootstraps conditional on one fixed annotation pool; they do not describe
generalization to other pools.

Folder map: `results/NN_*` = outputs as run on the workstation; `results/v7_cpu_rerun/` = the same
CPU analyses rerun with the v7 stable tie-break (see "Reproducibility fix"); `results/11_error_anatomy/` = new.

## 1. Annotation pools

| pool | N | K | source accuracy (a_direct, a_reason, b_direct, b_reason) | unusable outputs |
|---|---|---|---|---|
| AG News dev (`ag_news_5000`) | 5,000 | 4 | 0.775, 0.797, 0.787, 0.754 | ≤ 0.6% per source |
| AG News frozen holdout | 2,600 | 4 | 0.771, 0.805, 0.795, 0.759 | ≤ 0.6% |
| Yelp Review Full (star-alias reparse) | 2,600 | 5 | 0.620, 0.674, 0.656, 0.592 | ≤ 1.4% (strict parser failed its gate: 548 invalid for a_reason) |

## 2. Certified group repair (the original method)

| run | arms | outcome |
|---|---|---|
| AG News 500 (B=100, ε=0.05) | 7 | 0 groups certified in 20 seeds; guarded = DS-with-same-audits; cost ≈ PAC alone (352 vs 354) |
| AG News 5,000 (B=400, ε=0.03) | 7 | 0 groups certified in 20 seeds (6 tested per seed, all rejected/abstained); guarded 3,577 vs PAC alone 3,563 |
| AG News 5,000, stop-after-10 (post hoc) | 7 | Business→Sci/Tech (89 items) certified in 13/20 seeds as run (11/20 with the v7 tie-break), **0 harmful**; +19 [0, 58] vs DS-same-audits in both — exactly 0 in every seed except one (+388) |

Safety held on real data: harmful accepted repairs 0 in every run; the unguarded replay accepted 3 (500) and 1 (5,000) harmful repairs.

## 3. Why nothing (useful) gets certified — error anatomy (`results/11_error_anatomy`)

| pool | DS error | unanimous errors: all 4 responses valid and identical (invisible to disagreement-based candidate rules) | candidate groups | groups with positive oracle relabel gain |
|---|---|---|---|---|
| AG News dev | 17.3% | 321 / 866 (37.1%) | 12 | 1 (Business→Sci/Tech, n=89, gain +56) |
| AG News holdout | 16.6% | 182 / 432 (42.1%) | 8 | 1 (Business→Sci/Tech, n=48, gain +31) |
| Yelp | 32.5% | 295 / 845 (34.9%) | 11 | 1 (3→4 stars, n=43, gain +13) |

AG News errors are concentrated, as the paper assumed, but in a *label sink* (≈ 70% of DS errors are
predicted "Business"), not in a source-defined disagreement pattern. The largest split group
(Business with a World dissent, n=367) is 42% Business / 39% World / rest Sci/Tech: its errors have
no majority alternative, so no single relabel helps. The one beneficial group is 7th by size and
the default stop-after-6-failures rule never reaches it.

## 4. Gap to a retrospective oracle stopping benchmark

| pool (ε = 3%, 1,000 PAC draws, zero audits) | PAC cost, prompt DS | retrospective oracle stopping benchmark, same ranking | gap | realized final error |
|---|---|---|---|---|
| AG News dev | 3,470 (69%) | 2,246 (45%) | +1,224 (24% of pool) | 1.2% |
| AG News holdout | 1,965 (76%) | 1,150 (44%) | +815 (31%) | 1.0% |
| Yelp | 2,522 (97%) | 2,322 (89%) | +200 (8%) | 1.0% |

The benchmark uses gold labels to find where to stop along the uncertainty ranking; the deployed
procedure must certify its stopping point from sampled evidence. The gap is specific to this
configuration and does not establish how much a new method could save. The calibration sample alone uses 829–905 distinct expert labels. Every aggregation change tested
(group repair, grouped DS, model-aware ordering) moved cost by 2–73 labels, one to two orders of
magnitude below this gap.

## 5. Grouped (model-level) Dawid–Skene — frozen evaluations

| step | comparison | result | gate |
|---|---|---|---|
| dev sweep, 1,000 draws | grouped vs prompt DS, zero audits | −162 labels [−248, −78] | (selected the setting) |
| **AG News holdout (frozen)** | same | −7.1 [−30.9, 16.6]; error +0.01 pp | **fail** (needed ≥ 26 and CI > 0) |
| **Yelp replication (frozen, post-hoc parser)** | same | **+72.7** [66.4, 78.4] (more expensive); error −0.91 pp | **fail** |
| secondary, shared 400 audits | grouped vs prompt DS | dev −10.2 [−22.1, 1.8]; holdout −22.3 [−35.0, −9.4]; Yelp −33.7 [−38.1, −28.2] | not gated |

The dev-sweep saving (−162) shrank to −7 on fresh AG News: a selection effect from choosing the
configuration on the development pool. The frozen protocol caught it.

Equal-budget diagnostics (`10_cost_error_diagnostics`): on Yelp, grouped DS ranks errors better at
equal review budgets (residual error 4.86% vs 6.76% at 1,950 reviews; the gap comes from the ranking, not the labels), but PAC
converts this into a cost-vs-error trade-off that depends on the target (+73 labels at 3%, −105 at 5%).

## 6. Reproducibility fix in v7

`uncertainty_fill` selected audits with NumPy's default (unstable) `argsort`. Real pools have
thousands of exact uncertainty ties (unanimous items), so the audited set depended on the NumPy
build and CPU sort path: only 6% of shared-audit rows matched between the workstation and the
review machine. v7 uses a stable sort (ties broken by the seeded item order). Effect:
zero-audit arms and both frozen primary decisions are bit-identical; shared-audit arms move by a few
labels (e.g. dev grouped-minus-prompt −10.3 → −8.6) with unchanged conclusions.

## 7. Oracle-repair decomposition (`results/12_oracle_repair`, `experiments/oracle_repair`)

Same shortlist and paired PAC draws in every arm (seeds identical to `run_certified.py`, 100% of rows match);
extended search (stop after 10), B = 400, 500 draws, ε = 3%, 20 seeds × 10 reps. Mean expert labels:

| pool | PAC alone | DS, same audits | certified repair | oracle repairs, free | oracle, free, no audits | oracle, trusted (U = 0) |
|---|---|---|---|---|---|---|
| AG News dev | 3,563 | 3,579 | 3,598 | 3,579 | 3,563 | 3,709 (+131 [34, 269]) |
| AG News holdout | 1,942 | 1,942 | 1,942 | 1,942 | 1,942 | 1,942 (no beneficial group after warm-up) |
| Yelp | 2,538 | 2,591 | 2,591 | 2,591 | 2,538 | 2,577 (−14 [−20, −8]; final error 0.38% vs 0.04%) |

Free oracle repairs change cost by exactly 0 in every seed on every pool: the shortfall is not the cost of
discovering or certifying repairs. Repair candidates have source disagreement, and PAC reviews every item
with disagreement (it accepts only the ~2,400–2,600 near-certain items on AG News dev), so repaired labels are
always overwritten by experts.
