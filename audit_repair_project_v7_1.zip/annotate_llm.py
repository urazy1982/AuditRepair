"""Collect labels from several LLM "sources" (model x prompt) for a public dataset.

Works with any OpenAI-compatible endpoint (local vLLM or a hosted API).
Output CSV columns: id, text, gold, and per source
  src_<tag>_<prompt>        parsed label, -1 if not a valid label
  status_<tag>_<prompt>     ok | invalid | truncated | failed
so invalid/failed responses are never confused with classification mistakes.

Example (two models on vLLM, 2 prompts each = 4 sources):
  python annotate_llm.py --dataset ag_news --n 5000 \
      --source qwen=http://localhost:8000/v1@Qwen/Qwen2.5-7B-Instruct \
      --source llama=http://localhost:8001/v1@meta-llama/Llama-3.1-8B-Instruct \
      --out ag_news_labels.csv

Source spec:  tag=base_url@model[#fingerprint]
  fingerprint = free text you control, e.g. "rev=a1b2c3,quant=awq,tp=1,maxlen=8192".
  The script also queries <base_url>/models and adds what the server reports (id, root,
  max_model_len). Without --fingerprint text the run warns, because a model alias alone
  does not identify a checkpoint, quantization or serving configuration.

Cache: <out>.cache.jsonl. Every entry stores a provenance key built from dataset id,
revision, split, shuffle seed, the example's text hash, endpoint URL, model, deployment
fingerprint, prompt-template hash and generation settings. Entries whose key does not match the current run are never reused;
if any are found for the same output file, the run stops unless --allow-stale-cache is given.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re

import pandas as pd

DATASETS = {
    # name: (HF id, config, split, text field, label field, class names)
    "ag_news": ("fancyzhx/ag_news", None, "test", "text", "label",
                ["World", "Sports", "Business", "Sci/Tech"]),
    "trec": ("CogComp/trec", None, "train", "text", "coarse_label",
             ["Abbreviation", "Entity", "Description", "Human", "Location", "Numeric"]),
    "yelp": ("Yelp/yelp_review_full", None, "test", "text", "label",
             ["1 star", "2 stars", "3 stars", "4 stars", "5 stars"]),
    "imdb": ("stanfordnlp/imdb", None, "test", "text", "label", ["negative", "positive"]),
}

PROMPTS = {
    "direct": ("Classify the text into exactly one of these categories: {labels}.\n"
               "Text: {text}\nAnswer with the category name only, nothing else."),
    "reason": ("You are an expert annotator. Possible categories: {labels}.\n"
               "Read the text, think about which category fits best, then end your reply with a "
               "final line of exactly the form 'Answer: <category>'.\nText: {text}"),
}
GEN = {"temperature": 0.0, "seed": 0, "max_tokens": {"direct": 16, "reason": 512}}
SHUFFLE_SEED = 0


def sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def _norm(s: str) -> str:
    return re.sub(r"[\s\.\"'`*:;!]+$", "", re.sub(r"^[\s\"'`*]+", "", s)).strip().lower()


def parse(answer: str, names: list[str], prompt: str, finish_reason: str | None) -> tuple[int, str]:
    """Strict parsing. Returns (label index or -1, status)."""
    if answer is None or answer == "":
        return -1, "failed"
    if finish_reason == "length":
        return -1, "truncated"
    lookup = {nm.lower(): i for i, nm in enumerate(names)}
    if prompt == "direct":
        cand = _norm(answer)
    else:
        lines = [ln for ln in answer.strip().splitlines() if ln.strip()]
        m = re.fullmatch(r"\s*\**\s*answer\s*:\s*(.+?)\s*", lines[-1], re.I) if lines else None
        if not m:
            return -1, "invalid"
        cand = _norm(m.group(1))
    return (lookup[cand], "ok") if cand in lookup else (-1, "invalid")


async def ask(client, model, prompt, sem, max_tokens):
    from openai import APIError
    async with sem:
        for attempt in range(4):
            try:
                r = await client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}],
                    temperature=GEN["temperature"], max_tokens=max_tokens, seed=GEN["seed"])
                ch = r.choices[0]
                return ch.message.content or "", ch.finish_reason
            except APIError:
                await asyncio.sleep(2 ** attempt)
        return "", "error"


async def server_fingerprint(url: str, model: str) -> dict:
    """What the endpoint itself reports about the served model (vLLM: id, root, max_model_len)."""
    try:
        from openai import AsyncOpenAI
        cl = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        models = await cl.models.list()
        for mdl in models.data:
            d = mdl.model_dump() if hasattr(mdl, "model_dump") else dict(mdl)
            if d.get("id") == model:
                return {k: d.get(k) for k in ("id", "root", "max_model_len", "owned_by") if d.get(k) is not None}
    except Exception as e:  # endpoint without /models: rely on the user fingerprint
        return {"unavailable": type(e).__name__}
    return {"not_listed": True}


async def main_async(a):
    from datasets import load_dataset
    from openai import AsyncOpenAI
    from huggingface_hub import HfApi

    hf, cfg, split, tf, lf, names = DATASETS[a.dataset]
    revision = HfApi().dataset_info(hf, revision=a.revision).sha
    if not revision:
        raise ValueError("Could not resolve an immutable dataset revision")
    raw = load_dataset(hf, cfg, split=split, revision=revision)
    ds = raw.shuffle(seed=SHUFFLE_SEED).select(range(a.n))
    df = pd.DataFrame({"id": range(a.n), "text": ds[tf], "gold": ds[lf]})
    text_hash = [sha(t) for t in df.text]
    data_key = sha(json.dumps([hf, cfg, split, str(revision), SHUFFLE_SEED, a.n, names]))

    cache_path = a.out + ".cache.jsonl"
    cache, stale = {}, 0
    if os.path.exists(cache_path):
        with open(cache_path) as cached_file:
            for line in cached_file:
                r = json.loads(line)
                cache[r["key"]] = r
    sem = asyncio.Semaphore(a.concurrency)
    labels = ", ".join(names)
    used_keys = set()

    plan, deployments = [], {}
    for spec in a.source:
        tag, rest = spec.split("=", 1)
        url, model = rest.split("@", 1)
        model, _, user_fp = model.partition("#")
        if not user_fp:
            print(f"WARNING: no deployment fingerprint for '{tag}'. Add '#rev=...,quant=...' "
                  f"to the --source spec for reproducible source identity.", flush=True)
        server_fp = await server_fingerprint(url, model)
        deployments[tag] = {"url": url, "model": model, "fingerprint": user_fp, "server": server_fp}
        for pname, tmpl in PROMPTS.items():
            mt = GEN["max_tokens"][pname]
            src_key = sha(json.dumps([data_key, url.rstrip("/"), model, user_fp, server_fp,
                                      sha(tmpl), GEN["temperature"], GEN["seed"], mt]))
            keys = [f"{src_key}:{i}:{text_hash[i]}" for i in range(a.n)]
            used_keys.update(keys)
            plan.append((f"src_{tag}_{pname}", url, model, pname, tmpl, mt, keys))
    # refuse incompatible resumes BEFORE spending any queries
    stale = sum(1 for k in cache if k not in used_keys)
    if stale and not a.allow_stale_cache:
        raise SystemExit(f"{stale} cached answers in {cache_path} come from a different dataset/model/"
                         f"prompt/settings. Use a new --out path, or --allow-stale-cache to ignore them.")

    for src, url, model, pname, tmpl, mt, keys in plan:
        client = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        def needs_query(i):
            if keys[i] not in cache:
                return True
            rec = cache[keys[i]]
            # Transport failures are recoverable. Model-format failures are experimental
            # outcomes, retained unless the caller explicitly opts into resampling them.
            if rec.get("finish_reason") == "error":
                return True
            status = parse(rec["answer"], names, pname, rec["finish_reason"])[1]
            return getattr(a, "retry_unusable", False) and status != "ok"
        todo = [i for i in range(a.n) if needs_query(i)]
        print(f"{src}: {len(todo)} to query ({a.n - len(todo)} cached)", flush=True)
        for start in range(0, len(todo), 500):
            chunk = todo[start:start + 500]
            outs = await asyncio.gather(*[
                ask(client, model, tmpl.format(labels=labels, text=df.text[i][:2000]), sem, mt)
                for i in chunk])
            with open(cache_path, "a") as cache_f:
                for i, (ans, fin) in zip(chunk, outs):
                    rec = {"key": keys[i], "src": src, "id": i, "model": model, "prompt": pname,
                           "answer": ans, "finish_reason": fin}
                    cache[keys[i]] = rec
                    cache_f.write(json.dumps(rec) + "\n")
        parsed = [parse(cache[k]["answer"], names, pname, cache[k]["finish_reason"]) for k in keys]
        df[src] = [p[0] for p in parsed]
        df["status_" + src[4:]] = [p[1] for p in parsed]
        ok = df["status_" + src[4:]] == "ok"
        print(f"  {src}: accuracy on valid {(df[src][ok] == df.gold[ok]).mean():.3f}; "
              f"status {df['status_' + src[4:]].value_counts().to_dict()}", flush=True)

    df.to_csv(a.out, index=False)
    with open(a.out + ".meta.json", "w") as metadata_file:
        json.dump({"dataset": hf, "revision": str(revision), "split": split, "n": a.n,
                   "shuffle_seed": SHUFFLE_SEED, "classes": names, "deployments": deployments,
                   "retry_policy": {"transport_failures": True, "unusable_outputs": getattr(a, "retry_unusable", False)},
                   "prompts": {k: sha(v) for k, v in PROMPTS.items()}, "gen": GEN},
                  metadata_file, indent=2)
    print("saved", a.out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=list(DATASETS), default="ag_news")
    ap.add_argument("--revision", default=None, help="pin a HF dataset revision (commit hash)")
    ap.add_argument("--n", type=int, default=5000)
    ap.add_argument("--source", action="append", required=True, help="tag=base_url@model, repeatable")
    ap.add_argument("--concurrency", type=int, default=32)
    ap.add_argument("--allow-stale-cache", action="store_true")
    ap.add_argument("--retry-unusable", action="store_true",
                    help="explicitly resample invalid/truncated/empty outputs; changes the labeling protocol")
    ap.add_argument("--out", required=True)
    asyncio.run(main_async(ap.parse_args()))


if __name__ == "__main__":
    main()
