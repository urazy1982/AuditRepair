# Audit, Repair, or Abstain — v7 (merged: method, real-data experiments, results)

Real-data results and their interpretation: **`RESULTS.md`**. Annotation pools: `data/`.
Deployment manifests: `deployment/`. Follow-up experiments (each self-contained, CPU-only on the saved
pools): `experiments/`. Historical simulated v6.1 outputs: `results/simulated_v6_1/`.

## What changed in v7

- Merged the workstation package v6.4.2 and the eight follow-up experiment folders into one tree.
  The forked `audit_repair/core.py` and `pac.py` copies were unified (one is a strict superset;
  defaults unchanged, checked by bit-identical reruns).
- **Reproducibility fix:** `uncertainty_fill` now uses a stable sort. The unstable default sort made
  the audited set depend on the NumPy build/CPU when uncertainty scores tie (see RESULTS.md §6).
  All CPU analyses were rerun (`results/v7_cpu_rerun/`); both frozen decisions are unchanged.
- `requirements.txt` pins numpy 2.5.4 / pandas 3.1.0 (the workstation versions).
- Runner: `-ServerTimeoutMin` default 60 (first start downloads both models; the 20-min default
  failed). User-side Python now uses its own `HF_HOME` (`~/.cache/ar_hf_python`): the root-run
  vLLM containers had made `~/.cache/huggingface/hub/datasets--*` unwritable (PermissionError in Annotate).
- New `experiments/error_anatomy/error_anatomy.py` (unanimous-wrong errors, oracle gain of every
  candidate group, oracle review cost) and its outputs in `results/11_error_anatomy/`.


Question tested: does a certified group repair beat Dawid–Skene re-fit with exactly the same audited
labels, and how many expert labels does it save under an end-to-end PAC guarantee?

## Final pilot release: v6.4.1

No statistical algorithm or experiment setting was changed in this final review.
Runner checks now also exercise native stderr and exit codes using a real PowerShell child
process. Child PowerShell is resolved from PSHOME rather than relying on Get-Process.Path,
which returned an empty value in the review environment.

Start with the CPU checks from the directory containing the ZIP:

```powershell
$zip = (Resolve-Path .\audit_repair_project_v6_4_1.zip).Path
Expand-Archive $zip -DestinationPath .\audit_repair_v6_4_1 -Force
Set-Location .\audit_repair_v6_4_1
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-AuditRepair.ps1 -ZipPath $zip -Stages Setup,Test
```

After those checks succeed, with HF_TOKEN available in this PowerShell session and Docker
Desktop/WSL GPU support enabled, start the 500-item AG News pilot:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-AuditRepair.ps1 -Stages Serve,Annotate,Check,Certify,Stop,Collect
```

This uses the runner's default vLLM image (latest, with a reproducibility warning).
Use `-VllmImage` with your tested pinned tag or digest when available, and retain the
collected deployment manifests. The 500-item run checks the real pipeline; use `-Full`
for the later 5,000-item comparison. No further methodological expansion is needed
before this functional pilot. Send the resulting ZIP for analysis.

## What changed in v6.4 (runner robustness only)

- `Invoke-Wsl` / `Get-WslOutput` relax `ErrorActionPreference` while calling `wsl.exe`.
  Since v6.2, stderr is redirected (`2>&1`) for redaction; under Windows PowerShell 5.1 with
  `Stop`, the first stderr line (pip, datasets progress bars, warnings) became a terminating
  error. Success/failure is now decided by the exit code only.
- `Get-WslOutput` returns stdout only (stderr is printed separately), so a warning can no longer
  leak into the deployment fingerprint, and a failure message now includes the last output lines
  (e.g. "Running deployment differs from the recorded manifest; rerun Serve").
- The Test stage runs `tests/test_runner.ps1` in a child process with `-ExecutionPolicy Bypass`:
  scripts on `\\wsl.localhost` paths are treated as network files and are refused under RemoteSigned.
- No Python, statistics or results changed.

## What changed in v6.3

- The runner records a restricted deployment manifest from Docker after each server starts.
  Annotation verifies the running container ID, image ID, start time, restart count, model,
  immutable revision, quantization argument, context limit and endpoint port against that
  manifest before and after querying. A missing or mismatched manifest stops annotation.
  These are checks of trusted local configuration, not cryptographic weight attestation.
- `-Quant` now controls the actual `--quantization` launch argument; `auto` omits it
  and is recorded as automatic selection, not as an inferred numeric format.
- Dataset branches/tags are resolved to immutable commit hashes before loading; the actual
  resolved hash is stored in cache identity and metadata.
- Cached transport failures (`finish_reason=error`) are retried on resume. Successful
  responses and invalid/truncated/empty model outputs are retained. The optional annotation
  flag `--retry-unusable` resamples those outputs and records this protocol choice in metadata.
- `*_certificates.jsonl` contains every tested group's membership hash, member indices,
  mapping to original input rows, known indices at entry, ordered audit observations, allocated
  alpha, stopping reason, decisions and full-precision bound. `members` and `audit_history`
  use the seed's permuted dataset; `original_rows` and `audit_original_rows` map these to
  zero-based input rows (or original simulated rows). `true_remainder_gain` is an oracle-only
  evaluation diagnostic and never drives decisions.
- Two crossed ablations use the same audits and PAC draws: `repair_labels_ds_U+pac`
  uses repaired labels with DS ranking; `ds_labels_repair_U+pac` uses DS labels with
  repair-derived ranking. Compare these with `ds_same_audits+pac` and `guarded+pac`.
- The runner collects both deployment manifests and detailed certificate records.

Upgrade: use the v6.4.1 runner with `audit_repair_project_v6_4_1.zip` and run
`Setup,Test,Serve,Annotate,Check,Certify,Stop,Collect`. Older servers have no compatible
manifest: restart them with this runner. New deployment/dataset fingerprints intentionally
reject older annotation caches; use a new output path or explicitly opt into
`--allow-stale-cache` in the Python annotator (incompatible entries are ignored, never reused).
The original root-level CSVs and summaries are historical v6.1 results with five arms,
not reruns of the new seven-arm experiment. See `VALIDATION.md`.

## What changed in v6.2

- Redact the supplied Hugging Face token and `hf_...` tokens from WSL output and
  command-failure exceptions before logging. Sanitize collected server logs,
  `RUN_STATUS.txt`, and the completed transcript before building a results or diagnostics ZIP.
- Added `tests/test_runner.ps1`: parses the actual runner, loads only its helper
  functions, and mocks WSL to check redacted output/errors, exit-code propagation,
  and in-place log sanitation. It requires PowerShell, but no WSL, Docker, GPU, or network.
- Added four deterministic confidence-sequence regression tests for non-monotone
  grid rejections, sticky rejections, the zero bound, and remainder-gain subtraction.
- The runner's Test stage runs both new suites as well as the existing statistical checks.
- No annotation, repair, certification, or simulation algorithm changed; supplied
  simulation results are retained from v6.1.

Run the new Python checks with `python -m unittest tests.test_cs_regressions -v`.
On Windows run `powershell -NoProfile -File .\tests\test_runner.ps1` from the
extracted package, or run the usual runner with `-Stages Setup,Test`.
For the current release, keep the runner and ZIP together from v6.4.1.

## What changed in v6.1 (review of v6)

| # | Finding | Status |
|---|---|---|
| 1 | Runner could report success after Python failed inside `| tail` / `| tee` | **Fixed.** Every WSL command runs with `set -o pipefail`. A failure records the stage, writes `RUN_STATUS.txt`, produces `<out>_FAILED_diagnostics.zip` instead of a results zip, and exits with code 1. Tested: a Python crash inside `| tee` now fails the run |
| 2 | Group diagnostics CSV not collected | **Fixed.** `certified_<tag>_groups.csv` is in the bundle |
| 3 | Grid inversion of the confidence sequence needed a justification | **Changed the construction so a short proof exists** (docstring of `WorLowerCS`): lower(t) = the grid point just below the smallest never-rejected one. Only the test at the smallest grid point ≥ μ must be valid, which Ville's inequality gives; no monotonicity across grid points is needed. The previous "largest rejected" rule would have needed monotonicity. Numbers are unchanged in all tests and simulations |
| 3b | "Fixed before any audit" is inaccurate with warm-up | **Reworded:** groups and shortlist are fixed after the warm-up and before any group-certification sampling |
| 4 | Borderline result understated | **Reworded:** +19 labels [14, 24] is a small but detectable cost disadvantage |
| 5 | Scope of guarantees | **Reworded:** "beneficial" is defined at the repair-stage acceptance point; the joint claim is 1 − (α_repair + α_final) = 85% with defaults while final-error control alone stays at 90%; the matched-evidence replay is an ablation, not a substitute for learned-correction + PAC or the PAC router |

## What changed in v6 (methodological review)

| # | Finding | Status |
|---|---|---|
| 1 | The safeguard tested the whole group's gain, but a repair changes only the **unaudited remainder** (audited items already get expert labels). In a 55/45 group the old rule accepted in 4000/4000 runs and 59% of acceptances harmed the remainder | **Fixed.** `WorLowerCS`: time-uniform lower confidence sequence for the group mean (WoR betting test inverted over a grid). Accept iff the bound on the remainder's total gain, N·L_t − Σ_audited d_i, is > 0. Exact enumeration (N ≤ 7): no miscoverage. Harmful-acceptance rate in Monte Carlo ≤ 2% at α = 5% |
| 2 | Adaptive choices not covered by optional stopping (overlapping groups, labels measured against outdated references) | **Fixed by design.** Groups are now fixed and **disjoint** (`candidate_groups_disjoint`): one predefined replacement label per item, grouped by (current label, replacement, dissenting sources); shortlist ordered by size and fixed after warm-up, before group-certification sampling; uniform random order within a group; audits stop at half a group |
| 3 | Final error guarantee does not follow from repair benefit | Design is freeze → fresh PAC; `run_certified.py --alpha_repair` reports the joint level 1 − (α_repair + α_final). The written argument remains provisional until stated as a proof |
| 4 | Certified baselines have different guarantees | Stated in the review doc; cost comparisons use the same PAC stage for every arm |
| 5 | Need "same candidates, no safeguard, same PAC" baseline | Already present as `unguarded+pac` (matched-evidence replay); now described that way |
| 6 | Reporting | Group-stage diagnostics added (`*_groups.csv`): candidates tested, repaired, abstained, group-phase audits, group sizes, harmful acceptances |

A side effect of fix 2: with the earlier heuristic ordering, the most useful group (one dissenting source, so DS gives the alternative low probability) fell off the shortlist and the mechanism disappeared; ordering by size restores it. Ordering remains a design choice to report.

## What changed in v5 (reporting refinements)

| # | Finding | Status |
|---|---|---|
| 1 | Zero observed failures produced a degenerate `[0, 0]` bootstrap interval | **Fixed.** Reported as "0/N observed failures across D clusters; bootstrap interval degenerate, not informative about unseen failures" |
| 2 | Real-data repetitions re-use one annotation file | **Fixed reporting.** In `--labels` mode the clusters are named "preprocessing realizations of one fixed annotation file", with a printed note that they do not measure generalization across datasets or source configurations |
| 3 | Group guarantee wording | **Fixed** (below and in `run_group_repair` docstring): a false-certification guarantee over the shortlist |
| — | Small real pilot | `run_certified.py --min_size` added; recommended small-pilot settings below |

Status of verification: the reviewed defects are resolved and focused regression checks pass (exact-enumeration test of the betting test, budget, vocabulary, cache-identity and stream-separation checks). These checks are not an exhaustive proof of correctness.

## What changed in v4 (third review)

| # | Finding | Status |
|---|---|---|
| 1 | PAC seed `100000·seed + r` collided with the preprocessing/simulator seed (seed 0, rep 0) | **Fixed.** `SeedSequence([root, dataset]).spawn(3)` gives separate streams for data generation/item order, preprocessing, and PAC; PAC repetitions are children of the PAC stream, shared across methods (paired comparison) but never with data or preprocessing. Same separation in `run_pilot.py` |
| 2 | Pooled Clopper–Pearson over 20 datasets × 10 repetitions ignored the nested design | **Fixed reporting.** Per-method failure counts per dataset, and 95% **cluster bootstrap** CIs that resample datasets (repetitions stay together) for costs, failure rates and paired cost differences. Failure counts are diagnostics; validity rests on the proof below |
| 3 | Win rate comparator unspecified | Now reported against each DS arm separately **and** against the better DS arm per run |

Remaining caveat from the review: deployment identity still depends on an accurate user fingerprint; `/models` metadata may not reveal a changed checkpoint or quantization.

## What changed in v3 (second review)

| # | Finding | Status |
|---|---|---|
| 1 | Guarded trajectory excluded items that only the unguarded ablation repaired | **Fixed.** The guarded run excludes only its own repairs; the unguarded rule is a pure replay on the guarded evidence and never steers allocation |
| 2 | Cache key omitted endpoint and checkpoint identity | **Fixed.** Key includes endpoint URL, a user fingerprint (`tag=url@model#rev=...,quant=...`) and what the server reports at `/models` (vLLM: id, root, max_model_len); warning when no fingerprint is given. Tested: same alias on two endpoints is queried separately |
| 3 | `ref_share + group_share` could exceed the budget | **Fixed.** Group allowance = `group_share` of the budget left after warm-up; shares validated; no query when the budget is exhausted |
| 4 | K from observed gold classes (crash on `{0, 2}`) | **Fixed.** K from `<labels>.meta.json` "classes" (now written by `annotate_llm.py`), else max index + 1; out-of-vocabulary labels rejected |
| — | 20 runs cannot support a 90% guarantee | `run_certified.py --pac_reps R` repeats the PAC randomness R times per annotation dataset (reporting revised in v4) |

## Why the PAC guarantee still holds after preprocessing

PAC Labels treats the data, predictions Ŷ and uncertainties U as fixed; its probability is over its own draws only. Our preprocessing (DS fits, audits, repairs) produces Ŷ, U and a set A of items whose gold label is known (Ŷ_i = Y_i on A). It never sees PAC's draws, which are generated afterwards with a separate random seed. Conditional on everything the preprocessing produced, Ŷ and U are fixed and PAC's draws i_j ~ Unif[n] are independent of them, so the samples 1[Ŷ_ij ≠ Y_ij]·1[U_ij ≤ u] are i.i.d. with mean L^u. The upper bound used (a betting test of H0: L^u ≥ ε, whose capital is a nonnegative supermartingale under H0) is valid for each u separately, which is all PAC's Theorem 1 requires. Hence P(final error ≤ ε | preprocessing) ≥ 1 − α, and taking expectations gives the unconditional guarantee. Overwriting drawn items with gold (PAC step 7) only lowers the error. Conditions: preprocessing must not use PAC's draws, and PAC must not be rerun with different settings and the best run selected. The repairs affect only the cost of reaching ε, never the validity.

## What changed in v2 (first review)

| # | Finding | Status |
|---|---|---|
| 1 | Betting test rejected a true null when the observed sum hit the boundary (`mw <= 0`); ~50% false certification on a 15/15 population | **Fixed.** `mw < 0` = null impossible; `mw == 0` rejects only on a positive observation. Validated by exact enumeration of all orderings of 276 null populations (N ≤ 8): worst P(reject)/α = 0.20. 15/15 population: 1/4000 at α = 0.005. `python -m tests.test_betting` |
| 2 | Certificate compared against the initial DS label, but the final DS re-fit was overwritten | **Fixed.** A reference vector is frozen before group audits (optionally after a DS warm-up, `--ref_share`); certificates compare against it, and the re-fit never touches repaired items. The realized change is exactly the certified one |
| 3 | No end-to-end error certificate | **Added** `audit_repair/pac.py` (PAC Labels, Alg. 1, uniform weights, betting upper bound) and `run_certified.py`: every arm ends with PAC; all expert labels are counted |
| 4 | Heuristic policy; guarded vs unguarded mixed allocation and certification | **Ablation fixed:** unguarded now uses the *same audited items and stopping time*. Policy described below as heuristic; no value-of-information allocation yet |
| 5 | Cache keyed only by (source, id) | **Fixed.** Provenance key = dataset id, revision, split, shuffle seed, n, text hash, model, prompt hash, generation settings; incompatible resumes are refused before any query; `<out>.meta.json` written |
| 6 | Substring parser (`"not positive"` → positive; first `Answer:` taken) | **Fixed.** Exact label match; reasoning prompt reads only the last non-empty line `Answer: <label>`; per-source status column `ok / invalid / truncated / failed` |

## The current policy (heuristic allocation, certified repairs)

1. Optional warm-up: `ref_share` of the budget on DS uncertainty audits; freeze reference labels `ref`.
2. Candidate groups from observable data only, fixed and disjoint: each item contradicted by at least one source gets one candidate c → b (b = most frequent dissenting label); groups = (c, b, dissenting sources). Shortlist = the 10 largest groups, fixed after the warm-up and before any group-certification sampling.
3. Audit each group in uniformly random order; per-item gain d = 1[ref ≠ y] − 1[b ≠ y]. Repair the **unaudited remainder** iff the time-uniform lower bound on its total gain is > 0 at α/10 (Bonferroni over the shortlist). Futility stop after 10 items if the mean of (d+1)/2 < 0.45; stop at half the group or 80 items; leave the group phase after 6 non-repairs in a row; group phase uses at most 70% of the budget left after warm-up. These stopping rules do not affect the guarantee.
4. Remaining budget → DS uncertainty audits; DS re-fit; final labels as in fix 2.

The group guarantee is a **false-certification** guarantee: with probability at least 1 − α, no accepted candidate repair on the shortlist has non-positive net benefit relative to its frozen reference population. It is not a claim that an already accepted repair is harmful with conditional probability ≤ α/10, and it promises nothing about superiority over re-fitted DS or about downstream training loss.

## Results on simulated annotators (v6)

### A. Repair mechanism, budget 400, label error %, `--ref_share 0.3`, 20 seeds

| Method | Clear | Null | Borderline |
|---|---|---|---|
| DS + uncertainty audits | 8.18 | **0.29** | **5.59** |
| DS re-fit with the same audits | 7.29 | 0.39 | 5.60 |
| Guarded group repair | **3.74** | 0.39 | 5.60 |
| Same candidates and evidence, no safeguard | **3.74** | 0.39 | 5.61 |

Harmful accepted repairs (remainder gain ≤ 0): guarded 0 in every scenario; without the safeguard 3 in borderline. The gain in the clear scenario is smaller than in v5 (3.22%) because disjoint groups fix fewer items per repair (≈268 vs 393).

### B. Certified end-to-end: expert labels for P(error ≤ 3%) ≥ 90%

20 simulated datasets × 10 PAC repetitions; B = 400 pre-PAC audits; PAC m = 500; α_repair = 0.05, α_final = 0.10 (joint claim at 85%). Brackets: 95% cluster bootstrap over datasets.

| Arm | Clear | Null | Borderline |
|---|---|---|---|
| PAC Labels only | 3232 [3142, 3329] | **566** | 2338 |
| DS uncertainty audits + PAC | 2369 | 838 | 1834 |
| DS re-fit with same audits + PAC | 1823 [1789, 1857] | 838 | 1768 |
| **Guarded repair + PAC** | **1497** [1445, 1561] | 838 | 1768 |
| Same candidates, no safeguard + PAC | 1497 | 838 | **1760** |

Paired, guarded + PAC minus the better DS arm per run: clear **−326 [−376, −275]**, cheaper in 84% of runs; borderline **+19 [14, 24], a small but detectable cost disadvantage** (≈1%); null +1. Against PAC alone: clear −1735, borderline −569.

Failure diagnostics (final error > 3%): clear 3/200 for both repair arms, 0/200 for the others; borderline 2–3/200 for every arm; null 0/200 (degenerate interval). At most 1 failure in any dataset's 10 repetitions.

Repair stage (clear, per dataset): about 7.6 candidates tested, 1.05 repaired, 100 group-phase audits, median group size 73, 0 harmful acceptances.

### What this does and does not show

- No observed contradiction of the PAC guarantee; validity rests on the (provisional) argument, failure counts are diagnostics.
- Synthetic proof of mechanism: on simulated data with concentrated, exploitable errors, remainder-certified group repair reduced the expert-label cost of subsequent PAC certification relative to the implemented DS-based alternatives. The figure is specific to this simulator and these comparators.
- The per-repair safeguard does not lower cost against the same candidates without it; it prevents harmful repairs (0 vs 3 in borderline). Its contribution is the guarantee, and "beneficial" means beneficial at the moment of acceptance: the later PAC stage may replace some repaired labels with expert labels, and the group certificate says nothing about which repaired labels survive.
- Guarantee levels: final-error control alone holds at 1 − α_final = 90%; the joint claim (all accepted repairs beneficial at acceptance AND final error ≤ ε) at 1 − (α_repair + α_final) = 85%.
- With errors that are not concentrated (borderline), the method costs slightly more than the better DS arm (+19 labels).
- The matched-evidence replay without the safeguard is an ablation. It does not replace the independent learned-correction + PAC baseline or the PAC router, which are still to be added.
- No claim about joint adaptive allocation; the method is two-stage. A fixed pre-audit budget loses to PAC alone when there is nothing to repair.

## Files

`audit_repair/core.py` (DS, betting test, groups, policy) · `audit_repair/pac.py` · `audit_repair/simulate.py` ·
`run_pilot.py` (mechanism) · `run_certified.py` (PAC comparison) · `annotate_llm.py` · `tests/test_betting.py` ·
`results_*`, `summary_*`, `certified_*` (v3 outputs above).

```bash
python -m tests.test_betting      # also checks the remainder rule
python run_pilot.py --sim --scenario clear --seeds 20 --ref_share 0.3
python run_certified.py --sim --scenario clear --seeds 20 --pac_reps 10 --eps 0.03
python annotate_llm.py --dataset ag_news --n 5000 --source qwen=http://localhost:8000/v1@Qwen/Qwen2.5-7B-Instruct#rev=<hash>,quant=bf16 \
    --source llama=http://localhost:8001/v1@meta-llama/Llama-3.1-8B-Instruct#rev=<hash>,quant=bf16 --out ag_news_labels.csv
python run_certified.py --labels ag_news_labels.csv --seeds 20 --pac_reps 10 --eps 0.03
```

## One-command run on Windows (WSL2 + Docker + vLLM)

`Run-AuditRepair.ps1` runs every stage: setup in WSL, self-tests, two vLLM servers, annotation,
answer-quality gate, certified comparison, shutdown, and a results zip.

```powershell
powershell -ExecutionPolicy Bypass -File .\Run-AuditRepair.ps1 `
  -ZipPath .\audit_repair_project.zip `
  -VllmImage "vllm/vllm-openai:<pinned tag>" -HfToken "hf_..."
# -Full for 5000 items; -Stages Setup,Test for simulation only; -Distro <name> if not Ubuntu-24.04
```

## Small real-LLM pilot (next step)

```bash
# 500 AG News items, 2 models x 2 prompts, raw responses + statuses + fingerprints are kept
python annotate_llm.py --dataset ag_news --n 500 \
    --source qwen=http://localhost:8000/v1@Qwen/Qwen2.5-7B-Instruct#rev=<hash>,quant=bf16 \
    --source llama=http://localhost:8001/v1@meta-llama/Llama-3.1-8B-Instruct#rev=<hash>,quant=bf16 \
    --out ag_news_500.csv
# scaled-down settings for n = 500
python run_certified.py --labels ag_news_500.csv --B 100 --m 200 --min_size 10 \
    --eps 0.05 --seeds 20 --pac_reps 10 --out certified_ag_news_500.csv
```
Expect this run to be a pipeline and annotation-quality check rather than a cost comparison: on a simulated 500-item file with the same settings, PAC alone already labels about 87% of items (434/500), which compresses any savings. The comparative run needs roughly 5,000 items.

Keep `ag_news_500.csv.cache.jsonl` (raw responses) and `.meta.json` (classes, deployments). Evaluate the PAC router and learned-correction baselines on these stored annotations before collecting more.

## Open items (before claiming the paper's contribution)

1. Real LLM annotation errors, with `--pac_reps` repetitions per fixed annotation dataset.
2. Stronger baselines: PAC router (multi-model), stronger aggregation, and a competitive learned-correction model followed by the same PAC stage.
3. Joint adaptive allocation vs. the two-stage pipeline; adaptive pre-PAC budget (null case).
4. Calibrated uncertainty for repaired items (drives the heavy cost tail).
5. Learn-then-Test style multiplicity instead of Bonferroni.

### v6.4.2 WSL regression portability

`test_certificate_export` now compares the 5 original arms to a fresh `--baseline-only` run in the same environment, then replays certificates; it no longer requires numerical identity to historical `certified_clear.csv` produced with potentially different library versions. This change does not validate cross-environment scientific equivalence.
