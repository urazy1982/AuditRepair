"""Record and verify the actual local Docker deployment, without persisting its environment.

This checks deployment identity/configuration, not cryptographic attestation of model weights.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def inspect_deployment(container):
    result = subprocess.run(["docker", "inspect", container], check=True, capture_output=True, text=True)
    d = json.loads(result.stdout)[0]
    if not d["State"].get("Running"):
        raise ValueError("Deployment is not running")
    cmd = d["Config"].get("Cmd") or []
    def option(name, default=None):
        for i, arg in enumerate(cmd):
            if arg == name:
                if i + 1 >= len(cmd):
                    raise ValueError("Missing value for " + name)
                return cmd[i + 1]
            if arg.startswith(name + "="):
                return arg.split("=", 1)[1]
        return default
    revision = option("--revision")
    if not revision or len(revision) != 40 or any(c not in "0123456789abcdefABCDEF" for c in revision):
        raise ValueError("Deployment must use a full immutable 40-character model revision")
    ports = d.get("NetworkSettings", {}).get("Ports", {}).get("8000/tcp") or []
    return {"container_id": d["Id"], "image_id": d["Image"],
            "started_at": d["State"]["StartedAt"], "restart_count": d.get("RestartCount", 0),
            "model": option("--model"), "revision": revision,
            "quantization": option("--quantization", "auto"),
            "gpu_memory_utilization": option("--gpu-memory-utilization", "default"),
            "max_model_len": int(option("--max-model-len", "0")),
            "host_ports": sorted({int(p["HostPort"]) for p in ports})}


def check_configuration(actual, model, quant, max_model_len, port, revision=None):
    expected = {"model": model, "quantization": quant, "max_model_len": max_model_len}
    if revision:
        expected["revision"] = revision
    for key, value in expected.items():
        if actual[key] != value:
            raise ValueError("Deployment mismatch: " + key)
    if port not in actual["host_ports"]:
        raise ValueError("Deployment mismatch: endpoint port")


def verify_manifest(actual, recorded):
    if actual != recorded:
        raise ValueError("Running deployment differs from the recorded manifest; rerun Serve")
    # Instance identity is checked above, but a new instance of identical immutable
    # code/weights/configuration may safely resume the same annotation cache.
    stable = {k: v for k, v in recorded.items()
              if k not in {"container_id", "started_at", "restart_count"}}
    digest = hashlib.sha256(json.dumps(stable, sort_keys=True).encode()).hexdigest()
    return f"deployment={digest},rev={actual['revision']},quant={actual['quantization']},maxlen={actual['max_model_len']}"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("action", choices=["record", "verify"])
    ap.add_argument("--container", required=True)
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--revision")
    ap.add_argument("--quant", required=True)
    ap.add_argument("--max-model-len", required=True, type=int)
    ap.add_argument("--port", required=True, type=int)
    a = ap.parse_args()
    actual = inspect_deployment(a.container)
    check_configuration(actual, a.model, a.quant, a.max_model_len, a.port, a.revision)
    path = Path(a.manifest)
    if a.action == "record":
        path.write_text(json.dumps(actual, indent=2) + "\n")
    else:
        if not path.exists():
            raise ValueError("Missing deployment manifest; run Serve before Annotate")
        print(verify_manifest(actual, json.loads(path.read_text())))


if __name__ == "__main__":
    main()
