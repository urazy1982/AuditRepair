<#
.SYNOPSIS
  Runs the whole Audit-Repair-Abstain pilot from Windows: setup in WSL2, self-tests,
  two vLLM servers on the GPU, LLM annotation, status check, certified comparison,
  shutdown, and a results bundle on your Windows disk.

.EXAMPLE
  # small real pilot (500 AG News items), all stages
  .\Run-AuditRepair.ps1 -ZipPath "$HOME\Downloads\audit_repair_project_v7.zip" `
      -VllmImage "vllm/vllm-openai:<your pinned tag>" -HfToken "hf_..."

.EXAMPLE
  # full comparison run (5000 items) re-using an existing setup
  .\Run-AuditRepair.ps1 -Full -Stages Serve,Annotate,Check,Certify,Stop,Collect `
      -VllmImage "vllm/vllm-openai:<tag>" -HfToken "hf_..."

.EXAMPLE
  # only the simulated checks (no GPU, no models)
  .\Run-AuditRepair.ps1 -ZipPath .\audit_repair_project_v7.zip -Stages Setup,Test

.NOTES
  Stages (run in this order, skip any you don't list):
    Setup    unzip into WSL, create .venv, install Python packages
    Test     betting-test enumeration + short simulated runs
    Serve    start both vLLM containers (detached) and wait until they answer
    Annotate collect labels from 2 models x 2 prompts (resumes from cache)
    Check    stop if any source has too many invalid/truncated/failed answers
    Certify  run_certified.py on the collected labels
    Stop     stop and remove the vLLM containers
    Collect  copy outputs to a Windows folder and zip them
  A transcript of everything is written next to the results.
#>
[CmdletBinding()]
param(
    [string]   $ZipPath,
    [string]   $Distro       = "Ubuntu-24.04",
    [string]   $ProjectDir   = "audit_repair",                 # under the WSL home directory
    [string[]] $Stages       = @("Setup","Test","Serve","Annotate","Check","Certify","Stop","Collect"),
    [switch]   $Full,                                          # 5000 items + full settings
    [string]   $Dataset      = "ag_news",
    [string]   $VllmImage    = "vllm/vllm-openai:latest",
    [string]   $HfToken      = $env:HF_TOKEN,
    [string]   $ModelA       = "Qwen/Qwen2.5-7B-Instruct-AWQ",
    [string]   $ModelB       = "hugging-quants/Meta-Llama-3.1-8B-Instruct-AWQ-INT4",
    [string]   $RevisionA    = "",                             # empty = resolve current commit from the HF API
    [string]   $RevisionB    = "",
    [ValidateSet("awq", "gptq", "fp8", "auto")]
    [string]   $Quant        = "awq",
    [int]      $PortA        = 8000,
    [int]      $PortB        = 8001,
    [double]   $GpuMemShare  = 0.42,                           # per server; two servers share one GPU
    [int]      $MaxModelLen  = 4096,
    [double]   $MaxBadShare  = 0.05,                           # Check stage threshold
    [int]      $ServerTimeoutMin = 60,                          # first start downloads ~5 GB per model
    [string]   $OutDir       = (Join-Path (Get-Location) ("audit_repair_results_" + (Get-Date -Format "yyyyMMdd_HHmm"))),
    [string]   $ProjWinPath  = ""                              # advanced: Windows path of the WSL project dir
)

$ErrorActionPreference = "Stop"
# -Stages may arrive as one comma-separated string (e.g. via "powershell -File"): split and validate
$AllStages = @("Setup","Test","Serve","Annotate","Check","Certify","Stop","Collect")
$Stages = @($Stages | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
foreach ($st in $Stages) {
    if ($st -notin $AllStages) { throw "Unknown stage '$st'. Valid: $($AllStages -join ', ')" }
}
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }   # show WSL output correctly
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }   # Windows PowerShell 5.1
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
Start-Transcript -Path (Join-Path $OutDir "transcript.txt") -Append | Out-Null

# ---------------------------------------------------------------- settings by run size
if ($Full) {
    $N = 5000; $Tag = "${Dataset}_5000"
    $CertArgs = "--B 400 --m 500 --min_size 30 --eps 0.03"
} else {
    $N = 500;  $Tag = "${Dataset}_500"
    $CertArgs = "--B 100 --m 200 --min_size 10 --eps 0.05"
}
$ContainerA = "ar_vllm_a"; $ContainerB = "ar_vllm_b"
$RunStart = Get-Date
$script:CurrentStage = ""
$script:Failure = $null

# ---------------------------------------------------------------- helpers
function Write-Step([string]$msg) { Write-Host "`n=== $msg ===" -ForegroundColor Cyan }
function Enter-Stage([string]$name, [string]$msg) { $script:CurrentStage = $name; Write-Step $msg }

function Protect-LogText([AllowEmptyString()][string]$Text) {
    # Literal replacement also covers explicitly supplied tokens with unusual characters.
    if ($HfToken) { $Text = $Text.Replace($HfToken, "[REDACTED]") }
    return [regex]::Replace($Text, '\bhf_[A-Za-z0-9_]+\b', '[REDACTED]')
}

function Copy-SanitizedLog([string]$Source, [string]$Destination) {
    $text = [IO.File]::ReadAllText($Source)
    [IO.File]::WriteAllText($Destination, (Protect-LogText $text), (New-Object Text.UTF8Encoding($false)))
}

function Invoke-Wsl([string]$cmd, [switch]$AllowFail) {
    # run a bash command inside the distro, streaming its output to the console (and transcript);
    # throw on failure unless -AllowFail. Returns only the exit code.
    # pipefail: a failing python in "python ... | tail" / "| tee" must fail the whole command.
    # Windows PowerShell 5.1 turns redirected native stderr into terminating errors under
    # ErrorActionPreference=Stop, so relax it locally and rely on the exit code instead.
    $prevEap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try {
        & wsl.exe -d $Distro -- bash -lc ("set -o pipefail; " + $cmd) 2>&1 |
            ForEach-Object { Protect-LogText ([string]$_) } | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $prevEap }
    if ($code -ne 0 -and -not $AllowFail) { throw (Protect-LogText "WSL command failed (exit $code): $cmd") }
    return $code
}

function Get-WslOutput([string]$cmd) {
    # returns stdout only (stderr is shown, never mixed into the value); on failure the
    # exception carries the last lines of output so the reason is visible in RUN_STATUS.txt
    $prevEap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try {
        $raw = @(& wsl.exe -d $Distro -- bash -lc ("set -o pipefail; " + $cmd) 2>&1)
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $prevEap }
    $out = @(); $err = @()
    foreach ($r in $raw) {
        $t = Protect-LogText ([string]$r)
        if ($r -is [Management.Automation.ErrorRecord]) { $err += $t } else { $out += $t }
    }
    if ($code -ne 0) {
        $tail = (@($err + $out) | Select-Object -Last 12) -join "`n"
        throw (Protect-LogText "WSL command failed (exit $code): $cmd`n$tail")
    }
    foreach ($e in $err) { Write-Host $e }
    return ($out | Out-String).Trim()
}

function ConvertTo-WslPath([string]$winPath) {
    $full = (Resolve-Path $winPath).Path
    return Get-WslOutput ("wslpath -a '{0}'" -f ($full -replace "'", "'\''"))
}

function Resolve-HfRevision([string]$model, [string]$given) {
    if ($given) { return $given }
    $headers = @{}
    if ($HfToken) { $headers["Authorization"] = "Bearer $HfToken" }
    try {
        $info = Invoke-RestMethod -Uri "https://huggingface.co/api/models/$model" -Headers $headers -TimeoutSec 30
        if (-not $info.sha) { throw "no sha field" }
        Write-Host "  $model -> revision $($info.sha)"
        return $info.sha
    } catch {
        throw (Protect-LogText "Could not resolve the commit of $model from the Hugging Face API ($_). Pass -RevisionA/-RevisionB explicitly.")
    }
}

function Wait-Server([string]$name, [int]$port) {
    $deadline = (Get-Date).AddMinutes($ServerTimeoutMin)
    Write-Host "  waiting for $name on port $port (up to $ServerTimeoutMin min; first start downloads the model)..."
    while ((Get-Date) -lt $deadline) {
        $code = Invoke-Wsl ("curl -sf http://localhost:{0}/v1/models > /dev/null" -f $port) -AllowFail
        if ($code -eq 0) { Write-Host "  $name is up." -ForegroundColor Green; return }
        $state = Get-WslOutput ("docker inspect -f '{{{{.State.Status}}}}' {0} 2>/dev/null || echo missing" -f $name)
        if ($state -in @("exited", "dead", "missing")) {
            Invoke-Wsl ("docker logs --tail 40 {0}" -f $name) -AllowFail | Out-Null
            throw "$name stopped while starting (state: $state). See the log lines above."
        }
        Start-Sleep -Seconds 15
    }
    throw "$name did not answer within $ServerTimeoutMin minutes."
}

# paths
$WslHome = Get-WslOutput 'echo $HOME'
$Proj    = "$WslHome/$ProjectDir"
if ($ProjWinPath) {
    $ProjUnc = $ProjWinPath
} else {
    $uncRoot = "\\wsl.localhost\$Distro"
    if (-not (Test-Path $uncRoot)) { $uncRoot = "\\wsl$\$Distro" }        # older Windows 10 builds
    $ProjUnc = $uncRoot + ($Proj -replace "/", "\")
}
# The vLLM containers run as root and write the mounted ~/.cache/huggingface, which left root-owned
# dataset directories that the user-side Python could not write (PermissionError in Annotate).
# Python therefore uses its own Hugging Face cache; model weights stay in the containers' cache.
$Venv    = "source $Proj/.venv/bin/activate && export HF_HOME=$WslHome/.cache/ar_hf_python && mkdir -p `$HF_HOME"
Write-Host "Distro: $Distro   project: $Proj   run: $Tag   results: $OutDir"

# ---------------------------------------------------------------- stages
try {
    if ("Setup" -in $Stages) {
        Enter-Stage "Setup" "Setup"
        if (-not $ZipPath) { throw "-ZipPath is required for the Setup stage." }
        $zipWsl = ConvertTo-WslPath $ZipPath
        Invoke-Wsl ("( command -v unzip >/dev/null && python3 -c 'import ensurepip' 2>/dev/null ) || ( sudo apt-get update -qq && sudo apt-get install -y -qq unzip python3-venv )") | Out-Null
        Invoke-Wsl ("mkdir -p '{0}' && unzip -o -q '{1}' -d '{0}'" -f $Proj, $zipWsl) | Out-Null
        Invoke-Wsl ("cd '{0}' && ( [ -d .venv ] || python3 -m venv .venv ) && {1} && pip install -q --upgrade pip && pip install -q numpy pandas scipy datasets openai huggingface_hub" -f $Proj, $Venv) | Out-Null
        Write-Host "  setup done." -ForegroundColor Green
    }

    if ("Test" -in $Stages) {
        Enter-Stage "Test" "Self-tests (simulated, no GPU)"
        # run in a child process with -ExecutionPolicy Bypass: scripts on \\wsl$ / \\wsl.localhost
        # count as network files, which RemoteSigned/AllSigned policies refuse to run directly
        $psExe = @("pwsh.exe", "powershell.exe", "pwsh") |
            ForEach-Object { Join-Path $PSHOME $_ } | Where-Object { Test-Path $_ -PathType Leaf } |
            Select-Object -First 1
        if (-not $psExe) { throw "Cannot locate the current PowerShell executable" }
        & $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $ProjUnc "tests/test_runner.ps1")
        if ($LASTEXITCODE -ne 0) { throw "Runner regression checks failed (exit $LASTEXITCODE)" }
        Invoke-Wsl ("cd '{0}' && {1} && python -m unittest discover -v" -f $Proj, $Venv) | Out-Null
        Invoke-Wsl ("cd '{0}' && {1} && python -m unittest tests.test_cs_regressions" -f $Proj, $Venv) | Out-Null
        Invoke-Wsl ("cd '{0}' && {1} && python -m tests.test_betting" -f $Proj, $Venv) | Out-Null
        Invoke-Wsl ("cd '{0}' && {1} && python run_pilot.py --sim --scenario clear --seeds 3 --budgets 400 --quiet --ref_share 0.3 --out /tmp/ar_selftest.csv | tail -8" -f $Proj, $Venv) | Out-Null
        Invoke-Wsl ("cd '{0}' && {1} && python run_certified.py --sim --scenario clear --seeds 3 --pac_reps 2 --out /tmp/ar_selftest_cert.csv | tail -12" -f $Proj, $Venv) | Out-Null
    }

    if ("Serve" -in $Stages) {
        Enter-Stage "Serve" "Start vLLM servers"
        Invoke-Wsl "nvidia-smi --query-gpu=name,memory.total --format=csv" | Out-Null
        if ((Invoke-Wsl "docker info > /dev/null 2>&1" -AllowFail) -ne 0) {
            throw "Docker is not reachable inside $Distro. Start Docker Desktop and enable WSL integration for this distro (or install docker in WSL)."
        }
        if ($VllmImage -like "*:latest") { Write-Warning "Using '$VllmImage'. Pass your pinned vLLM image tag/digest for reproducibility." }
        if (-not $HfToken) { Write-Warning "No -HfToken given: gated models (e.g. Llama) will fail to download." }
        $script:RevA = Resolve-HfRevision $ModelA $RevisionA
        $script:RevB = Resolve-HfRevision $ModelB $RevisionB
        $quantArgs = if ($Quant -eq "auto") { "" } else { " --quantization $Quant" }
        foreach ($s in @(@{n=$ContainerA; m=$ModelA; r=$script:RevA; p=$PortA},
                         @{n=$ContainerB; m=$ModelB; r=$script:RevB; p=$PortB})) {
            Invoke-Wsl ("docker rm -f {0} > /dev/null 2>&1 || true" -f $s.n) | Out-Null
            $run = ("docker run -d --name {0} --gpus all --ipc=host -p {1}:8000 " +
                    "-e HF_TOKEN='{2}' -v $WslHome/.cache/huggingface:/root/.cache/huggingface " +
                    "{3} --model {4} --revision {5} --gpu-memory-utilization {6} --max-model-len {7}$quantArgs > /dev/null") `
                    -f $s.n, $s.p, $HfToken, $VllmImage, $s.m, $s.r, $GpuMemShare, $MaxModelLen
            Invoke-Wsl $run | Out-Null
            Wait-Server $s.n $s.p      # start one at a time so their GPU memory reservations don't race
            Invoke-Wsl ("cd '{0}' && {1} && python deployment.py record --container {2} --manifest deployment_{2}.json --model {3} --revision {4} --quant {5} --max-model-len {6} --port {7}" `
                -f $Proj, $Venv, $s.n, $s.m, $s.r, $Quant, $MaxModelLen, $s.p) | Out-Null
        }
        Set-Content -Path (Join-Path $OutDir "revisions.txt") -Value "$ModelA $script:RevA`n$ModelB $script:RevB"
    }

    if ("Annotate" -in $Stages) {
        Enter-Stage "Annotate" "Annotate $N $Dataset items (2 models x 2 prompts)"
        # Verify the running container against its saved launch record; never infer its
        # checkpoint from today's repository HEAD when Serve was skipped.
        $verifyA = ("cd '{0}' && {1} && python deployment.py verify --container {2} --manifest deployment_{2}.json --model {3} --quant {4} --max-model-len {5} --port {6}" -f $Proj, $Venv, $ContainerA, $ModelA, $Quant, $MaxModelLen, $PortA)
        $verifyB = ("cd '{0}' && {1} && python deployment.py verify --container {2} --manifest deployment_{2}.json --model {3} --quant {4} --max-model-len {5} --port {6}" -f $Proj, $Venv, $ContainerB, $ModelB, $Quant, $MaxModelLen, $PortB)
        $fpA = Get-WslOutput $verifyA
        $fpB = Get-WslOutput $verifyB
        if ($RevisionA -and $fpA -notlike "*rev=$RevisionA,*") { throw "RevisionA differs from the running deployment" }
        if ($RevisionB -and $fpB -notlike "*rev=$RevisionB,*") { throw "RevisionB differs from the running deployment" }
        $srcA = "a=http://localhost:{0}/v1@{1}#{2}" -f $PortA, $ModelA, $fpA
        $srcB = "b=http://localhost:{0}/v1@{1}#{2}" -f $PortB, $ModelB, $fpB
        Invoke-Wsl ("cd '{0}' && {1} && python annotate_llm.py --dataset {2} --n {3} --source '{4}' --source '{5}' --out {6}.csv" `
                    -f $Proj, $Venv, $Dataset, $N, $srcA, $srcB, $Tag) | Out-Null
        if ((Get-WslOutput $verifyA) -ne $fpA -or (Get-WslOutput $verifyB) -ne $fpB) {
            throw "Deployment changed during annotation; do not use this label file for certification"
        }
    }

    if ("Check" -in $Stages) {
        Enter-Stage "Check" ("Check answer quality (stop if any source has > {0:P1} invalid/truncated/failed)" -f $MaxBadShare)
        $checkPy = @"
import sys, pandas as pd
df = pd.read_csv(sys.argv[1]); limit = float(sys.argv[2]); bad = False
for c in [c for c in df.columns if c.startswith('status_')]:
    share = (df[c] != 'ok').mean()
    acc = (df['src_' + c[7:]][df[c] == 'ok'] == df['gold'][df[c] == 'ok']).mean()
    flag = 'TOO HIGH' if share > limit else 'ok'
    print(f'{c[7:]:22s} not-ok {share:6.1%}   accuracy on valid {acc:6.1%}   {flag}   {df[c].value_counts().to_dict()}')
    bad |= share > limit
sys.exit(3 if bad else 0)
"@
        [IO.File]::WriteAllText((Join-Path $ProjUnc "check_status.py"), $checkPy, (New-Object Text.UTF8Encoding($false)))
        $code = Invoke-Wsl ("cd '{0}' && {1} && python check_status.py {2}.csv {3}" -f $Proj, $Venv, $Tag, $MaxBadShare) -AllowFail
        if ($code -eq 3) {
            throw "Too many unusable answers. Inspect $Tag.csv.cache.jsonl (raw responses) and fix prompts/parsing before certifying."
        } elseif ($code -ne 0) { throw "Status check failed (exit $code)." }
    }

    if ("Certify" -in $Stages) {
        Enter-Stage "Certify" "Certified comparison"
        Invoke-Wsl ("cd '{0}' && {1} && python run_certified.py --labels {2}.csv {3} --seeds 20 --pac_reps 10 --out certified_{2}.csv | tee report_{2}.txt" `
                    -f $Proj, $Venv, $Tag, $CertArgs) | Out-Null
    }
}
catch {
    $script:Failure = $_
    Write-Host (Protect-LogText "`nRUN FAILED in stage '$($script:CurrentStage)': $($_.Exception.Message)") -ForegroundColor Red
}
finally {
    if ("Stop" -in $Stages) {
        Write-Step "Stop vLLM servers"
        foreach ($c in @($ContainerA, $ContainerB)) {
            Invoke-Wsl ("docker logs {0} > /tmp/{0}.log 2>&1; docker rm -f {0} > /dev/null 2>&1 || true" -f $c) -AllowFail | Out-Null
        }
    }
    if ("Collect" -in $Stages) {
        Write-Step "Collect results into $OutDir"
        $files = @("$Tag.csv", "$Tag.csv.meta.json", "$Tag.csv.cache.jsonl", "certified_$Tag.csv",
                   "certified_${Tag}_groups.csv", "certified_${Tag}_certificates.jsonl", "report_$Tag.txt",
                   "deployment_ar_vllm_a.json", "deployment_ar_vllm_b.json")
        # the cache and label file are cumulative (resumable), so they are always copied;
        # results files are copied only if THIS run wrote them, so a failed run never ships
        # an older report as if it were current
        $cumulative = @("$Tag.csv", "$Tag.csv.meta.json", "$Tag.csv.cache.jsonl",
                        "deployment_ar_vllm_a.json", "deployment_ar_vllm_b.json")
        foreach ($f in $files) {
            $src = Join-Path $ProjUnc $f
            if (-not (Test-Path $src)) { Write-Warning "missing: $f"; continue }
            if ($f -in $cumulative -or (Get-Item $src).LastWriteTime -ge $RunStart.AddSeconds(-2)) {
                Copy-Item $src $OutDir -Force
            } else {
                Write-Warning "not copied (left over from an earlier run): $f"
            }
        }
        foreach ($c in @($ContainerA, $ContainerB)) {
            Invoke-Wsl ("[ -f /tmp/{0}.log ] && [ -d '{1}' ] && cp /tmp/{0}.log '{1}/' || true" -f $c, $Proj) -AllowFail | Out-Null
            $log = Join-Path $ProjUnc "$c.log"
            if (Test-Path $log) { Copy-SanitizedLog $log (Join-Path $OutDir "$c.log") }
        }
        $status = if ($script:Failure) {
            "FAILED in stage '$($script:CurrentStage)': $($script:Failure.Exception.Message)"
        } else { "SUCCESS: stages $($Stages -join ', ') completed" }
        Set-Content -Path (Join-Path $OutDir "RUN_STATUS.txt") -Value (Protect-LogText $status)
        Stop-Transcript | Out-Null
        # Also scrub an appended transcript from an earlier attempt in this output directory.
        $transcriptPath = Join-Path $OutDir "transcript.txt"
        if (Test-Path $transcriptPath) { Copy-SanitizedLog $transcriptPath $transcriptPath }
        if ($script:Failure) {
            $zip = "${OutDir}_FAILED_diagnostics.zip"
            Compress-Archive -Path (Join-Path $OutDir "*") -DestinationPath $zip -Force
            Write-Host "`nRun FAILED. These are diagnostics, not results: $zip" -ForegroundColor Red
        } else {
            $zip = "$OutDir.zip"
            Compress-Archive -Path (Join-Path $OutDir "*") -DestinationPath $zip -Force
            Write-Host "`nDone. Send this file: $zip" -ForegroundColor Green
        }
    } else {
        Stop-Transcript | Out-Null
        $transcriptPath = Join-Path $OutDir "transcript.txt"
        if (Test-Path $transcriptPath) { Copy-SanitizedLog $transcriptPath $transcriptPath }
    }
    if ($script:Failure) { exit 1 }
}
