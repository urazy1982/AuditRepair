# BANKING77 replication

The panel contains 3,080 test items and 77 intents, with predictions from
four pinned checkpoints. All four constrained runs reported zero unusable
responses. The unconstrained preliminary runs reported 50 unusable Qwen
responses and 710 unusable Llama responses. Llama exceeded the frozen 5%
per-source gate, prompting a separately versioned constrained collection
with exact choices 0 through 76. Qwen and Llama used AWQ checkpoints.
Mistral and Phi used BF16. See replication/banking77_prepared/protocol.json
for pinned inputs, hashes and analysis settings.

| Comparison | Mean expert reviews | Paired difference |
|---|---:|---|
| Frozen guarded repair vs same-audit Dawid–Skene | 2,664.71 vs 2,664.71 | 0 across 200 pairs |
| Frozen same-audit Dawid–Skene vs PAC alone | 2,664.71 vs 2,765.17 | −100.46 (95% interval −114.62 to −85.58) |
| Secondary guarded repair vs uncertainty-audit Dawid–Skene | 2,665 vs 2,684 | −19 (95% interval −35 to −4) |
| Secondary guarded repair vs same-audit Dawid–Skene | 2,665 vs 2,665 | 0 across 200 pairs |

The frozen analysis used a ten-failure stop. No group was certified and no
shortlisted repair had positive gain relative to the same-audit baseline.
The secondary comparison used a six-failure stop. It isolates a difference
in audit allocation under the tested conditions. Intervals describe
variability across preprocessing realizations of one fixed panel.

The uploaded result archives are unpacked under frozen/ and audit_baseline/.
The secondary banking77.csv is the per-run metrics file. The analysed label file is
included as data/banking77.csv (v7.9). The row-level joined input CSV, original and constrained raw model responses, prepared
texts and the blinded gold.jsonl remain workstation inputs and were unavailable for
this archive. Keep those files for a full rerun.

Descriptive diagnostics (pool statistics, error anatomy, identifier-offset
counts) are under descriptive/.
