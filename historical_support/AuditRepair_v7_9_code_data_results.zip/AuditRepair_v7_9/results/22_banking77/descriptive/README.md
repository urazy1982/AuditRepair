# BANKING77 descriptive diagnostics (v7.9, CPU, retrospective)

Computed from `data/banking77.csv` (constrained collection, analysis input of the frozen run;
SHA-256 111170bac00b61c4623fba9ab273da8639bb82f586c250766269db4599812984).

    python experiments/pool_statistics/pool_statistics.py --labels data/banking77.csv --out results/22_banking77/descriptive/pool_statistics.json
    python experiments/error_anatomy/error_anatomy.py --labels data/banking77.csv --out results/22_banking77/descriptive/error_anatomy.json

`id_offset_diagnostic.json` counts predictions whose integer ID differs from the gold ID by
exactly one, and the share expected if wrong labels were uniform over the other 76 intents
(about 2.6%). The observed 9.5--28.4% of errors is consistent with an artefact of
answering with integer identifiers. Descriptive only; no annotations were changed.
