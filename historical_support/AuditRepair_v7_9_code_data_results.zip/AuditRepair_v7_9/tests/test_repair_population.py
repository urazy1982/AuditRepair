import unittest
from unittest.mock import patch

import numpy as np

from audit_repair.core import Group, run_group_repair


class RepairPopulationTests(unittest.TestCase):
    def test_overlapping_group_excludes_previously_revealed_item(self):
        items = np.arange(6)
        groups = [Group(source, 0, 1, items, 0.0) for source in (0, 1)]
        labels = np.zeros((6, 2), dtype=int)
        gold = np.ones(6, dtype=int)
        with patch("audit_repair.core.candidate_groups", return_value=groups):
            result = run_group_repair(labels, 2, gold, budget=5, min_size=2,
                                      k_max=1, disjoint=False, seed=17)
        first, second = result["guarded"][1]["log"]
        first_item = first["audit_history"][0]["item"]
        self.assertNotIn(first_item, second["members"])
        self.assertEqual(second["size"], first["size"] - 1)
