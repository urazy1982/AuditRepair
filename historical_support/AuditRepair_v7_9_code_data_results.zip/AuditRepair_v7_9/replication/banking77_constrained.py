"""Collect blinded BANKING77 responses against a locally served pinned checkpoint."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import re
import subprocess
from pathlib import Path
from urllib.request import Request, urlopen

def parse_label(text):
    value = text.strip()
    return int(value) if re.fullmatch(r"(?:0|[1-9][0-9]?)", value) and int(value) < 77 else None

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--container", required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--limit", type=int, choices=(32, 3080), default=32)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit(f"Output already exists: {args.out}")
    raw_protocol = (args.prepared / "protocol.json").read_bytes()
    protocol = json.loads(raw_protocol)
    raw_items = (args.prepared / "items.jsonl").read_bytes()
    if hashlib.sha256(raw_items).hexdigest() != protocol["sha256"]["items.jsonl"]:
        raise SystemExit("Input hash mismatch")
    items = [json.loads(line) for line in raw_items.splitlines()]
    if [row["id"] for row in items] != list(range(3080)) or any(
        set(row) != {"id", "text"} or not isinstance(row["text"], str) for row in items
    ):
        raise SystemExit("Unexpected blinded input format")
    intents = "\n".join(f"{i}: {protocol['class_ids'][str(i)]}" for i in range(77))
    revision = protocol["inputs"]["models"][args.model]
    deployment = json.loads(subprocess.check_output(["docker", "inspect", args.container]))[0]
    cmd = deployment["Config"]["Cmd"]
    for flag, expected in [("--model", args.model), ("--revision", revision)]:
        if flag not in cmd or cmd[cmd.index(flag)+1] != expected:
            raise SystemExit(f"Container does not match the frozen {flag}")
    bindings = deployment["NetworkSettings"]["Ports"].get("8000/tcp") or []
    if not any(b["HostPort"] == str(args.port) for b in bindings):
        raise SystemExit("Endpoint port does not belong to the verified container")
    base = f"http://127.0.0.1:{args.port}/v1"
    with urlopen(base + "/models", timeout=15) as response:
        if args.model not in {row["id"] for row in json.load(response)["data"]}:
            raise SystemExit("Server did not advertise the expected model")
    constraint = {"choice": [str(i) for i in range(77)]}
    def query(row):
        content = protocol["prompt_template"].format(intents=intents, text=row["text"])
        body = {"model": args.model, "messages": [{"role": "user", "content": content}],
                **protocol["generation"], "structured_outputs": constraint}
        req = Request(base + "/chat/completions", data=json.dumps(body).encode(),
                      headers={"Content-Type": "application/json"})
        with urlopen(req, timeout=120) as response:
            choice = json.load(response)["choices"][0]
        text = choice["message"]["content"]
        label = parse_label(text) if isinstance(text, str) and choice["finish_reason"] == "stop" else None
        return {"id": row["id"], "label": label, "answer": text,
                "finish_reason": choice["finish_reason"]}
    identity = {"protocol_sha256": hashlib.sha256(raw_protocol).hexdigest(),
                "model": args.model, "revision": revision, "image_id": deployment["Image"],
                "command": cmd, "limit": args.limit, "structured_outputs": constraint}
    cache = args.out.with_suffix(".checkpoint.jsonl")
    if cache.exists():
        with cache.open(encoding="utf-8") as f:
            if json.loads(next(f)) != identity:
                raise SystemExit("Checkpoint provenance mismatch")
            records = [json.loads(line) for line in f]
    else:
        with cache.open("x", encoding="utf-8") as f:
            f.write(json.dumps(identity) + "\n")
        records = []
    if [r["id"] for r in records] != list(range(len(records))) or len(records) > args.limit:
        raise SystemExit("Checkpoint row order mismatch")
    with cache.open("a", encoding="utf-8") as f, ThreadPoolExecutor(max_workers=8) as workers:
        for record in workers.map(query, items[len(records):args.limit]):
            records.append(record)
            f.write(json.dumps(record) + "\n")
            f.flush()
            if len(records) % 250 == 0:
                print(f"{len(records)}/{args.limit}", flush=True)
    if subprocess.check_output(["docker", "inspect", "--format", "{{.Id}} {{.State.StartedAt}}", args.container],
                               text=True).strip() != f"{deployment['Id']} {deployment['State']['StartedAt']}":
        raise SystemExit("Container changed during smoke test")
    unusable = sum(r["label"] is None for r in records)
    result = {**identity, "unusable": unusable, "rows": records}
    if args.limit == 3080:
        result["passes_quality_gate"] = unusable / args.limit <= protocol["max_unusable_share_per_source"]
    with args.out.open("x", encoding="utf-8") as output:
        json.dump(result, output, indent=2)
    print(f"Saved {args.out}: {unusable}/{args.limit} unusable responses")
    if result.get("passes_quality_gate") is False:
        print("Full-pool quality gate failed. Preserve the output for diagnosis.")

if __name__ == "__main__":
    main()
