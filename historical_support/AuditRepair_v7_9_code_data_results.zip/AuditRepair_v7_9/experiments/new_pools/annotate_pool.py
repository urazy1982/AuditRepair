"""Collect additional evaluation pools with the SAME verified deployments, prompts and generation
settings as the AG News development pool (generalised from annotate_yelp.py).

Pools are defined in POOLS below. Selection: shuffle the test split with a fixed seed and keep the
first N items whose normalised prompt-visible text (first 2,000 characters) is unique within the pool.
The dataset revision is resolved to an immutable commit at run time (or pinned with --revision) and
recorded in the metadata sidecar.
Usage: python annotate_pool.py --pool dbpedia --development ~/audit_repair/ag_news_5000.csv \
           --deployment-dir ~/audit_repair --out dbpedia_2600.csv"""
from __future__ import annotations

from pathlib import Path

from deployment import inspect_deployment, verify_manifest
from holdout_protocol import development, digest
from holdout_protocol import prompt_key

SHUFFLE_SEED = 20261108
RULE = "first_N_unique_prompt_texts_after_fixed_test_shuffle"
POOLS = {
    # name: (HF id, config, split, text field, label field, readable class names, items)
    "dbpedia": ("fancyzhx/dbpedia_14", "dbpedia_14", "test", "content", "label",
                ["Company", "Educational institution", "Artist", "Athlete", "Office holder",
                 "Means of transportation", "Building", "Natural place", "Village", "Animal",
                 "Plant", "Album", "Film", "Written work"], 2600),
    "emotion": ("dair-ai/emotion", "split", "test", "text", "label",
                ["sadness", "joy", "love", "anger", "fear", "surprise"], 2000),
    "imdb": ("stanfordnlp/imdb", "plain_text", "test", "text", "label",
             ["negative", "positive"], 2600),
}


def select_positions(texts, items, *, allow_short=False):
    seen, selected = set(), []
    for i, text in enumerate(texts):
        key = prompt_key(text)
        if key not in seen:
            seen.add(key)
            selected.append(i)
            if len(selected) == items:
                return selected
    if allow_short and selected:
        return selected
    raise ValueError("Split has too few unique items")

import argparse
import asyncio
import hashlib
import json
import os
import re

import pandas as pd

PROMPTS = {
    "direct": ("Classify the text into exactly one of these categories: {labels}.\n"
               "Text: {text}\nAnswer with the category name only, nothing else."),
    "reason": ("You are an expert annotator. Possible categories: {labels}.\n"
               "Read the text, think about which category fits best, then end your reply with a "
               "final line of exactly the form 'Answer: <category>'.\nText: {text}"),
}
GEN = {"temperature": 0.0, "seed": 0, "max_tokens": {"direct": 16, "reason": 512}}


def sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def _norm(s: str) -> str:
    return re.sub(r"[\s\.\"'`*:;!]+$", "", re.sub(r"^[\s\"'`*]+", "", s)).strip().lower()


def parse(answer: str, names: list[str], prompt: str, finish_reason: str | None) -> tuple[int, str]:
    """Strict parsing. Returns (label index or -1, status)."""
    if answer is None or answer == "":
        return -1, "failed"
    if finish_reason == "length":
        return -1, "truncated"
    lookup = {nm.lower(): i for i, nm in enumerate(names)}
    if prompt == "direct":
        cand = _norm(answer)
    else:
        lines = [ln for ln in answer.strip().splitlines() if ln.strip()]
        m = re.fullmatch(r"\s*\**\s*answer\s*:\s*(.+?)\s*", lines[-1], re.I) if lines else None
        if not m:
            return -1, "invalid"
        cand = _norm(m.group(1))
    return (lookup[cand], "ok") if cand in lookup else (-1, "invalid")


async def ask(client, model, prompt, sem, max_tokens):
    from openai import APIError
    async with sem:
        for attempt in range(4):
            try:
                r = await client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}],
                    temperature=GEN["temperature"], max_tokens=max_tokens, seed=GEN["seed"])
                ch = r.choices[0]
                return ch.message.content or "", ch.finish_reason
            except APIError:
                await asyncio.sleep(2 ** attempt)
        return "", "error"


async def server_fingerprint(url: str, model: str) -> dict:
    """What the endpoint itself reports about the served model (vLLM: id, root, max_model_len)."""
    try:
        from openai import AsyncOpenAI
        cl = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        models = await cl.models.list()
        for mdl in models.data:
            d = mdl.model_dump() if hasattr(mdl, "model_dump") else dict(mdl)
            if d.get("id") == model:
                return {k: d.get(k) for k in ("id", "root", "max_model_len", "owned_by") if d.get(k) is not None}
    except Exception as e:  # endpoint without /models: rely on the user fingerprint
        return {"unavailable": type(e).__name__}
    return {"not_listed": True}


async def main_async(a):
    from datasets import load_dataset
    from openai import AsyncOpenAI
    from huggingface_hub import HfApi

    dev, dev_meta = development(a.development)
    hf, cfg, split, tf, lf, names, items = POOLS[a.pool]
    revision_path = Path(a.out + ".revision")
    pinned = revision_path.read_text().strip() if revision_path.exists() else None
    if pinned and a.revision and pinned != a.revision:
        raise ValueError("Output already belongs to a different dataset revision")
    requested = a.revision or pinned
    revision = HfApi().dataset_info(hf, revision=requested).sha
    if not revision or not re.fullmatch(r"[0-9a-f]{40}", revision) or (requested and revision != requested):
        raise ValueError("Could not resolve or verify an immutable dataset revision")
    raw = load_dataset(hf, cfg, split=split, revision=revision).shuffle(seed=SHUFFLE_SEED)
    feats = getattr(raw, "features", None)
    expected_names = {"imdb": ["neg", "pos"],
                      "dbpedia": [*names[:5], "MeanOfTransportation", *names[6:]]}.get(a.pool, names)
    normalize = lambda value: re.sub(r"[^a-z0-9]", "", value.lower())
    if feats is None or list(map(normalize, feats[lf].names)) != list(map(normalize, expected_names)):
        raise ValueError(f"Unexpected class mapping in {hf}: {getattr(feats[lf], 'names', None) if feats else None}")
    positions = select_positions(raw[tf], items, allow_short=a.pool == "emotion")
    ds = raw.select(positions)
    a.n = len(positions)
    df = pd.DataFrame({"id": range(a.n), "shuffled_position": positions, "text": ds[tf], "gold": ds[lf]})
    text_hash = [sha(t) for t in df.text]
    data_key = sha(json.dumps([hf, cfg, split, revision, SHUFFLE_SEED, positions, names]))
    prompt_hashes = {k: sha(v) for k, v in PROMPTS.items()}
    if (dev_meta["prompts"] != prompt_hashes or dev_meta["gen"] != GEN
            or dev_meta["retry_policy"] != {"transport_failures": True, "unusable_outputs": False}):
        raise ValueError("Prompt, generation or retry protocol differs from development")
    revision_path.write_text(revision + "\n")
    if a.prepare_only:
        print(f"Prepared {a.n} {a.pool} items from {hf}@{revision}", flush=True)
        return
    instances = {}
    a.source = []
    for tag, expected in dev_meta["deployments"].items():
        container = "ar_vllm_" + tag
        recorded = json.loads((Path(a.deployment_dir) / f"deployment_{container}.json").read_text())
        actual = inspect_deployment(container)
        fp = verify_manifest(actual, recorded)
        if fp != expected["fingerprint"] or actual["model"] != expected["model"]:
            raise ValueError(f"Deployment {tag} differs from development")
        instances[container] = actual
        a.source.append(f"{tag}={expected['url']}@{expected['model']}#{fp}")
    print(f"Selected {a.n} {a.pool} items from {hf}@{revision}", flush=True)

    cache_path = a.out + ".cache.jsonl"
    cache = {}
    if os.path.exists(cache_path):
        with open(cache_path) as cached_file:
            for line in cached_file:
                r = json.loads(line)
                cache[r["key"]] = r
    sem = asyncio.Semaphore(a.concurrency)
    labels = ", ".join(names)
    used_keys = set()

    plan, deployments = [], {}
    for spec in a.source:
        tag, rest = spec.split("=", 1)
        url, model = rest.split("@", 1)
        model, _, user_fp = model.partition("#")
        if not user_fp:
            print(f"WARNING: no deployment fingerprint for '{tag}'. Add '#rev=...,quant=...' "
                  f"to the --source spec for reproducible source identity.", flush=True)
        server_fp = await server_fingerprint(url, model)
        deployments[tag] = {"url": url, "model": model, "fingerprint": user_fp, "server": server_fp}
        for pname, tmpl in PROMPTS.items():
            mt = GEN["max_tokens"][pname]
            src_key = sha(json.dumps([data_key, url.rstrip("/"), model, user_fp, server_fp,
                                      sha(tmpl), GEN["temperature"], GEN["seed"], mt]))
            keys = [f"{src_key}:{i}:{text_hash[i]}" for i in range(a.n)]
            used_keys.update(keys)
            plan.append((f"src_{tag}_{pname}", url, model, pname, tmpl, mt, keys))
    if deployments != dev_meta["deployments"]:
        raise ValueError("Endpoint fingerprints differ from development")
    # refuse incompatible resumes BEFORE spending any queries
    stale = sum(1 for k in cache if k not in used_keys)
    if stale and not a.allow_stale_cache:
        raise SystemExit(f"{stale} cached answers in {cache_path} come from a different dataset/model/"
                         f"prompt/settings. Use a new --out path, or --allow-stale-cache to ignore them.")

    for src, url, model, pname, tmpl, mt, keys in plan:
        client = AsyncOpenAI(base_url=url, api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"))
        def needs_query(i):
            if keys[i] not in cache:
                return True
            rec = cache[keys[i]]
            # Transport failures are recoverable. Model-format failures are experimental
            # outcomes, retained unless the caller explicitly opts into resampling them.
            if rec.get("finish_reason") == "error":
                return True
            status = parse(rec["answer"], names, pname, rec["finish_reason"])[1]
            return getattr(a, "retry_unusable", False) and status != "ok"
        todo = [i for i in range(a.n) if needs_query(i)]
        print(f"{src}: {len(todo)} to query ({a.n - len(todo)} cached)", flush=True)
        for start in range(0, len(todo), 500):
            chunk = todo[start:start + 500]
            outs = await asyncio.gather(*[
                ask(client, model, tmpl.format(labels=labels, text=df.text[i][:2000]), sem, mt)
                for i in chunk])
            with open(cache_path, "a") as cache_f:
                for i, (ans, fin) in zip(chunk, outs):
                    rec = {"key": keys[i], "src": src, "id": i, "model": model, "prompt": pname,
                           "answer": ans, "finish_reason": fin}
                    cache[keys[i]] = rec
                    cache_f.write(json.dumps(rec) + "\n")
        parsed = [parse(cache[k]["answer"], names, pname, cache[k]["finish_reason"]) for k in keys]
        df[src] = [p[0] for p in parsed]
        df["status_" + src[4:]] = [p[1] for p in parsed]
        ok = df["status_" + src[4:]] == "ok"
        print(f"  {src}: accuracy on valid {(df[src][ok] == df.gold[ok]).mean():.3f}; "
              f"status {df['status_' + src[4:]].value_counts().to_dict()}", flush=True)

    for container, before in instances.items():
        if inspect_deployment(container) != before:
            raise ValueError("Deployment changed during annotation")
    unusable = {src: float((df["status_" + src[4:]] != "ok").mean()) for src, *_ in plan}
    if any(rate > 0.05 for rate in unusable.values()):
        print(f"QUALITY GATE FAILED (5% unusable per source): {unusable}", flush=True)
    df.to_csv(a.out, index=False)
    with open(a.out + ".meta.json", "w") as metadata_file:
        json.dump({"dataset": hf, "revision": str(revision), "split": split, "n": a.n,
                   "shuffle_seed": SHUFFLE_SEED, "classes": names, "deployments": deployments,
                   "pool": a.pool, "selection_rule": RULE, "config": cfg,
                   "unusable_share": unusable, "passes_quality_gate": all(rate <= 0.05 for rate in unusable.values()), "development_sha256": digest(a.development),
                   "pool_sha256": digest(a.out),
                   "retry_policy": {"transport_failures": True, "unusable_outputs": getattr(a, "retry_unusable", False)},
                   "prompts": {k: sha(v) for k, v in PROMPTS.items()}, "gen": GEN},
                  metadata_file, indent=2)
    print("saved", a.out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", required=True, choices=list(POOLS))
    ap.add_argument("--revision", default=None, help="optional: pin the dataset commit")
    ap.add_argument("--development", required=True)
    ap.add_argument("--deployment-dir", required=True)
    ap.add_argument("--prepare-only", action="store_true", help="validate and cache dataset before starting vLLM")
    ap.add_argument("--concurrency", type=int, default=32)
    ap.set_defaults(allow_stale_cache=False, retry_unusable=False)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    if args.concurrency < 1:
        ap.error("--concurrency must be positive")
    asyncio.run(main_async(args))


if __name__ == "__main__":
    main()
