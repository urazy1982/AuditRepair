# New evaluation pools: DBpedia-14, Emotion, IMDB

Adds three datasets to the study, annotated with exactly the development deployments
(same vLLM image digest, model commits, quantization, memory share, context length, ports),
prompts and generation settings. `annotate_pool.py` refuses to query if any of these differ.

| pool | HF dataset (config, split) | classes | items |
|---|---|---|---|
| dbpedia | fancyzhx/dbpedia_14 (dbpedia_14, test), field `content` | 14 | 2,600 |
| emotion | dair-ai/emotion (split, test) | 6 | up to 2,000 unique texts |
| imdb | stanfordnlp/imdb (plain_text, test) | 2 | 2,600 |

Selection: shuffle the test split with seed 20261108, keep the first N items whose normalised
prompt-visible text (first 2,000 characters) is unique. The dataset commit is resolved at run time
and stored in `<pool>.csv.revision` before inference. Keep that file with the cache when resuming.

## Run (Windows PowerShell, GPU must be free; ports 8000/8001 must be free)

    $env:HF_TOKEN = "hf_..."
    powershell -NoProfile -ExecutionPolicy Bypass -File C:\auditrepair\v7\experiments\new_pools\Run-NewPools.ps1

It starts the servers, annotates the three pools (resumable), always stops the servers, and writes
`new_pools_results_<date>.zip`. Runtime depends on reasoning output length and cache hits. The first start may download the image and model weights. Only pools: `-Pools dbpedia,emotion`.

Everything after annotation (certified repair, oracle decomposition, error anatomy, grouped DS)
runs on CPU from the saved CSVs.

The runner prepares and validates all requested datasets before starting vLLM.
DBpedia uses the content field. Emotion uses all distinct prompt-visible texts
up to 2,000. Keep strict parsing and report the per-source unusable rate.
The sidecar records whether each pool passes the 5% per-source quality gate.
A failing pool is still exported for diagnosis and should be reported as
such. This collection extends dataset coverage with the same
two model checkpoints.

From the package root in WSL, after collection and inspection of the sidecars:

    source ~/audit_repair/.venv/bin/activate
    for pool in dbpedia emotion imdb; do
      python experiments/oracle_repair/run_oracle_repair.py \
        --labels "$HOME/audit_repair/pools/$pool.csv" --out "results/oracle_$pool"
    done

The oracle runner defaults match the historical repair diagnostic (500 PAC
draws, 3% target, 400 pre-audits, 20 seeds and 10 repetitions).
The separate frozen aggregation experiment used 1,000 PAC draws.
