<#
.SYNOPSIS
  Annotate the three new evaluation pools (DBpedia-14, Emotion, IMDB) with the SAME verified vLLM
  deployments as the AG News development pool, then stop the servers and zip the results.

.DESCRIPTION
  1. Starts both vLLM servers with the pinned image digest, model commits, quantization, memory share,
     context length and ports used for the development run (Run-AuditRepair.ps1 -Stages Serve).
  2. Runs annotate_pool.py for each pool. It refuses to query if the running deployments, prompts or
     generation settings differ from the development pool's metadata.
  3. Always stops the servers (also on failure) so the GPU is free for other jobs.
  4. Copies <pool>.csv, its .meta.json and .cache.jsonl to -OutDir and zips them.

  Annotations resume from the cache: if interrupted, run the script again.
  The development run used ports 8000/8001; the deployment fingerprint includes the ports, so
  stop anything else on those ports first (check: wsl -d Ubuntu-24.04 -- docker ps).

.EXAMPLE
  $env:HF_TOKEN = "hf_..."
  powershell -NoProfile -ExecutionPolicy Bypass -File C:\auditrepair\v7\experiments\new_pools\Run-NewPools.ps1
#>
[CmdletBinding()]
param(
    [string]   $PackageRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path,
    [string]   $Distro      = "Ubuntu-24.04",
    [string[]] $Pools       = @("dbpedia", "emotion", "imdb"),
    [string]   $OutDir      = (Join-Path (Get-Location) ("new_pools_results_" + (Get-Date -Format "yyyyMMdd_HHmmss"))),
    [string]   $VllmImage   = "vllm/vllm-openai@sha256:d825baf9ce4b1b6bfc5ecc7b79880c7e6748c65a72d697ce3d47607aafa84c6e",
    [string]   $RevisionA   = "b25037543e9394b818fdfca67ab2a00ecc7dd641",
    [string]   $RevisionB   = "db1f81ad4b8c7e39777509fac66c652eb0a52f91",
    [string]   $HfToken     = $env:HF_TOKEN
)
$ErrorActionPreference = "Stop"
$Pools = @($Pools | ForEach-Object { $_ -split "," } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if (-not $Pools -or @($Pools | Where-Object { $_ -notin @("dbpedia", "emotion", "imdb") }).Count) {
    throw "Choose pools from dbpedia, emotion, imdb."
}
$Pools = @($Pools | ForEach-Object { $_.ToLowerInvariant() } | Select-Object -Unique)
if (Test-Path -LiteralPath $OutDir) { throw "Choose a fresh output directory: $OutDir" }
New-Item -ItemType Directory -Path $OutDir | Out-Null
$OutDir = (Resolve-Path -LiteralPath $OutDir).Path

$runner = Join-Path $PackageRoot "Run-AuditRepair.ps1"
$psExe = @("pwsh.exe", "powershell.exe", "pwsh") | ForEach-Object { Join-Path $PSHOME $_ } |
    Where-Object { Test-Path $_ -PathType Leaf } | Select-Object -First 1

function Invoke-Bash([string]$cmd) {
    $prev = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try {
        & wsl.exe -d $Distro -- bash -lc ("set -o pipefail; " + $cmd) 2>&1 | ForEach-Object {
            $line = [string]$_
            if ($HfToken) { $line = $line.Replace($HfToken, "[REDACTED]") }
            [regex]::Replace($line, '\bhf_[A-Za-z0-9_]+\b', '[REDACTED]')
        } | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $prev }
    if ($code -ne 0) { throw "WSL command failed (exit $code)" }
}

$wslPkg = (& wsl.exe -d $Distro -- wslpath -a ($PackageRoot -replace '\\', '/')).Trim()
$failure = $null
$started = $false
$completed = @()
Start-Transcript -Path (Join-Path $OutDir "transcript.txt") | Out-Null
try {
    Invoke-Bash 'docker info >/dev/null && names=$(docker ps -a --format "{{.Names}}") && ! grep -Ex "ar_vllm_[ab]" <<< "$names" && test -x ~/audit_repair/.venv/bin/python && test -f ~/audit_repair/ag_news_5000.csv.meta.json'
    $collector = "source ~/audit_repair/.venv/bin/activate && export HF_HOME=~/.cache/ar_hf_python && mkdir -p ~/audit_repair/pools && cd '$wslPkg/experiments/new_pools' && python -u annotate_pool.py --development ~/audit_repair/ag_news_5000.csv --deployment-dir ~/audit_repair"
    Write-Host "`n=== Prepare and validate datasets ===" -ForegroundColor Cyan
    foreach ($p in $Pools) {
        Invoke-Bash "$collector --pool $p --out ~/audit_repair/pools/$p.csv --prepare-only"
    }
    Write-Host "`n=== Start the development deployments ===" -ForegroundColor Cyan
    $started = $true
    & $psExe -NoProfile -ExecutionPolicy Bypass -File $runner -Distro $Distro -Stages Serve -ServerTimeoutMin 60 `
        -VllmImage $VllmImage -RevisionA $RevisionA -RevisionB $RevisionB -HfToken $HfToken `
        -OutDir (Join-Path $OutDir "serve")
    if ($LASTEXITCODE -ne 0) { throw "Serve stage failed; see $OutDir\serve" }

    foreach ($p in $Pools) {
        Write-Host "`n=== Annotate $p ===" -ForegroundColor Cyan
        Invoke-Bash "$collector --pool $p --out ~/audit_repair/pools/$p.csv"
        $completed += $p
    }
}
catch { $failure = $_; Write-Host "`nFAILED: $($_.Exception.Message)" -ForegroundColor Red }
finally {
    Write-Host "`n=== Stop the servers ===" -ForegroundColor Cyan
    if ($started) {
        & $psExe -NoProfile -ExecutionPolicy Bypass -File $runner -Distro $Distro -Stages Stop -OutDir (Join-Path $OutDir "stop")
        if ($LASTEXITCODE -ne 0 -and -not $failure) { $failure = "Stop stage failed" }
        try {
            Invoke-Bash 'names=$(docker ps -a --format "{{.Names}}") && ! grep -Ex "ar_vllm_[ab]" <<< "$names"'
        } catch {
            if (-not $failure) { $failure = "Could not verify removal of the vLLM containers" }
        }
    }
    Write-Host "`n=== Collect ===" -ForegroundColor Cyan
    $wslOut = (& wsl.exe -d $Distro -- wslpath -a ($OutDir -replace '\\', '/')).Trim()
    foreach ($p in $completed) {
        try {
            Invoke-Bash "cp ~/audit_repair/pools/$p.csv ~/audit_repair/pools/$p.csv.meta.json ~/audit_repair/pools/$p.csv.cache.jsonl ~/audit_repair/pools/$p.csv.revision '$wslOut/'"
        } catch { $failure = $_ }
    }
    $status = if ($failure) { "FAILED: $failure" } else { "SUCCESS: pools $($Pools -join ', ')" }
    Set-Content -Path (Join-Path $OutDir "RUN_STATUS.txt") -Value $status
    Stop-Transcript | Out-Null
    $zip = if ($failure) { "${OutDir}_FAILED_diagnostics.zip" } else { "$OutDir.zip" }
    Compress-Archive -Path (Join-Path $OutDir "*") -DestinationPath $zip
    Write-Host "`n$status`nSend this file: $zip" -ForegroundColor $(if ($failure) { "Red" } else { "Green" })
    if ($failure) { exit 1 }
}
