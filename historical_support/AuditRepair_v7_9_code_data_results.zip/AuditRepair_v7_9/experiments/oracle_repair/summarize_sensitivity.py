"""Summarise results/18_sensitivity (+ the archived B=400 baseline restricted to the same 10 seeds x 5 reps).
Writes results/18_sensitivity/summary.csv and prints a compact table. Run from the package root."""
from pathlib import Path
import numpy as np, pandas as pd

R = Path("results")
BASE = {"ag_news_5000": R / "12_oracle_repair/ag_news_5000", "ag_news_holdout": R / "12_oracle_repair/ag_news_holdout",
        "yelp_2600_star_alias": R / "12_oracle_repair/yelp_2600_star_alias", "dbpedia": R / "13_new_pools_3pct/dbpedia",
        "imdb": R / "13_new_pools_3pct/imdb", "emotion": R / "13_new_pools_3pct/emotion"}
CONFIGS = [("B100", "B", 100), ("B200", "B", 200), ("base", "B", 400), ("B800", "B", 800),
           ("m250", "m", 250), ("base", "m", 500), ("m1000", "m", 1000),
           ("alpha0.05", "alpha", 0.05), ("base", "alpha", 0.10), ("alpha0.2", "alpha", 0.2)]


def boot(d, n=4000, seed=0):
    rng = np.random.default_rng(seed)
    b = [rng.choice(d, len(d)).mean() for _ in range(n)]
    return np.percentile(b, [2.5, 97.5])


rows = []
for pool, base in BASE.items():
    for tag, param, value in CONFIGS:
        f = (base if tag == "base" else R / f"18_sensitivity/{pool}_{tag}") / "comparison.csv"
        if not f.exists():
            continue
        df = pd.read_csv(f)
        df = df[(df.seed < 10) & (df.rep < 5)]
        w = df.pivot_table(index=["seed", "rep"], columns="method", values="expert_total")
        e = df.pivot_table(index=["seed", "rep"], columns="method", values="error")
        N = {"ag_news_5000": 5000, "emotion": 2000}.get(pool, 2600)
        d_rep = (w["certified_repair"] - w["same_audit_ds"]).groupby(level="seed").mean().values
        d_aud = (w["same_audit_ds"] - w["pac_only"]).groupby(level="seed").mean().values
        d_orc = (w["oracle_free"] - w["same_audit_ds"]).groupby(level="seed").mean().values
        lo, hi = boot(d_aud)
        rows.append(dict(pool=pool, param=param, value=value, N=N, pac_only=w["pac_only"].mean(),
                         same_audit_ds=w["same_audit_ds"].mean(), certified=w["certified_repair"].mean(),
                         repair_minus_ds=d_rep.mean(), oracle_minus_ds=d_orc.mean(),
                         audits_minus_pac=d_aud.mean(), audits_lo=lo, audits_hi=hi,
                         error_pac=e["pac_only"].mean(), error_ds=e["same_audit_ds"].mean(),
                         violations_pac=int((e["pac_only"] > (0.03)).sum())))
out = pd.DataFrame(rows)
out.to_csv(R / "18_sensitivity/summary.csv", index=False)
pd.set_option("display.width", 200)
print(out.round(1).to_string(index=False))
