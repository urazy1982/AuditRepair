"""Oracle-repair decomposition (CPU only, existing annotation pools; retrospective diagnostic).

Question: is the shortfall of certified repair caused by (a) few repair opportunities, or
(b) the cost of discovering and certifying them?  For each preprocessing seed we fix ONE common
candidate shortlist (the guarded procedure's own: disjoint groups, size order, top 10) and pass
every arm through the same PAC stage with paired calibration draws:

  pac_only                    DS labels, no audits
  same_audit_ds               DS refitted on exactly the guarded run's audits
  certified_repair            the guarded procedure (extended search, stop after 10 failures)
  oracle_free                 same_audit_ds labels + every shortlisted group whose TRUE remainder
                              gain is positive, relabelled for free (gold used; not deployable)
  oracle_free_no_audits       DS labels (no audits) + beneficial repairs on that arm’s labels
  oracle_free_trusted         oracle_free, and repaired items are also offered for automatic
                              acceptance (uncertainty set to 0): what repair could save if the
                              certifier trusted the repaired labels

Costs are reported separately: pre-PAC audits, new PAC calibration labels, new threshold-review
labels. Intervals: 95% bootstrap over whole seeds, conditional on the pool.
Usage: python run_oracle_repair.py --labels pool.csv --out outdir [--seeds 20 --pac-reps 10]
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from audit_repair.core import Oracle, dawid_skene, run_group_repair, candidate_groups_disjoint, uncertainty_fill  # noqa: E402
from audit_repair.pac import pac_labels  # noqa: E402
from run_pilot import load_labels  # noqa: E402


def unc(post):
    return 1.0 - post.max(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--seeds", type=int, default=20)
    ap.add_argument("--pac-reps", type=int, default=10)
    ap.add_argument("--B", type=int, default=400)
    ap.add_argument("--m", type=int, default=500)
    ap.add_argument("--eps", type=float, default=0.03)
    ap.add_argument("--alpha", type=float, default=0.10)
    ap.add_argument("--alpha-repair", type=float, default=0.05)
    ap.add_argument("--min-size", type=int, default=30)
    ap.add_argument("--ref-share", type=float, default=0.3, help="warm-up share, as run_certified.py")
    ap.add_argument("--stop-after-fails", type=int, default=10)
    ap.add_argument("--boot", type=int, default=4000)
    ap.add_argument("--root-seed", type=int, default=20261030)  # same streams as run_certified.py
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)

    L0, gold0, K, _ = load_labels(a.labels)
    rows, groups_out = [], []
    for seed in range(a.seeds):
        ss_data, ss_pre, ss_pac = np.random.SeedSequence([a.root_seed, seed]).spawn(3)
        pac_streams = ss_pac.spawn(a.pac_reps)
        perm = np.random.default_rng(ss_data).permutation(len(gold0))
        L, gold = L0[perm], gold0[perm]

        def run(name, pre, pred, U, already):
            for r in range(a.pac_reps):
                _, info = pac_labels(pred, U, gold, eps=a.eps, alpha=a.alpha, m=a.m,
                                     already=already, seed=pac_streams[r])
                rows.append(dict(pool=Path(a.labels).name, method=name, seed=seed, rep=r, pre_audits=pre,
                                 calibration_new=info["calibration_new"], threshold_new=info["threshold_new"],
                                 expert_total=pre + info["expert_new"], error=info["error"],
                                 violated=info["error"] > a.eps))

        post0 = dawid_skene(L, K)
        run("pac_only", 0, post0.argmax(1), unc(post0), {})

        res = run_group_repair(L, K, gold, a.B, alpha=a.alpha_repair, seed=ss_pre, ref_share=a.ref_share,
                               min_size=a.min_size, stop_after_fails=a.stop_after_fails)
        y_g, info_g = res["guarded"]
        aud = info_g["audited_labels"]
        p3 = dawid_skene(L, K, dict(aud))
        run("same_audit_ds", len(aud), p3.argmax(1), unc(p3), aud)
        U_g = unc(info_g["post"])
        for i, pa in info_g["repair_conf"].items():
            U_g[i] = 1.0 - pa
        run("certified_repair", len(aud), y_g, U_g, aud)

        # common shortlist, rebuilt exactly as run_group_repair does (deterministic warm-up audits)
        warm_clamp = {}
        if int(a.ref_share * a.B):
            uncertainty_fill(L, K, Oracle(gold, int(a.ref_share * a.B)), warm_clamp)
        post_ref = dawid_skene(L, K, warm_clamp); ref = post_ref.argmax(1)
        for i, yv in warm_clamp.items():
            ref[i] = yv
        shortlist = sorted(candidate_groups_disjoint(L, ref, post_ref, min_size=a.min_size),
                           key=lambda g: -len(g.items))[:10]
        y_o, y_o0 = p3.argmax(1).copy(), post0.argmax(1).copy()
        repaired = []
        base = p3.argmax(1)
        base0 = post0.argmax(1)
        for j, g in enumerate(shortlist):
            rem = np.array([i for i in g.items if int(i) not in aud], dtype=int)
            gain = int((gold[rem] == g.alt).sum() - (gold[rem] == ref[rem]).sum()) if len(rem) else 0
            ds_gain = int((gold[rem] == g.alt).sum() - (gold[rem] == base[rem]).sum())
            ds0_gain = int((gold[g.items] == g.alt).sum() - (gold[g.items] == base0[g.items]).sum())
            tested = next((x for x in info_g["log"] if set(x["members"]) == set(map(int, g.items))), None)
            groups_out.append(dict(pool=Path(a.labels).name, seed=seed, rank=j, cur=int(g.cur), alt=int(g.alt),
                                   size=int(len(g.items)), oracle_remainder_gain=gain,
                                   same_audit_gain=ds_gain, no_audit_gain=ds0_gain,
                                   tested=tested is not None, certified=bool(tested and tested["guarded"])))
            if ds_gain > 0:
                y_o[rem] = g.alt
                repaired.extend(rem[base[rem] != g.alt].tolist())
            if ds0_gain > 0:
                y_o0[g.items] = g.alt
        run("oracle_free", len(aud), y_o, unc(p3), aud)
        run("oracle_free_no_audits", 0, y_o0, unc(post0), {})
        U_t = unc(p3).copy(); U_t[repaired] = 0.0
        run("oracle_free_trusted", len(aud), y_o, U_t, aud)
        print(f"seed {seed}: audits {len(aud)}, oracle-beneficial groups "
              f"{sum(d['oracle_remainder_gain'] > 0 for d in groups_out if d['seed'] == seed)}, "
              f"certified {sum(d['certified'] for d in groups_out if d['seed'] == seed)}", flush=True)

    df = pd.DataFrame(rows); df.to_csv(a.out / "comparison.csv", index=False)
    gdf = pd.DataFrame(groups_out); gdf.to_csv(a.out / "shortlists.csv", index=False)
    cols = ["pre_audits", "calibration_new", "threshold_new", "expert_total", "error"]
    summ = df.groupby("method")[cols].mean().reindex(
        ["pac_only", "same_audit_ds", "certified_repair", "oracle_free", "oracle_free_no_audits", "oracle_free_trusted"])
    summ["violations"] = df.groupby("method")["violated"].sum()
    rng = np.random.default_rng(a.root_seed)
    w = df.pivot_table(index=["seed", "rep"], columns="method", values="expert_total")
    lines = []
    for m, ref_m in [("certified_repair", "same_audit_ds"), ("oracle_free", "same_audit_ds"),
                     ("oracle_free_no_audits", "pac_only"), ("oracle_free_trusted", "same_audit_ds"),
                     ("same_audit_ds", "pac_only")]:
        d = (w[m] - w[ref_m]).groupby(level="seed").mean().values
        b = [rng.choice(d, len(d)).mean() for _ in range(a.boot)]
        lo, hi = np.percentile(b, [2.5, 97.5])
        lines.append(dict(method=m, reference=ref_m, mean_delta=d.mean(), lower=lo, upper=hi,
                          seeds_nonzero=int((np.abs(d) > 1e-9).sum())))
    pdiff = pd.DataFrame(lines); pdiff.to_csv(a.out / "paired_differences.csv", index=False)
    summ.to_csv(a.out / "summary.csv")
    rep_txt = (summ.round(4).to_string() + "\n\n" + pdiff.round(2).to_string(index=False) +
               f"\n\nOracle-beneficial groups per seed (mean): "
               f"{(gdf.assign(beneficial=gdf.same_audit_gain > 0).groupby('seed').beneficial.sum().reindex(range(a.seeds), fill_value=0).mean() if len(gdf) else 0):.2f}; "
               f"certified per seed: {(gdf.groupby('seed').certified.sum().reindex(range(a.seeds), fill_value=0).mean() if len(gdf) else 0):.2f}\n"
               "Oracle arms use gold labels and are retrospective benchmarks, not deployable methods.\n")
    (a.out / "report.txt").write_text(rep_txt); print(rep_txt)
    (a.out / "manifest.json").write_text(json.dumps(dict(vars(a), out=str(a.out), labels=a.labels,
                                                         numpy=np.__version__, pandas=pd.__version__), indent=2))


if __name__ == "__main__":
    main()
