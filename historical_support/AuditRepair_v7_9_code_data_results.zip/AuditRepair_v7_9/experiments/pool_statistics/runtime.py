"""Wall-clock time of each pipeline stage per pool (one seed, one PAC repetition; CPU)."""
import json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from audit_repair.core import dawid_skene, run_group_repair  # noqa: E402
from audit_repair.pac import pac_labels  # noqa: E402
from run_pilot import load_labels  # noqa: E402

rows = []
for p in sys.argv[2:]:
    L, g, K, _ = load_labels(p)
    t0 = time.perf_counter(); post = dawid_skene(L, K); t1 = time.perf_counter()
    res = run_group_repair(L, K, g, 400, seed=np.random.SeedSequence([1, 0]), ref_share=0.3, stop_after_fails=10); t2 = time.perf_counter()
    pac_labels(post.argmax(1), 1 - post.max(1), g, eps=0.03, alpha=0.1, m=500, seed=np.random.SeedSequence([2, 0])); t3 = time.perf_counter()
    rows.append(dict(pool=Path(p).stem, N=len(g), K=K, ds_fit_s=round(t1 - t0, 3), repair_stage_s=round(t2 - t1, 2),
                     groups_tested=len(res["guarded"][1]["log"]), pac_s=round(t3 - t2, 3)))
    print(rows[-1], flush=True)
Path(sys.argv[1]).write_text(json.dumps(rows, indent=1))
