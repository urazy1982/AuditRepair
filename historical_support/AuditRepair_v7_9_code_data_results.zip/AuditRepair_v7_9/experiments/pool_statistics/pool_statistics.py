"""Descriptive statistics of the annotation pools (CPU, retrospective; gold labels used for evaluation only).

Per pool: source accuracy and macro-F1, pairwise agreement and Cohen's kappa between sources, error
correlation between sources (phi of error indicators; share of joint errors that pick the same wrong
label), majority-vote and Dawid-Skene accuracy, the Dawid-Skene confusion matrix (rows = gold), the
number of distinct uncertainty values, and the calibration of Dawid-Skene uncertainty (binned error
rate vs mean uncertainty, expected calibration error).
Usage: python pool_statistics.py --labels data/a.csv [--labels data/b.csv ...] --out stats.json
"""
import argparse, json, sys
from itertools import combinations
from pathlib import Path
import numpy as np, pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from audit_repair.core import dawid_skene, majority_vote  # noqa: E402


def kappa(a, b, K):
    po = (a == b).mean()
    pa = np.bincount(a, minlength=K) / len(a); pb = np.bincount(b, minlength=K) / len(b)
    pe = (pa * pb).sum()
    return (po - pe) / (1 - pe) if pe < 1 else np.nan


def macro_f1(y, p, K):
    f = []
    for k in range(K):
        tp = ((p == k) & (y == k)).sum(); fp = ((p == k) & (y != k)).sum(); fn = ((p != k) & (y == k)).sum()
        f.append(2 * tp / (2 * tp + fp + fn) if tp + fp + fn else np.nan)
    return float(np.nanmean(f))


def analyse(path):
    df = pd.read_csv(path)
    meta = json.loads(Path(str(path) + ".meta.json").read_text())
    names = meta["classes"]; K = len(names)
    src = [c for c in df.columns if c.startswith("src_")]
    L = df[src].fillna(-1).astype(int).values
    stat = [c.replace("src_", "status_") for c in src]
    if all(c in df.columns for c in stat):  # pools without status columns (e.g. BANKING77) are all valid
        L[df[stat].values != "ok"] = -1
    g = df.gold.values.astype(int); N = len(g)
    out = dict(pool=Path(path).stem, N=N, K=K, classes=names,
               class_share=(np.bincount(g, minlength=K) / N).round(4).tolist())
    out["sources"] = {}
    for j, s in enumerate(src):
        ok = L[:, j] >= 0
        out["sources"][s] = dict(valid=float(ok.mean()), accuracy=float((L[ok, j] == g[ok]).mean()),
                                 macro_f1=macro_f1(g[ok], L[ok, j], K))
    pairs = []
    for a, b in combinations(range(len(src)), 2):
        ok = (L[:, a] >= 0) & (L[:, b] >= 0)
        ea, eb = L[ok, a] != g[ok], L[ok, b] != g[ok]
        both = ea & eb
        phi = np.corrcoef(ea, eb)[0, 1] if ea.std() > 0 and eb.std() > 0 else np.nan
        pairs.append(dict(a=src[a], b=src[b], agreement=float((L[ok, a] == L[ok, b]).mean()),
                          kappa=float(kappa(L[ok, a], L[ok, b], K)), error_phi=float(phi),
                          joint_error_rate=float(both.mean()),
                          same_wrong_label_given_both_wrong=float((L[ok, a][both] == L[ok, b][both]).mean()) if both.any() else np.nan))
    out["pairs"] = pairs
    mv = majority_vote(L, K, np.random.default_rng(0))   # random tie-break, fixed seed
    mv = mv.argmax(1) if np.ndim(mv) == 2 else mv
    post = dawid_skene(L, K); y = post.argmax(1); U = 1 - post.max(1)
    out["majority_vote_accuracy"] = float((mv == g).mean())
    out["ds_accuracy"] = float((y == g).mean()); out["ds_macro_f1"] = macro_f1(g, y, K)
    cm = np.zeros((K, K), int)
    np.add.at(cm, (g, y), 1)
    out["ds_confusion"] = cm.tolist()
    out["distinct_uncertainty_values"] = int(len(np.unique(U.round(12))))
    out["share_uncertainty_below_1e-6"] = float((U < 1e-6).mean())
    err = (y != g)
    bins = [0, 1e-6, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 1.0001]
    cal, ece = [], 0.0
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (U >= lo) & (U < hi)
        if m.any():
            cal.append(dict(lo=lo, hi=hi, n=int(m.sum()), mean_u=float(U[m].mean()), error=float(err[m].mean())))
            ece += m.mean() * abs(U[m].mean() - err[m].mean())
    out["calibration"] = cal; out["ece"] = float(ece)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--labels", action="append", required=True)
    ap.add_argument("--out", required=True); a = ap.parse_args()
    res = [analyse(p) for p in a.labels]
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(res, indent=1))
    for r in res:
        pr = pd.DataFrame(r["pairs"])
        print(f"{r['pool']:22s} N={r['N']} K={r['K']} MV {r['majority_vote_accuracy']:.3f} DS {r['ds_accuracy']:.3f} "
              f"kappa {pr.kappa.mean():.2f} err-phi {pr.error_phi.mean():.2f} same-wrong {pr.same_wrong_label_given_both_wrong.mean():.2f} "
              f"U-values {r['distinct_uncertainty_values']} U~0 {r['share_uncertainty_below_1e-6']:.2f} ECE {r['ece']:.3f}")
