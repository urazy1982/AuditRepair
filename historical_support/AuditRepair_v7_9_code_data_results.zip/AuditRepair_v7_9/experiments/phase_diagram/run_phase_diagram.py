"""When does repair pay? Synthetic phase diagram (CPU).

One systematic confusion (true class 0 -> label 1) is shared by k of the 4 sources (k = 1..4) on a
hidden slice of class 0 of size `frac` (flip probability 0.85); base accuracies as in the 'clear'
scenario. For each cell and seed we run the certified repair (extended search) and, on the same
audits and paired PAC draws, record
  share_above        share of items changed by beneficial (oracle) repairs above the PAC threshold
  labels_only        cost change from applying those repairs to the labels only (scores fixed)
  repair_minus_ds    certified repair + PAC minus DS with the same audits + PAC
  ds_error           Dawid-Skene error without audits
Usage: python run_phase_diagram.py --out outdir [--seeds 10 --pac-reps 5]
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from audit_repair.core import Oracle, dawid_skene, run_group_repair, candidate_groups_disjoint, uncertainty_fill  # noqa: E402
from audit_repair.pac import pac_labels  # noqa: E402
from audit_repair.simulate import Confusion, simulate  # noqa: E402


def unc(p):
    return 1.0 - p.max(1)


def cell(k, frac, seeds, reps, root=20261103, B=400, m=500, eps=0.03):
    sources = tuple(range(k))
    rows = []
    for seed in range(seeds):
        ss_data, ss_pre, ss_pac = np.random.SeedSequence([root, k, int(frac * 100), seed]).spawn(3)
        streams = ss_pac.spawn(reps)
        L, gold = simulate(seed=ss_data, confusions=[Confusion(0, 1, frac, sources)]); K = 4
        post0 = dawid_skene(L, K)
        res = run_group_repair(L, K, gold, B, alpha=0.05, seed=ss_pre, ref_share=0.3, min_size=30, stop_after_fails=10)
        aud = res["guarded"][1]["audited_labels"]
        p3 = dawid_skene(L, K, dict(aud)); base = p3.argmax(1); U3 = unc(p3)
        warm = {}
        uncertainty_fill(L, K, Oracle(gold, int(0.3 * B)), warm)
        pr = dawid_skene(L, K, warm); ref = pr.argmax(1)
        for i, v in warm.items():
            ref[i] = v
        y_or = base.copy(); changed = []
        for g in sorted(candidate_groups_disjoint(L, ref, pr, min_size=30), key=lambda g: -len(g.items))[:10]:
            rem = np.array([i for i in g.items if int(i) not in aud], dtype=int)
            if len(rem) and (gold[rem] == g.alt).sum() - (gold[rem] == base[rem]).sum() > 0:
                ch = rem[base[rem] != g.alt]; y_or[ch] = g.alt; changed.extend(ch.tolist())
        y_g, info = res["guarded"]
        U_g = unc(info["post"])
        for i, pa in info["repair_conf"].items():
            U_g[i] = 1.0 - pa
        ch = np.array(changed, dtype=int)
        for r in range(reps):
            _, b0 = pac_labels(base, U3, gold, eps=eps, alpha=0.1, m=m, already=aud, seed=streams[r])
            _, b1 = pac_labels(y_or, U3, gold, eps=eps, alpha=0.1, m=m, already=aud, seed=streams[r])
            _, b2 = pac_labels(y_g, U_g, gold, eps=eps, alpha=0.1, m=m, already=aud, seed=streams[r])
            rows.append(dict(k=k, frac=frac, seed=seed, rep=r, ds_error=float((post0.argmax(1) != gold).mean()),
                             changed=len(ch), share_above=float((U3[ch] > b0["u_hat"]).mean()) if len(ch) else np.nan,
                             labels_only=b1["expert_new"] - b0["expert_new"],
                             repair_minus_ds=b2["expert_new"] - b0["expert_new"],
                             certified=int(info["groups_repaired"])))
    return rows


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--seeds", type=int, default=10); ap.add_argument("--pac-reps", type=int, default=5)
    a = ap.parse_args(); a.out.mkdir(parents=True, exist_ok=False)
    rows = []
    for k in (1, 2, 3, 4):
        for frac in (0.1, 0.2, 0.35, 0.5):
            rows += cell(k, frac, a.seeds, a.pac_reps)
            print(f"k={k} frac={frac} done", flush=True)
    df = pd.DataFrame(rows); df.to_csv(a.out / "phase_diagram.csv", index=False)
    s = df.groupby(["k", "frac"]).agg(ds_error=("ds_error", "mean"), share_above=("share_above", "mean"),
                                      labels_only=("labels_only", "mean"), repair_minus_ds=("repair_minus_ds", "mean"),
                                      certified=("certified", "mean"))
    s.to_csv(a.out / "summary.csv"); txt = s.round(3).to_string(); (a.out / "report.txt").write_text(txt); print(txt)
    (a.out / "manifest.json").write_text(json.dumps(dict(seeds=a.seeds, pac_reps=a.pac_reps, numpy=np.__version__)))


if __name__ == "__main__":
    main()
