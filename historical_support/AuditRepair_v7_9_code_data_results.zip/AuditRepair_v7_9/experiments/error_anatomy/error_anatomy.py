"""Error anatomy of a fixed LLM annotation pool (CPU, uses gold only for retrospective analysis).

Answers three questions the cost results raise:
  1. How many aggregation errors are invisible to disagreement-based methods (all sources agree)?
  2. Does any source-defined repair group have a positive oracle gain (would relabelling it help)?
  3. How far is PAC's review cost from the oracle review cost at the same error target?
Usage: python error_anatomy.py --labels pool.csv [--labels pool2.csv ...] --out anatomy.json
"""
import argparse, json, sys
from collections import Counter
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from audit_repair.core import dawid_skene, candidate_groups_disjoint

def analyse(path):
    df = pd.read_csv(path)
    meta = json.loads(Path(str(path) + ".meta.json").read_text())
    K = len(meta["classes"])
    src = [c for c in df.columns if c.startswith("src_")]
    L = df[src].fillna(-1).astype(int).values
    stat = [c.replace("src_", "status_") for c in src]
    if all(c in df.columns for c in stat):  # pools without status columns (e.g. BANKING77) are all valid
        L[df[stat].values != "ok"] = -1
    g = df.gold.values.astype(int); N = len(g)
    post = dawid_skene(L, K); y = post.argmax(1); err = y != g
    unan = (L >= 0).all(1) & np.array([len(set(r)) == 1 for r in L])  # all responses valid AND identical
    groups = candidate_groups_disjoint(L, y, post, min_size=30)
    gains = []
    for G in groups:
        it = G.items
        gains.append(dict(cur=meta["classes"][G.cur], alt=meta["classes"][G.alt], size=int(len(it)),
                          oracle_gain=int((g[it] == G.alt).sum() - (g[it] == G.cur).sum()),
                          share_alt=round(float((g[it] == G.alt).mean()), 3),
                          share_cur=round(float((g[it] == G.cur).mean()), 3)))
    order = np.argsort(-(1 - post.max(1)), kind="stable")
    tail_err = np.cumsum(err[order[::-1]])
    oracle = {}
    for eps in (0.01, 0.02, 0.03, 0.05):
        ok = np.where(tail_err <= eps * N)[0]
        oracle[str(eps)] = int(N - (ok.max() + 1 if len(ok) else 0))
    conf = Counter((meta["classes"][a], meta["classes"][b]) for a, b in zip(g[err], y[err])).most_common(3)
    return dict(pool=Path(path).name, N=N, K=K,
                source_accuracy={s: round(float((L[:, j] == g)[L[:, j] >= 0].mean()), 3) for j, s in enumerate(src)},
                ds_error=round(float(err.mean()), 4), unanimous_share=round(float(unan.mean()), 3),
                errors=int(err.sum()), unanimous_wrong=int((err & unan).sum()),
                unanimous_wrong_share_of_errors=round(float((err & unan).sum() / max(err.sum(), 1)), 3),
                top_confusions_gold_to_pred=[[a, b, n] for (a, b), n in conf],
                candidate_groups=sorted(gains, key=lambda d: -d["size"]),
                groups_with_positive_oracle_gain=sum(d["oracle_gain"] > 0 for d in gains),
                oracle_review_cost=oracle)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--labels", action="append", required=True)
    ap.add_argument("--out", required=True); a = ap.parse_args()
    res = [analyse(p) for p in a.labels]
    Path(a.out).write_text(json.dumps(res, indent=2))
    for r in res:
        print(f"{r['pool']}: N={r['N']} DS error {r['ds_error']:.3f}; unanimous-wrong {r['unanimous_wrong']}/{r['errors']} "
              f"({100*r['unanimous_wrong_share_of_errors']:.0f}%); groups {len(r['candidate_groups'])}, positive oracle gain "
              f"{r['groups_with_positive_oracle_gain']}; oracle review @3% {r['oracle_review_cost']['0.03']}")
        for d in r["candidate_groups"][:4]:
            print(f"   {d['cur']:>8} -> {d['alt']:<8} n={d['size']:4d} gain={d['oracle_gain']:+5d} (alt {d['share_alt']:.2f} vs cur {d['share_cur']:.2f})")
