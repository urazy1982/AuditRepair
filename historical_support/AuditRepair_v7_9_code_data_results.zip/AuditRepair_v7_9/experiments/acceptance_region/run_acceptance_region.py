"""Where do repairs land relative to the PAC acceptance threshold? (CPU only; retrospective diagnostic)

Proposition (paper, Sec. 3): for uniform PAC Labels with fixed uncertainties U and fixed calibration draws,
if a relabelling changes predictions only on items with U_i > u_hat (the threshold selected for the
unrepaired labels), the selected threshold, the reviewed set, the final labels and the cost are identical.

For every pool and seed this script rebuilds exactly the same-audit Dawid-Skene labels and the common
shortlist used by run_oracle_repair.py / run_certified.py (same seeds and streams), takes the items a
beneficial repair would change (oracle: true remainder gain > 0 against the same-audit labels; for the
synthetic scenarios also the guarded procedure's accepted repairs), and for each PAC repetition records
  share_above   share of changed items with U_i > u_hat      (proposition applies when = 1)
  invariant     whether PAC on the repaired labels returns exactly the same threshold and cost
It also writes the uncertainty values, candidate flags and thresholds of seed 0 for plotting.
Usage:
  python run_acceptance_region.py --labels data/ag_news_5000.csv --out outdir
  python run_acceptance_region.py --sim clear --out outdir
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from audit_repair.core import (Oracle, dawid_skene, run_group_repair, candidate_groups_disjoint,  # noqa: E402
                               uncertainty_fill)
from audit_repair.pac import pac_labels  # noqa: E402
from audit_repair.simulate import SCENARIOS, simulate  # noqa: E402
from run_pilot import load_labels  # noqa: E402


def unc(post):
    return 1.0 - post.max(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--labels")
    g.add_argument("--sim", choices=list(SCENARIOS))
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--seeds", type=int, default=20)
    ap.add_argument("--pac-reps", type=int, default=10)
    ap.add_argument("--B", type=int, default=400)
    ap.add_argument("--m", type=int, default=500)
    ap.add_argument("--eps", type=float, default=0.03)
    ap.add_argument("--alpha", type=float, default=0.10)
    ap.add_argument("--alpha-repair", type=float, default=0.05)
    ap.add_argument("--min-size", type=int, default=30)
    ap.add_argument("--ref-share", type=float, default=0.3)
    ap.add_argument("--stop-after-fails", type=int, default=10)
    ap.add_argument("--root-seed", type=int, default=20261030)
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=False)
    pool = Path(a.labels).stem if a.labels else f"synthetic_{a.sim}"
    if a.labels:
        L0, gold0, K, _ = load_labels(a.labels)

    rows, plot = [], None
    for seed in range(a.seeds):
        ss_data, ss_pre, ss_pac = np.random.SeedSequence([a.root_seed, seed]).spawn(3)
        pac_streams = ss_pac.spawn(a.pac_reps)
        if a.sim:
            L, gold = simulate(seed=ss_data, **SCENARIOS[a.sim]); K = int(gold.max()) + 1
        else:
            perm = np.random.default_rng(ss_data).permutation(len(gold0))
            L, gold = L0[perm], gold0[perm]
        res = run_group_repair(L, K, gold, a.B, alpha=a.alpha_repair, seed=ss_pre, ref_share=a.ref_share,
                               min_size=a.min_size, stop_after_fails=a.stop_after_fails)
        aud = res["guarded"][1]["audited_labels"]
        p3 = dawid_skene(L, K, dict(aud)); base = p3.argmax(1); U3 = unc(p3)

        warm = {}
        if int(a.ref_share * a.B):
            uncertainty_fill(L, K, Oracle(gold, int(a.ref_share * a.B)), warm)
        post_ref = dawid_skene(L, K, warm); ref = post_ref.argmax(1)
        for i, yv in warm.items():
            ref[i] = yv
        shortlist = sorted(candidate_groups_disjoint(L, ref, post_ref, min_size=a.min_size),
                           key=lambda g: -len(g.items))[:10]
        sets = {"oracle": [], "guarded": []}
        y_or = base.copy()
        for g in shortlist:
            rem = np.array([i for i in g.items if int(i) not in aud], dtype=int)
            if len(rem) and (gold[rem] == g.alt).sum() - (gold[rem] == base[rem]).sum() > 0:
                ch = rem[base[rem] != g.alt]
                y_or[ch] = g.alt
                sets["oracle"].extend(ch.tolist())
        y_g = res["guarded"][0]
        sets["guarded"] = [int(i) for i in np.where((y_g != base))[0] if int(i) not in aud]
        y_gl = base.copy(); y_gl[sets["guarded"]] = y_g[sets["guarded"]]   # guarded labels, DS uncertainties
        cand = np.zeros(len(gold), bool)
        for g in shortlist:
            cand[g.items] = True
        dissent = np.array([len(set(r[r >= 0])) > 1 for r in L])

        for r in range(a.pac_reps):
            _, i0 = pac_labels(base, U3, gold, eps=a.eps, alpha=a.alpha, m=a.m, already=aud, seed=pac_streams[r])
            u_hat = i0["u_hat"]
            for kind, yrep in (("oracle", y_or), ("guarded", y_gl)):
                ch = np.array(sets[kind], dtype=int)
                _, i1 = pac_labels(yrep, U3, gold, eps=a.eps, alpha=a.alpha, m=a.m, already=aud, seed=pac_streams[r])
                rows.append(dict(pool=pool, seed=seed, rep=r, repair=kind, changed=len(ch),
                                 share_above=float((U3[ch] > u_hat).mean()) if len(ch) else np.nan,
                                 u_hat=u_hat, accepted_items=int((U3 < u_hat).sum()),
                                 dissent_share_above=float((U3[dissent] > u_hat).mean()) if dissent.any() else np.nan,
                                 cost_base=i0["expert_new"], cost_repaired=i1["expert_new"],
                                 invariant=bool(i1["u_hat"] == u_hat and i1["expert_new"] == i0["expert_new"])))
            if seed == 0 and r == 0:
                plot = dict(pool=pool, u_hat=u_hat, U=U3.round(6).tolist(), candidate=cand.tolist(),
                            dissent=dissent.tolist(), oracle_changed=sets["oracle"], wrong=(base != gold).tolist(),
                            audited=sorted(map(int, aud)))
        print(f"{pool} seed {seed}: oracle changes {len(sets['oracle'])}, guarded changes {len(sets['guarded'])}", flush=True)

    df = pd.DataFrame(rows); df.to_csv(a.out / "acceptance_region.csv", index=False)
    s = (df[df.changed > 0].groupby("repair")
         .agg(runs=("rep", "size"), mean_share_above=("share_above", "mean"),
              runs_all_above=("share_above", lambda x: int((x == 1).sum())),
              runs_invariant=("invariant", "sum"),
              mean_cost_change=("cost_repaired", "mean")))
    if len(s):
        base_cost = df[df.changed > 0].groupby("repair").cost_base.mean()
        s["mean_cost_change"] = s["mean_cost_change"] - base_cost
    # proposition check: every run with all changed items strictly above u_hat must be invariant
    applies = df[(df.changed > 0) & (df.share_above == 1)]
    violations = int((~applies.invariant).sum())
    txt = (f"pool {pool}\nruns with a non-empty repair:\n{s.round(3).to_string() if len(s) else '  none'}\n"
           f"mean accepted items (U < u_hat): {df.accepted_items.mean():.1f} of {len(gold)}; "
           f"mean share of items with source disagreement above u_hat: {df.dissent_share_above.mean():.3f}\n"
           f"proposition check: {len(applies)} runs with all changed items above u_hat, "
           f"{violations} of them not invariant (must be 0)\n")
    (a.out / "report.txt").write_text(txt); print(txt)
    (a.out / "plot_seed0.json").write_text(json.dumps(plot))
    (a.out / "manifest.json").write_text(json.dumps(dict({k: (str(v) if isinstance(v, Path) else v) for k, v in vars(a).items()},
                                                       numpy=np.__version__, pandas=pd.__version__), indent=2))


if __name__ == "__main__":
    main()
