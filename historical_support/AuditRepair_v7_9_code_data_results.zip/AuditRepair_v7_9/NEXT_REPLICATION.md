# External replication design

Purpose. Separate candidate availability, certification and review savings on
a fresh pool annotated by a more diverse panel.

Before exposing any evaluation gold labels, record the pool and sampling seed,
four distinct checkpoint revisions, prompts, parser and quality gate, the
repository revision, and the input hashes. Use one prompt per checkpoint. Fix
the group search, audit budget, PAC draws, error target and seed schedule using
the existing evaluation settings. Keep the model panel and dataset choice
fixed after annotation begins. Use the benchmark labels only through simulated
review and retrospective analysis.

Primary cost comparison. Compare guarded repair plus PAC with Dawid–Skene
refitted on the same audits plus PAC. Pair PAC draws. Count distinct benchmark
labels revealed, split by audit, calibration and threshold review. Report
realized final error and any target violations.

Mechanism diagnostic. Report the number and gains of beneficial shortlisted
groups, the number certified and the share of changed items strictly above
the baseline threshold. Run the fixed-score oracle against the same-audit
baseline. If no beneficial candidates exist, report that as evidence on
opportunity scarcity. If beneficial changes occur at or below the threshold,
report their effect on cost and error even if the effect is zero or adverse.

This is a protocol outline. Freeze the concrete dataset, checkpoint hashes,
sample size and analysis settings before running it.
